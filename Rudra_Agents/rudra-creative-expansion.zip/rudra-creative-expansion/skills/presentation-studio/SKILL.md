---
name: presentation-studio
description: >
  This skill activates when the user discusses creating presentations, slide decks,
  pitch decks, board presentations, steering committee decks, workshop slides,
  PowerPoint, PPTX generation, HTML slide decks, speaker notes, slide design,
  deck creation, or auto-generating polished consulting-grade presentation files.
version: 1.0.0
---

# Presentation Studio — Deck Production Excellence

Expert-level guidance for producing complete, polished presentation decks with content, visuals, speaker notes, and executive-ready formatting.

---

## 1. Deck Type Quick Reference

| Type | Slides | Audience | Key Principle |
|------|--------|----------|--------------|
| Pitch Deck | 10-15 | C-suite, prospects | Persuade & inspire |
| Board Presentation | 8-12 | Board, executives | Inform & decide |
| SteerCo Deck | 10-15 | Sponsors, PMO | Report & escalate |
| Workshop Slides | 20-40 | Working teams | Facilitate & engage |
| Deliverable Report | 15-30 | Mixed audience | Document & recommend |
| Training Material | 20-50 | End users | Teach & enable |

---

## 2. The 5 Laws of Executive Slides

### Law 1: One Slide = One Point
If you can't state the slide's message in one sentence, split it.

### Law 2: Title = Takeaway
The title should be the insight, not the topic.
**Bad:** "Revenue Analysis"
**Good:** "Revenue grew 23% driven by Enterprise expansion"

### Law 3: So What?
Every data slide must answer "So what does this mean?"
Place the insight below or beside the chart.

### Law 4: Visual Dominance
- Executive decks: 60% visual, 40% text
- Working decks: 40% visual, 60% text
- Never: walls of text with no visuals

### Law 5: The Storyline Test
Read only the slide titles in sequence. If they tell a coherent story without the content, your deck structure is right.

---

## 3. Slide Architecture Patterns

### The Situation-Complication-Resolution (SCR)
```
Slides 1-3: Situation — Set the context
Slides 4-6: Complication — Introduce the tension
Slides 7-10: Resolution — Present the solution
Slides 11-12: Next Steps — Call to action
```

### The What-So What-Now What
```
Slides 1-4: What — Present findings/data
Slides 5-8: So What — Analyze implications
Slides 9-12: Now What — Recommend actions
```

### The Problem-Solution-Value
```
Slides 1-3: Problem — Pain points (use client's words)
Slides 4-7: Solution — How we solve it
Slides 8-10: Value — Quantified benefits
Slides 11-12: Path Forward — How to start
```

---

## 4. Speaker Notes Best Practice

### Structure Per Slide
```
=== TALKING POINT ===
[1-2 sentences: the core message to deliver verbally]

=== CONTEXT ===
[Background that helps the presenter answer questions]

=== DATA CALLOUT ===
[Specific number to emphasize: "Note the 23% growth..."]

=== TRANSITION ===
["This leads us to..." or "Building on this..."]

=== ANTICIPATED QUESTIONS ===
Q: [Likely question]
A: [Prepared response]
```

---

## 5. Data Slide Design

### The Insight-First Pattern
```
┌─────────────────────────────────────────────────┐
│  ACTION TITLE (the insight)              [Logo] │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌───────────────────────────────────────┐     │
│  │        [CHART / VISUALIZATION]         │     │
│  │        Direct labels, no legend        │     │
│  │        Highlight the story line        │     │
│  └───────────────────────────────────────┘     │
│                                                 │
│  So What: [One sentence explaining significance]│
│                                                 │
├─────────────────────────────────────────────────┤
│  Source: [attribution] | Page X | Confidential  │
└─────────────────────────────────────────────────┘
```

### The Comparison Pattern
```
┌─────────────────────────────────────────────────┐
│  ACTION TITLE                            [Logo] │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌──────────────────┐  ┌──────────────────┐    │
│  │  OPTION A         │  │  OPTION B         │    │
│  │  • Pro 1          │  │  • Pro 1          │    │
│  │  • Pro 2          │  │  • Pro 2          │    │
│  │  Cost: $X         │  │  Cost: $Y         │    │
│  │  Timeline: Z mo   │  │  Timeline: W mo   │    │
│  └──────────────────┘  └──────────────────┘    │
│                                                 │
│  Recommendation: [Which and why]                │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 6. Output Format Specifications

### PowerPoint (.pptx) via python-pptx
```python
# Key specifications:
slide_width = Inches(13.333)   # Widescreen 16:9
slide_height = Inches(7.5)
title_font = 'Calibri', 28pt, Bold
body_font = 'Calibri', 18pt, Regular
accent_color = RGBColor(0x4A, 0x7C, 0x59)  # Forest green
```

### Interactive HTML Deck
```html
<!-- Key features: -->
- Arrow key navigation
- Touch/swipe support
- Presenter notes (press 'N')
- Slide counter
- Progress bar
- Print-friendly CSS
- Embedded Chart.js charts
- Responsive (desktop + tablet)
```

---

## 7. Quality Checklist

### Content Quality
- [ ] Every slide has an action title (insight, not topic)
- [ ] Data slides have "So What?" insight
- [ ] Speaker notes are complete
- [ ] Flow tells a coherent story (title test)
- [ ] No orphan slides (every slide connects)

### Visual Quality
- [ ] Consistent color palette throughout
- [ ] Font hierarchy applied (title/body/caption)
- [ ] Charts are directly labeled
- [ ] White space is balanced
- [ ] Maximum 7 elements per slide
- [ ] 3-second test on every slide

### Professional Quality
- [ ] Page numbers on every slide
- [ ] Confidentiality marking
- [ ] Client/company logos placed correctly
- [ ] Date and version noted
- [ ] Spell check passed
- [ ] No placeholder text remaining
