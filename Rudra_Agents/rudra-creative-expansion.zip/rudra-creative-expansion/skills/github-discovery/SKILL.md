---
name: github-discovery
description: >
  This skill activates when the user discusses GitHub, code search, repository discovery,
  open-source, agent frameworks, MCP servers, Claude plugins, reference architectures,
  consulting accelerators, code templates, reusable IP, API patterns, SDK examples,
  awesome lists, or finding existing implementations to reference or reuse.
version: 1.0.0
---

# GitHub Discovery & Code Intelligence

Expert-level guidance for discovering, evaluating, and leveraging code from GitHub to accelerate consulting engagements and extend AI platform capabilities.

---

## 1. Search Strategy Framework

### Query Construction
Build effective GitHub search queries using:
```
[domain keyword] + [technology] + [pattern type] + [quality filter]

Examples:
"aws bedrock agent" language:python stars:>50
"sap s4hana api" language:java pushed:>2024-01-01
"mcp-server" topic:model-context-protocol
"finance reconciliation" language:python stars:>20
"chart-of-accounts" OR "general-ledger" stars:>10
```

### Multi-Dimensional Search
For any request, search across 3+ dimensions:
1. **Exact match** — Direct technology/feature search
2. **Ecosystem** — Related tools, libraries, frameworks
3. **Awesome lists** — Curated collections (awesome-x)
4. **Organization repos** — Official samples (aws-samples, SAP, oracle)
5. **Template repos** — Starter kits and boilerplates

### GitHub Advanced Search Operators
| Operator | Example | Purpose |
|----------|---------|---------|
| `stars:>N` | `stars:>100` | Quality filter |
| `pushed:>date` | `pushed:>2024-06-01` | Activity filter |
| `language:X` | `language:python` | Language filter |
| `topic:X` | `topic:aws-bedrock` | Topic filter |
| `org:X` | `org:aws-samples` | Organization filter |
| `in:readme` | `bedrock in:readme` | Search in README |
| `filename:X` | `filename:docker-compose` | File search |

---

## 2. Evaluation Framework

### Repository Quality Score (1-10)
| Factor | Weight | Scoring |
|--------|--------|---------|
| Documentation | 20% | README quality, API docs, examples |
| Code quality | 20% | Style, error handling, architecture |
| Test coverage | 15% | Unit tests, integration tests, CI |
| Activity | 15% | Commit frequency, issue response |
| Community | 15% | Stars, forks, contributors |
| License | 10% | Permissive (MIT, Apache 2.0) |
| Security | 5% | No hardcoded secrets, dependency audit |

### Quick Evaluation Checklist
```
□ README exists and is comprehensive
□ License is permissive (MIT, Apache 2.0, BSD)
□ Last commit within 6 months
□ Issues are responded to
□ Tests exist and pass (check CI badges)
□ Dependencies are reasonable and up-to-date
□ No hardcoded credentials or API keys
□ Architecture is modular and extensible
```

---

## 3. Domain-Specific Search Guides

### AWS Bedrock & Agentic AI
```
Primary Orgs: aws-samples, aws-solutions-library-samples
Key Topics: aws-bedrock, bedrock-agents, generative-ai-aws
Search Patterns:
  "bedrock agent" knowledge base
  "bedrock" action group lambda
  "amazon bedrock" guardrails
  "bedrock" multi-agent orchestration
```

### SAP S/4HANA Integration
```
Primary Orgs: SAP, SAP-samples, SAP-archive
Key Topics: sap-cloud-sdk, s4hana, sap-btp
Search Patterns:
  "sap cloud sdk" language:java OR language:javascript
  "s4hana" odata OR api
  "sap integration suite" OR "sap-integration"
  "bapi" OR "idoc" connector
```

### Oracle ERP / EPM
```
Primary Orgs: oracle, oracle-samples, oracle-quickstart
Key Topics: oracle-cloud, oracle-erp, oracle-epm
Search Patterns:
  "oracle erp cloud" rest api
  "oracle epm" OR "oracle pbcs"
  "oracle integration cloud" OR "oic"
  "oracle fusion" financial
```

### MCP Servers & Claude Plugins
```
Key Topics: mcp, model-context-protocol, claude
Awesome Lists: awesome-mcp-servers
Search Patterns:
  "mcp-server" OR "mcp server"
  "model-context-protocol" tool
  "claude" plugin OR agent
  "anthropic" sdk OR agent
```

### Finance & Accounting Domain
```
Key Topics: fintech, financial-reporting, accounting, erp
Search Patterns:
  "financial close" automation
  "reconciliation" engine OR framework
  "chart of accounts" OR "general ledger"
  "ifrs" OR "gaap" reporting
  "intercompany" elimination OR matching
  "capital adequacy" OR "basel" OR "regulatory reporting"
```

### Data & Analytics
```
Key Topics: data-pipeline, etl, data-warehouse
Search Patterns:
  "databricks" notebook OR pipeline
  "redshift" OR "snowflake" dbt
  "power bi" embedded OR api
  "data quality" framework
  "data migration" erp OR sap OR oracle
```

---

## 4. Integration Patterns

### How to Adopt Found Code

**Pattern 1: Direct Use (Fork & Configure)**
Best for: Well-maintained, modular repos
```
1. Fork the repository
2. Review and understand the architecture
3. Configure for your environment
4. Add client-specific customizations
5. Maintain upstream sync for updates
```

**Pattern 2: Pattern Extraction (Learn & Rebuild)**
Best for: Good ideas, different stack
```
1. Study the architecture and patterns
2. Extract key algorithms or approaches
3. Rebuild in your technology stack
4. Add your domain-specific logic
5. Document the inspiration source
```

**Pattern 3: Library Integration (Import & Extend)**
Best for: Utility libraries, SDKs
```
1. Add as dependency (pip/npm install)
2. Wrap with your interface layer
3. Add error handling and logging
4. Write integration tests
5. Pin version for stability
```

---

## 5. Reporting Templates

### Quick Scout Report
```markdown
# GitHub Scout: [Topic]
**Searched:** [date] | **Queries:** [count] | **Repos Reviewed:** [count]

## Top 3 Recommendations
1. **[repo-name]** (stars) — [one-line description]
   - URL: [link]
   - Relevance: [why it matters]
   - Quality: [score]/10

2. **[repo-name]** ...

3. **[repo-name]** ...

## Gaps
[What wasn't found]
```

### Deep Discovery Report
```markdown
# GitHub Discovery: [Domain]
**Searched:** [date] | **Landscape Size:** [count repos]

## Ecosystem Map
[Visual or table of the technology landscape]

## Category Breakdown
### [Category 1]
| Repo | Stars | Language | Maturity | Fit |
|------|-------|----------|----------|-----|

### [Category 2]
...

## Recommended Stack
[Which repos to combine and how]

## Build vs. Adopt Matrix
| Capability | Recommendation | Rationale |
|------------|---------------|-----------|
```

---

## 6. Security & Compliance

### Before Using Any Found Code
- [ ] License review (legal clearance for commercial use)
- [ ] Dependency audit (no known vulnerabilities)
- [ ] Secret scan (no hardcoded credentials)
- [ ] Code review (no malicious patterns)
- [ ] Client IP policy check (open-source usage permitted?)

### License Compatibility Guide
| License | Commercial Use | Modification | Distribution | Patent |
|---------|---------------|-------------|-------------|--------|
| **MIT** | Yes | Yes | Yes | No |
| **Apache 2.0** | Yes | Yes | Yes | Yes |
| **BSD 2/3** | Yes | Yes | Yes | No |
| **GPL v3** | Caution | Yes | Copyleft | Yes |
| **AGPL** | Avoid | Yes | Strong copyleft | Yes |
