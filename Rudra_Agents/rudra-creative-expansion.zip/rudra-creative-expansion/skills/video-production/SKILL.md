---
name: video-production
description: >
  This skill activates when the user discusses video creation, explainer videos,
  prototype walkthroughs, screen recordings, slide-to-video conversion, storyboards,
  voiceover scripts, motion graphics videos, training videos, demo recordings,
  video production, narration, or any video content for consulting engagements.
version: 1.0.0
---

# Video Production — Consulting Video Content

Expert-level guidance for creating video content that communicates complex concepts to executive audiences through storyboards, voiceover scripts, and actual video production.

---

## 1. Video Type Selection

| Type | Duration | Purpose | Production Time |
|------|----------|---------|----------------|
| Animated Explainer | 1-3 min | Explain concept/platform | 2-4 hours |
| Prototype Walkthrough | 3-7 min | Demo a prototype async | 1-2 hours |
| Slide-to-Video | 5-15 min | Convert deck to video | 1-3 hours |
| Training Tutorial | 5-15 min | Teach a process/system | 3-5 hours |
| Micro-Video (Social) | 30-60 sec | Highlight a key insight | 30-60 min |
| Executive Summary | 1-2 min | Summarize a deliverable | 1-2 hours |

---

## 2. Scriptwriting Framework

### The Hook-Problem-Solution-Proof-CTA Structure
```
[0:00-0:10] HOOK
"What if your capital team could detect a $45 million
regulatory risk before it ever reached the report?"

[0:10-0:30] PROBLEM
"Today, capital adequacy reporting takes weeks of
manual reconciliation across disconnected systems..."

[0:30-1:00] SOLUTION
"Our Capital Intelligence Platform uses AI agents to
automatically reconcile, validate, and report..."

[1:00-1:45] HOW IT WORKS
"Step 1: Data flows from SAP S/4HANA into AWS Bedrock...
 Step 2: Specialized agents validate each component...
 Step 3: The dashboard shows real-time CET1 position..."

[1:45-2:15] PROOF
"In our pilot, this reduced reconciliation time by 70%
and caught 3 material misstatements that manual
processes had missed..."

[2:15-2:30] CALL TO ACTION
"Ready to see this with your data? Let's schedule
a 30-minute discovery session."
```

### Word Count / Duration Calculator
```
Target pace: 150 words per minute (executive)

30 seconds  = ~75 words
1 minute    = ~150 words
2 minutes   = ~300 words
5 minutes   = ~750 words
10 minutes  = ~1,500 words
```

### Script Writing Rules
1. **Write for the ear, not the eye** — Use contractions, short sentences
2. **One idea per sentence** — Complex ideas need visual support
3. **Active voice** — "The agent detects..." not "A detection is made..."
4. **Concrete over abstract** — "$45K mismatch" not "potential discrepancy"
5. **Pause markers** — [PAUSE] after key statistics or transitions

---

## 3. Storyboard Template

### Per-Frame Structure
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FRAME [#]  |  [START] → [END]  |  [DURATION]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VISUAL:
[Description of what's on screen — or a rough sketch]

VOICEOVER:
"[Exact narration text for this frame]"

ANIMATION NOTES:
• [Element] enters from [direction] at [timestamp]
• [Chart] builds progressively from [start] to [end]
• [Highlight] appears on [element] at [timestamp]

TRANSITION:
→ [Fade / Slide / Zoom / Cut] to Frame [#+1]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 4. Production Methods

### Method 1: Animated HTML → Screen Record → MP4
**Best for:** Explainer videos, platform demos
```
1. Build animated HTML sequence with timed CSS/JS
2. Open in browser at target resolution (1920x1080)
3. Screen record (OBS, QuickTime, or programmatic)
4. Add voiceover audio track
5. Export as MP4 (H.264, 30fps)
```

### Method 2: ffmpeg Image Sequence
**Best for:** Slide-to-video, controlled frame timing
```bash
# Generate PNG frames (1 per slide or scene)
# Assemble with ffmpeg:
ffmpeg -framerate 1/5 -i slide_%03d.png \
  -c:v libx264 -r 30 -pix_fmt yuv420p \
  -vf "scale=1920:1080:force_original_aspect_ratio=decrease,
       pad=1920:1080:-1:-1:color=white" \
  output.mp4

# Add fade transitions between slides:
ffmpeg -i slide1.png -i slide2.png \
  -filter_complex \
  "[0:v]loop=150:1:0,setpts=N/30/TB[v0]; \
   [1:v]loop=150:1:0,setpts=N/30/TB[v1]; \
   [v0][v1]xfade=transition=fade:duration=1:offset=4" \
  output.mp4
```

### Method 3: Canvas API Real-Time Recording
**Best for:** Interactive/generative animations
```javascript
const canvas = document.getElementById('animation');
const stream = canvas.captureStream(30);
const recorder = new MediaRecorder(stream, {
  mimeType: 'video/webm;codecs=vp9',
  videoBitsPerSecond: 8000000
});
const chunks = [];
recorder.ondataavailable = e => chunks.push(e.data);
recorder.onstop = () => {
  const blob = new Blob(chunks, { type: 'video/webm' });
  // Download or convert to MP4
};
recorder.start();
// Run animation...
// recorder.stop() when done
```

### Method 4: Programmatic with Puppeteer
**Best for:** Automated, reproducible video generation
```javascript
const puppeteer = require('puppeteer');
const { spawn } = require('child_process');

// 1. Launch browser at target resolution
// 2. Navigate to animated HTML
// 3. Screenshot each frame at 30fps
// 4. Assemble frames with ffmpeg
```

---

## 5. Video Specifications

### Standard Formats
| Context | Resolution | FPS | Codec | Bitrate |
|---------|-----------|-----|-------|---------|
| Presentation | 1920x1080 | 30 | H.264 | 5-8 Mbps |
| Web/Email | 1280x720 | 30 | H.264 | 3-5 Mbps |
| Social | 1080x1080 | 30 | H.264 | 3-5 Mbps |
| GIF fallback | 800x450 | 15 | GIF | N/A |

### Audio Specs
| Element | Spec |
|---------|------|
| Voiceover | 44.1kHz, 16-bit, mono or stereo |
| Background music | -20dB relative to voice |
| Total loudness | -16 LUFS (broadcast standard) |

---

## 6. Deliverable Package Structure
```
video-project/
├── 01-storyboard.md          # Frame-by-frame storyboard
├── 02-voiceover-script.md    # Narration with timing marks
├── 03-animated-source.html   # Animated HTML sequence
├── 04-frames/                # Key frame images (PNG)
├── 05-output/
│   ├── final.mp4             # Production video
│   ├── preview.gif           # GIF for email
│   └── thumbnail.png         # Cover image
├── 06-production-notes.md    # Tech specs, music recs
└── README.md                 # Reproduction guide
```

---

## 7. Quality Checklist

### Before Production
- [ ] Script reviewed and timed
- [ ] Storyboard approved
- [ ] Visual assets created
- [ ] Color palette matches client brand

### During Production
- [ ] Resolution correct (1920x1080)
- [ ] Frame rate smooth (30fps)
- [ ] Transitions are clean
- [ ] Text is readable at target size

### After Production
- [ ] Audio levels balanced
- [ ] No dead air > 2 seconds
- [ ] Captions/subtitles included
- [ ] File size reasonable (< 100MB for email)
- [ ] Thumbnail captures key message
