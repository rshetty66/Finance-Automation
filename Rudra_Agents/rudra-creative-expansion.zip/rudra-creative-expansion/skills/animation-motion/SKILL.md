---
name: animation-motion
description: >
  This skill activates when the user discusses animations, motion graphics, animated
  diagrams, interactive HTML, animated charts, CSS animations, SVG animations,
  particle effects, scroll-triggered animations, transition effects, animated
  infographics, interactive data visualizations, or any moving visual content
  for consulting deliverables, demos, and workshops.
version: 1.0.0
---

# Animation & Motion — Dynamic Visual Experiences

Expert-level guidance for creating animated visuals, interactive experiences, and motion graphics that elevate consulting deliverables.

---

## 1. Animation Decision Matrix

| Need | Technology | Complexity | Time |
|------|-----------|-----------|------|
| Animated diagram | SVG + CSS | Medium | 20-30 min |
| Data flow particles | Canvas / SVG | Medium-High | 25-35 min |
| Progressive waterfall | D3.js / Chart.js | Medium | 20-25 min |
| Interactive slider | HTML/CSS/JS | Low-Medium | 15-20 min |
| Scroll-triggered reveal | Intersection Observer | Low | 10-15 min |
| Counter animation | Vanilla JS | Low | 5-10 min |
| Background particles | Canvas / p5.js | Medium | 15-20 min |
| Drag-and-drop matrix | HTML/JS | Medium-High | 30-40 min |
| Morphing charts | D3.js transitions | High | 30-40 min |
| Animated timeline | CSS + JS | Medium | 20-30 min |

---

## 2. Core Animation Patterns

### Pattern 1: Progressive Reveal
```css
.reveal-item {
  opacity: 0;
  transform: translateY(20px);
  transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
}
.reveal-item.visible {
  opacity: 1;
  transform: translateY(0);
}
/* Stagger: delay increases per item */
.reveal-item:nth-child(1) { transition-delay: 0ms; }
.reveal-item:nth-child(2) { transition-delay: 100ms; }
.reveal-item:nth-child(3) { transition-delay: 200ms; }
```

### Pattern 2: Data Flow Particles
```javascript
// Particles moving along SVG paths between system nodes
class Particle {
  constructor(path, speed, color) {
    this.path = path;
    this.progress = 0;
    this.speed = speed;
    this.color = color;
  }
  update() {
    this.progress += this.speed;
    if (this.progress > 1) this.progress = 0;
    const point = this.path.getPointAtLength(
      this.progress * this.path.getTotalLength()
    );
    return { x: point.x, y: point.y };
  }
}
```

### Pattern 3: Counter Animation
```javascript
function animateValue(el, start, end, duration) {
  const range = end - start;
  const startTime = performance.now();
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    el.textContent = formatNumber(start + range * eased);
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}
```

### Pattern 4: Pulse / Heartbeat
```css
@keyframes pulse {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(74, 124, 89, 0.4);
  }
  50% {
    transform: scale(1.03);
    box-shadow: 0 0 0 12px rgba(74, 124, 89, 0);
  }
}
.live-indicator { animation: pulse 2s ease-in-out infinite; }
```

### Pattern 5: Draw Line / Path
```css
.draw-line {
  stroke-dasharray: 1000;
  stroke-dashoffset: 1000;
  animation: draw 2s ease-out forwards;
}
@keyframes draw {
  to { stroke-dashoffset: 0; }
}
```

---

## 3. Timing & Easing Reference

### Duration Guide
| Animation Type | Duration | Notes |
|---------------|----------|-------|
| Hover feedback | 150ms | Immediate feel |
| Button click | 200ms | Responsive feel |
| Card expansion | 300ms | Smooth reveal |
| Modal open | 400ms | Noticeable but fast |
| Content reveal | 600ms | Dramatic but not slow |
| Chart build | 1000ms | Time to absorb |
| Full sequence | 2000ms | Storytelling pace |
| Ambient loop | 5000ms+ | Background rhythm |

### Easing Functions
```css
/* Standard material motion */
--ease-standard: cubic-bezier(0.4, 0, 0.2, 1);

/* Deceleration (entering) */
--ease-decelerate: cubic-bezier(0, 0, 0.2, 1);

/* Acceleration (exiting) */
--ease-accelerate: cubic-bezier(0.4, 0, 1, 1);

/* Sharp (quick in-out) */
--ease-sharp: cubic-bezier(0.4, 0, 0.6, 1);

/* Bounce (playful, use sparingly) */
--ease-bounce: cubic-bezier(0.34, 1.56, 0.64, 1);
```

---

## 4. Interactive Patterns for Workshops

### Draggable Priority Matrix
```
High Impact ┌───────────────────────────┐
            │  Quick Wins  │  Strategic  │
            │  (do first)  │  (plan for) │
            ├──────────────┼────────────│
            │  Fill-ins    │  Rethink   │
            │  (delegate)  │  (depriori)│
Low Impact  └───────────────────────────┘
            Low Effort        High Effort

Drag initiative cards into quadrants.
Animate snap-to-grid and reorder within quadrants.
```

### Interactive Score Radar
```
Dimensions: Process, Technology, People, Data, Controls, Governance
Drag points on each axis (1-5 scale)
Animate the polygon shape morphing
Show benchmark overlay for comparison
Calculate and display overall maturity score
```

### Before/After Slider
```
Slide a divider left/right to compare two states
Left side: Current state visual
Right side: Future state visual
Smooth CSS clip-path animation
```

---

## 5. Accessibility & Performance

### Reduced Motion
```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

### Performance Budget
- Maximum 20 simultaneous animations
- Prefer transform/opacity over layout properties
- Use `will-change` for known animations
- Throttle scroll handlers (requestAnimationFrame)
- Lazy-load off-screen animations

### Keyboard Accessibility
- Space: Play/pause
- Arrow keys: Step through sequences
- Tab: Navigate interactive elements
- Escape: Reset state
