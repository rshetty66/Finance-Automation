---
name: image-studio
description: >
  This skill activates when the user discusses creating images, diagrams, architecture
  visuals, infographics, data visualizations, charts, illustrations, icons, SVG graphics,
  process flows, system diagrams, visual assets, executive graphics, or any visual
  content generation for consulting deliverables and presentations.
version: 1.0.0
---

# Image Studio — Visual Asset Creation

Expert-level guidance for producing diagrams, infographics, charts, and illustrations optimized for Big 4 consulting-grade presentations and executive audiences.

---

## 1. Visual Asset Decision Matrix

| Need | Technology | Output Format | Time |
|------|-----------|--------------|------|
| Architecture diagram | SVG / HTML | .html / .svg | 15-20 min |
| Data chart (static) | Python matplotlib | .png | 10-15 min |
| Data chart (interactive) | Plotly / Chart.js | .html | 15-20 min |
| Infographic | HTML/CSS | .html | 20-30 min |
| Process flow | Mermaid / SVG | .html / .svg | 10-15 min |
| Icon set | SVG | .svg | 15-20 min |
| Generative art | p5.js / Canvas | .html / .png | 15-20 min |
| Waterfall chart | D3.js / Plotly | .html | 15-20 min |
| Heat map | Python seaborn | .png / .html | 10-15 min |
| Sankey diagram | D3.js / Plotly | .html | 20-25 min |

---

## 2. Client Color System

### Warm White/Grey (Default — Per Client Preference)
```css
:root {
  --bg-primary: #FAFAF8;
  --bg-secondary: #F0EFEB;
  --bg-card: #FFFFFF;
  --text-primary: #2D2D2D;
  --text-secondary: #6B6B6B;
  --text-muted: #999999;
  --accent-green: #4A7C59;
  --accent-copper: #C4956A;
  --accent-blue: #5B7FA5;
  --accent-purple: #8B6DAF;
  --border: #E0DED8;
  --shadow: rgba(0,0,0,0.06);
  --positive: #2E7D32;
  --negative: #C62828;
  --warning: #E65100;
  --neutral: #9E9E9E;
}
```

### Sequential Palette (for ordered data)
```
Light → Dark progression:
#E8F0E4 → #B8D4A8 → #7CB86A → #4A7C59 → #2D5A3A
```

### Diverging Palette (for positive/negative)
```
Negative ← Neutral → Positive:
#C62828 → #E57373 → #F0EFEB → #81C784 → #2E7D32
```

---

## 3. Chart Design Best Practices

### The Tufte Principles
1. **Data-ink ratio** — Maximize data, minimize decoration
2. **Chartjunk** — Remove anything that doesn't inform
3. **Small multiples** — Repeat simple charts for comparison
4. **Direct labeling** — Label data points, not legends
5. **Aspect ratio** — Banking to 45° for line charts

### Chart Type Selection
```
COMPARISON → Bar chart (horizontal for labels, vertical for time)
TREND → Line chart (max 5 series, highlight the story)
COMPOSITION → Stacked bar or treemap (part-to-whole)
DISTRIBUTION → Histogram or box plot (spread and outliers)
CORRELATION → Scatter plot (two variables, highlight clusters)
FLOW → Sankey diagram (volume between categories)
HIERARCHY → Treemap or sunburst (nested categories)
STATUS → Bullet chart or gauge (target vs. actual)
BRIDGE → Waterfall chart (start to end decomposition)
```

### Financial Chart Patterns

**CET1 Waterfall:**
```
Opening CET1 → +Net Income → -Dividends → +/-RWA → -Deductions → Closing CET1
Bars: Green (positive), Red (negative), Grey (totals)
Connector lines between bars
Labels: Value + % change
```

**Budget vs. Actual:**
```
Clustered bars: Budget (outline) vs. Actual (filled)
Variance line overlay
Color: Green (favorable), Red (unfavorable)
Summary row: Total variance + %
```

---

## 4. SVG Architecture Diagram Patterns

### Layered Architecture
```svg
<!-- 5-layer pattern -->
<rect fill="#FAFAF8" /> <!-- Background -->
<g class="layer-5">Presentation</g>
<g class="layer-4">Application Logic</g>
<g class="layer-3">Orchestration</g>
<g class="layer-2">Data Services</g>
<g class="layer-1">Source Systems</g>
<!-- Arrows connecting layers -->
```

### Hub-and-Spoke
```
Central hub (larger node) connected to peripheral systems
Good for: Integration architecture, data hub, accounting hub
Animate: Data particles flowing along spokes
```

### Pipeline / Flow
```
Left-to-right flow: Source → Transform → Enrich → Load → Present
Good for: ETL, data pipelines, close process
Annotate: Volumes, timing, technology at each step
```

---

## 5. Infographic Design Patterns

### Before/After Comparison
```
┌──────────────────────┬──────────────────────┐
│  TODAY                │  TOMORROW            │
│  [Pain icon] 8 days  │  [Win icon] 4 days   │
│  [Pain icon] 65% manual│ [Win icon] 15% manual│
│  [Pain icon] $2M cost │  [Win icon] $800K    │
│  Red/warm tones       │  Green/cool tones    │
└──────────────────────┴──────────────────────┘
```

### Value Proposition
```
┌─────────────────────────────────────────┐
│  HEADLINE: Bold value statement         │
│  ─────────────────────────────────────  │
│  [Icon] Metric 1  [Icon] Metric 2      │
│  [Icon] Metric 3  [Icon] Metric 4      │
│  ─────────────────────────────────────  │
│  CALL TO ACTION: Next step              │
└─────────────────────────────────────────┘
```

### Timeline / Roadmap
```
Q1 2026 ──── Q2 2026 ──── Q3 2026 ──── Q4 2026
  │              │              │              │
  Phase 1:       Phase 2:       Phase 3:       Phase 4:
  Discovery      Design         Build          Deploy
  [deliverables] [deliverables] [deliverables] [deliverables]
```

---

## 6. Production Quality Checklist

### Before Delivery
- [ ] Key message visible in 3 seconds
- [ ] Color contrast meets WCAG AA (4.5:1 text, 3:1 graphics)
- [ ] All text is readable at intended display size
- [ ] Data is accurately represented (spot-check numbers)
- [ ] Consistent spacing and alignment
- [ ] Client color palette applied correctly
- [ ] No typos or grammatical errors
- [ ] File format appropriate for use case
- [ ] Transparent background where needed (PNG)
- [ ] Vector format preserved where possible (SVG)
