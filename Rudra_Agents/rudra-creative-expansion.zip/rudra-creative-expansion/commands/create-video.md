---
name: create-video
description: Create explainer videos, prototype walkthroughs, and slide-to-video conversions
---

# /create-video

Produce video content — storyboards, voiceover scripts, animated sequences, and video files.

## Usage
```
/create-video "2-min explainer for BCAR Agentic AI platform pitch"
/create-video "Narrated walkthrough of Capital Intelligence prototype"
/create-video "Convert our 15-slide proposal into a 5-min video"
```

## What This Command Does

1. **Plans the video** — Type, duration, audience, key message
2. **Writes the script** — Voiceover narration with timing markers
3. **Creates storyboard** — Frame-by-frame visual plan
4. **Builds animated source** — HTML/CSS/JS animation sequence
5. **Produces video** — MP4 via ffmpeg or Canvas recording (when possible)

## Video Types

| Type | Duration | Purpose |
|------|----------|---------|
| Animated Explainer | 1-3 min | Explain concept/platform |
| Prototype Walkthrough | 3-7 min | Demo for async viewing |
| Slide-to-Video | 5-15 min | Convert deck to video |
| Training Tutorial | 5-15 min | Teach process/system |
| Executive Summary | 1-2 min | Summarize a deliverable |

## Deliverable Package
```
storyboard.md           — Frame-by-frame plan
voiceover-script.md     — Narration with timing
animated-sequence.html  — HTML animation source
output/video.mp4        — Final video (when producible)
output/video.gif        — GIF for email embeds
```

## Tips
- Specify duration: "2 minutes" not "short video"
- Name the audience: "for the CFO who missed the demo"
- Include key data: "show the 70% reduction in rec time"
