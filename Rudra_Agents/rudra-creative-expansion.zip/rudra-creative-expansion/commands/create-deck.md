---
name: create-deck
description: Auto-generate polished presentation decks (PPTX or interactive HTML)
---

# /create-deck

Generate complete, polished presentation decks with content, charts, speaker notes, and executive formatting.

## Usage
```
/create-deck "12-slide pitch deck for BCAR Agentic AI platform to bank CFO/CRO"
/create-deck "SteerCo deck for March — program status, risks, decisions needed"
/create-deck "Workshop slides for 2-day finance transformation design session"
```

## What This Command Does

1. **Determines deck type** — Pitch, board, SteerCo, workshop, deliverable
2. **Builds slide outline** — Action titles, content structure, visual plan
3. **Generates full content** — Every slide with text, charts, and speaker notes
4. **Produces deliverable file** — .pptx or interactive .html deck

## Deck Types

| Type | Slides | Best For |
|------|--------|----------|
| Pitch Deck | 10-15 | Winning deals |
| Board Presentation | 8-12 | Executive decisions |
| SteerCo Deck | 10-15 | Status reporting |
| Workshop Slides | 20-40 | Facilitated sessions |
| Deliverable Report | 15-30 | Recommendations |

## Output Formats
- **.pptx** — Editable PowerPoint with speaker notes
- **.html** — Interactive slide deck with keyboard navigation
- **.jsx** — React component with interactive charts

## Tips
- Specify the audience: "CFO and CRO" vs "project team"
- Include the key message: "investing $2.5M saves $8.4M over 5 years"
- Request speaker notes: "include talking points for each slide"
