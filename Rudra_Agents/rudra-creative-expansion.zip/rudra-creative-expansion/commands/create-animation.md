---
name: create-animation
description: Create animated visuals, interactive experiences, and motion graphics
---

# /create-animation

Create animated diagrams, interactive charts, motion graphics, and dynamic visuals for demos and workshops.

## Usage
```
/create-animation "Animated data flow from SAP through Bedrock agents to dashboard"
/create-animation "Progressive CET1 waterfall that builds step by step"
/create-animation "Interactive maturity radar with draggable scores"
```

## What This Command Does

1. **Plans the animation** — Purpose, timing, interaction model
2. **Selects technology** — SVG/CSS, Canvas, D3.js, React
3. **Builds the experience** — Coded, tested, and polished
4. **Ensures accessibility** — Reduced motion support, keyboard controls

## Animation Types

| Type | Technology | Time |
|------|-----------|------|
| Animated diagram | SVG + CSS | 20-30 min |
| Data flow particles | Canvas / SVG | 25-35 min |
| Progressive chart | D3.js / Chart.js | 20-25 min |
| Interactive slider | HTML/CSS/JS | 15-20 min |
| Counter animation | Vanilla JS | 5-10 min |
| Scroll-triggered reveal | Intersection Observer | 10-15 min |
| Drag-and-drop matrix | HTML/JS | 30-40 min |

## Output: Self-contained .html file with embedded CSS/JS

## Tips
- Specify the trigger: "on scroll", "on click", "auto-play"
- Mention timing: "build over 3 seconds" or "step through on click"
- Request interactivity: "draggable", "hover reveals", "slider"
