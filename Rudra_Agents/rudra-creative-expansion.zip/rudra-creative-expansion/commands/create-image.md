---
name: create-image
description: Create diagrams, infographics, charts, and visual assets for consulting deliverables
---

# /create-image

Generate visual assets — architecture diagrams, infographics, data charts, process flows, and illustrations.

## Usage
```
/create-image "BCAR platform architecture diagram — SAP, BlackLine, AWS Bedrock, Redshift"
/create-image "CET1 waterfall chart from 12.8% to 13.2% with 5 components"
/create-image "Before/after infographic — manual vs automated close process"
```

## What This Command Does

1. **Understands the visual brief** — Audience, format, style, content
2. **Selects the right technology** — SVG, HTML/CSS, Python, Mermaid, p5.js
3. **Creates the visual** — Using client's warm white/grey palette by default
4. **Quality checks** — 3-second rule, contrast, accuracy, readability

## Visual Types

| Request | Output | Format |
|---------|--------|--------|
| Architecture diagram | Layered system visual | .html / .svg |
| Data chart | Waterfall, bar, line, gauge | .html / .png |
| Infographic | Single-page visual story | .html |
| Process flow | BPMN / swim lane diagram | .html / .svg |
| Comparison visual | Before/after or side-by-side | .html |
| Timeline/roadmap | Phased visual with milestones | .html / .svg |

## Tips
- Specify the audience: "for the board" vs "for the working team"
- Mention key data: "CET1 from 12.8% to 13.2%" not "a capital chart"
- Request a specific style: "warm white/grey" or "corporate navy"
