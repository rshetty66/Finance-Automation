---
name: github-search
description: Search GitHub for code, templates, agent frameworks, and consulting accelerators
---

# /github-search

Search GitHub for code, templates, frameworks, and patterns to accelerate your engagement.

## Usage
```
/github-search "AWS Bedrock agent patterns for capital reporting"
/github-search "MCP servers for SAP S/4HANA integration"
/github-search "finance transformation RACI templates"
```

## What This Command Does

1. **Parses your search intent** — Breaks your request into 3-5 search dimensions
2. **Executes multi-query search** — Searches GitHub across repos, orgs, topics, and awesome-lists
3. **Evaluates results** — Scores repos on quality, relevance, activity, and license
4. **Delivers recommendations** — Top 3-5 repos with rationale and integration guidance

## Output

```markdown
# GitHub Scout Report: [Your Topic]

## Search Summary
- Queries executed: [list]
- Repos scanned: [count]

## Top Recommendations
### 1. [Repo Name] — [stars] stars
- URL: [link]
- Relevance: [why it matters]
- Quality: [score]/10
- How to Use: [guidance]

## Integration Guidance
[How to apply to your engagement]

## Gaps
[What needs to be built custom]
```

## Tips
- Be specific: "SAP S/4HANA GL API connector Python" > "SAP code"
- Include technology: "AWS Bedrock multi-agent Python" > "AI agents"
- Mention use case: "reconciliation automation" > "finance tool"
