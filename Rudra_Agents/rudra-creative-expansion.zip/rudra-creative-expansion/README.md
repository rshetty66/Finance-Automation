# Rudra Creative Expansion Pack

## 5 New Sub-Agents + 5 Skills + 5 Commands

This expansion adds a full **Creative Production Studio** to your Rudra consulting platform — taking your agent count from 12 to **17 specialized sub-agents**.

---

## New Agents

| Agent | Color | Specialty | Key Capability |
|-------|-------|-----------|----------------|
| **github-scout** | Cyan | GitHub Discovery | Code search, agent/plugin discovery, IP reuse |
| **image-studio** | Violet | Visual Assets | Diagrams, infographics, charts, SVG art |
| **presentation-studio** | Yellow | Deck Production | Auto-generate PPTX/HTML with speaker notes |
| **animation-motion** | Green | Motion Graphics | Animated diagrams, interactive workshops |
| **video-producer** | Red | Video Content | Explainers, walkthroughs, slide-to-video |

---

## New Skills

| Skill | Triggers |
|-------|----------|
| **github-discovery** | GitHub, code search, MCP servers, repos, frameworks |
| **image-studio** | Diagrams, infographics, charts, visual assets, SVG |
| **presentation-studio** | Decks, slides, PPTX, presentations, speaker notes |
| **animation-motion** | Animations, motion, interactive, particles, scroll |
| **video-production** | Videos, storyboards, voiceover, walkthroughs, MP4 |

---

## New Commands

| Command | Purpose |
|---------|---------|
| `/github-search` | Search GitHub for code, templates, and frameworks |
| `/create-image` | Generate diagrams, charts, and infographics |
| `/create-deck` | Auto-generate polished presentation decks |
| `/create-animation` | Create animated visuals and interactive experiences |
| `/create-video` | Produce explainer videos and walkthroughs |

---

## Installation

### Option 1: Merge into Existing Rudra Plugin
Copy these files into your Rudra plugin directory:

```bash
# Agents (copy to agents/)
cp agents/github-scout.md      → [rudra-plugin]/agents/
cp agents/image-studio.md      → [rudra-plugin]/agents/
cp agents/presentation-studio.md → [rudra-plugin]/agents/
cp agents/animation-motion.md  → [rudra-plugin]/agents/
cp agents/video-producer.md    → [rudra-plugin]/agents/

# Skills (copy to skills/)
cp -r skills/github-discovery/  → [rudra-plugin]/skills/
cp -r skills/image-studio/      → [rudra-plugin]/skills/
cp -r skills/presentation-studio/ → [rudra-plugin]/skills/
cp -r skills/animation-motion/  → [rudra-plugin]/skills/
cp -r skills/video-production/  → [rudra-plugin]/skills/

# Commands (copy to commands/)
cp commands/github-search.md    → [rudra-plugin]/commands/
cp commands/create-image.md     → [rudra-plugin]/commands/
cp commands/create-deck.md      → [rudra-plugin]/commands/
cp commands/create-animation.md → [rudra-plugin]/commands/
cp commands/create-video.md     → [rudra-plugin]/commands/
```

### Option 2: Update Rudra Master Agent
Apply the sections from `agents/rudra-updated-sections.md` to your main `rudra.md` agent file.

---

## Architecture After Expansion

```
RUDRA (Master Agent — 17 Sub-Agents)
├── CONSULTING CORE
│   ├── coa-designer
│   ├── accounting-hub-architect
│   ├── rapid-prototyper
│   └── apqc-researcher
│
├── SYSTEMS INTEGRATION
│   ├── si-finance-process-lead
│   ├── si-functional-lead
│   ├── si-data-architect
│   ├── si-integration-lead
│   ├── si-security-controls-lead
│   ├── si-change-management-lead
│   └── si-data-analytics-lead
│
├── CREATIVE DESIGN (existing)
│   └── creative-designer
│
└── CREATIVE PRODUCTION STUDIO (NEW)
    ├── github-scout          ← Code & agent discovery
    ├── image-studio          ← Visual asset creation
    ├── presentation-studio   ← Polished deck generation
    ├── animation-motion      ← Animated & interactive visuals
    └── video-producer        ← Video content production
```

---

## Example Workflows

### Pitch Preparation (Full Stack)
```
1. /github-search "competitor AI platforms in capital reporting"
2. /create-image "BCAR platform architecture diagram"
3. /create-deck "12-slide pitch for bank CFO"
4. /create-animation "animated data flow demo"
5. /create-video "2-min explainer for email follow-up"
```

### Workshop Delivery
```
1. /create-deck "workshop slides for design session"
2. /create-animation "interactive maturity radar"
3. /create-image "current vs future state infographic"
4. /create-video "session recording walkthrough"
```

### Deliverable Enhancement
```
1. /create-image "architecture diagram for design doc"
2. /create-deck "executive summary presentation"
3. /create-animation "animated roadmap timeline"
```
