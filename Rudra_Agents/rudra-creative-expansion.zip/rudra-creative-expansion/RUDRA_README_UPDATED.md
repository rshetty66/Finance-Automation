# Rudra: The Ultimate Consulting Expert Agent

**Your AI partner for selling, managing, delivering, and driving vision for consulting engagements — with comprehensive Systems Integration expertise, APQC benchmark capabilities, and a full Creative Production Studio across all major platforms.**

Rudra is a specialized consulting agent designed to help you succeed across the full engagement lifecycle — from winning deals to delivering exceptional client value. Built on 25+ years of frontline consulting experience.

**Key Capabilities:**
- 🎯 **SELL** — Win deals through compelling propositions
- 📊 **MANAGE** — Run programs with discipline
- ✨ **DELIVER** — Produce exceptional work
- 🏛️ **MODERN FINANCE** — Deep GL/COA/Accounting Hub expertise
- ⚡ **PROTOTYPE** — 15-minute vision demos
- 🔧 **SYSTEMS INTEGRATION** — Full-spectrum SI expertise
- 📊 **APQC BENCHMARKS** — PCF, benchmarks, best practices
- 🎨 **CREATIVE DESIGN** — Stunning visuals and interactive GUIs
- 🔍 **GITHUB DISCOVERY** — Code search, agent/plugin discovery, IP reuse
- 🖼️ **IMAGE STUDIO** — Diagrams, infographics, charts, SVG art
- 📑 **PRESENTATION STUDIO** — Auto-generate polished PPTX/HTML decks
- 🎬 **ANIMATION & MOTION** — Animated diagrams, interactive experiences
- 🎥 **VIDEO PRODUCER** — Explainer videos, walkthroughs, slide-to-video

---

## What Rudra Does

### 🎯 SELL — Win More Deals
Rudra helps you qualify opportunities, develop win strategies, and craft compelling proposals.

### 📊 MANAGE — Run Programs with Discipline
Rudra guides you through program setup, governance design, risk management, and recovery.

### ✨ DELIVER — Produce Exceptional Work
Rudra ensures your deliverables meet the highest standards — board-ready and professionally polished.

### 🏛️ MODERN FINANCE — Deep GL Expertise
Rudra provides world-class expertise in General Ledger architecture, Chart of Accounts design, Accounting Hub concepts, and financial close optimization.

### ⚡ PROTOTYPE — Drive Vision in 15 Minutes
Rudra creates rapid prototypes — dashboards, calculators, process flows — to accelerate decisions.

### 🔧 SYSTEMS INTEGRATION — Full-Spectrum SI
Rudra covers all SI workstreams across Oracle, SAP, Workday, OneStream, Anaplan, Databricks, AWS, and more.

### 📊 APQC BENCHMARKS — Data-Driven Insights
Rudra leverages APQC's Process Classification Framework (PCF) and benchmarking data to assess performance, set targets, and validate business cases.

### 🎨 CREATIVE DESIGN — Mind-Blowing Visuals
Rudra creates stunning visual designs, executive dashboards, interactive GUIs, and pitch decks that captivate audiences and drive engagement.

### 🔍 GITHUB DISCOVERY — Code Intelligence (NEW)
Search GitHub for reference architectures, agent frameworks, MCP servers, consulting accelerators, and reusable IP. Evaluate quality, relevance, and licensing.

### 🖼️ IMAGE STUDIO — Visual Asset Creation (NEW)
Generate architecture diagrams, infographics, data visualizations, process flows, and illustrations using SVG, HTML/CSS, Python, and p5.js.

### 📑 PRESENTATION STUDIO — Deck Production (NEW)
Auto-generate complete pitch decks, board presentations, SteerCo decks, and workshop slides with action titles, charts, and speaker notes.

### 🎬 ANIMATION & MOTION — Dynamic Experiences (NEW)
Create animated data flows, progressive chart reveals, interactive workshop tools, scroll-triggered animations, and motion graphics.

### 🎥 VIDEO PRODUCER — Video Content (NEW)
Produce animated explainer videos, narrated prototype walkthroughs, slide-to-video conversions, and training tutorials.

---

## Sub-Agents

Rudra can spawn **17 specialized sub-agents** for focused, complex tasks:

### Consulting Core
| Sub-Agent | Specialty | When to Spawn |
|-----------|-----------|---------------|
| **coa-designer** | COA Design Guru | Multi-entity COA design or rationalization |
| **accounting-hub-architect** | Hub Architecture | Multi-ERP consolidation |
| **rapid-prototyper** | Vision Demos | 15-minute prototypes |
| **apqc-researcher** | Benchmarks & PCF | APQC analysis, target setting |

### Systems Integration
| Sub-Agent | Specialty | When to Spawn |
|-----------|-----------|---------------|
| **si-finance-process-lead** | Process Design | R2R, O2C, P2P, Planning |
| **si-functional-lead** | ERP Configuration | Oracle, SAP, Workday setup |
| **si-data-architect** | Data & Migration | Migration, MDM, governance |
| **si-integration-lead** | Integration | APIs, middleware, B2B |
| **si-security-controls-lead** | Security & Compliance | SOD, SOX, access management |
| **si-change-management-lead** | OCM | Training, adoption, readiness |
| **si-data-analytics-lead** | BI & Analytics | Power BI, Tableau, dashboards |

### Creative Design
| Sub-Agent | Specialty | When to Spawn |
|-----------|-----------|---------------|
| **creative-designer** | Visual Design & GUI | Stunning visuals, interactive interfaces |

### Creative Production Studio (NEW)
| Sub-Agent | Specialty | When to Spawn |
|-----------|-----------|---------------|
| **github-scout** | GitHub Discovery | Code search, agent discovery, IP reuse |
| **image-studio** | Visual Assets | Diagrams, infographics, charts, SVG |
| **presentation-studio** | Deck Production | PPTX/HTML decks with speaker notes |
| **animation-motion** | Animation & Motion | Animated diagrams, interactive tools |
| **video-producer** | Video Content | Explainers, walkthroughs, slide-to-video |

---

## Commands

Use these commands to engage Rudra:

### Sales Commands
| Command | Purpose |
|---------|---------|
| `/qualify-deal "..."` | MEDDIC deal qualification |
| `/win-strategy "..."` | Competitive win strategy |

### Program Management Commands
| Command | Purpose |
|---------|---------|
| `/setup-program "..."` | Program governance setup |
| `/recovery-plan "..."` | Troubled program recovery |

### Delivery Commands
| Command | Purpose |
|---------|---------|
| `/review-deliverable "..."` | Quality review |

### Prototyping Commands
| Command | Purpose |
|---------|---------|
| `/prototype-vision "..."` | 15-minute prototype |

### APQC Commands
| Command | Purpose |
|---------|---------|
| `/apqc-analysis "..."` | Benchmark analysis |

### Creative Design Commands
| Command | Purpose |
|---------|---------|
| `/design-visuals "..."` | Create stunning visuals, dashboards, GUIs |

### Creative Production Studio Commands (NEW)
| Command | Purpose |
|---------|---------|
| `/github-search "..."` | Search GitHub for code, templates, frameworks |
| `/create-image "..."` | Generate diagrams, charts, and infographics |
| `/create-deck "..."` | Auto-generate polished presentation decks |
| `/create-animation "..."` | Create animated visuals and interactive experiences |
| `/create-video "..."` | Produce explainer videos and walkthroughs |

---

## Architecture

```
RUDRA (Master Agent — 17 Sub-Agents)
├── CONSULTING CORE
│   ├── coa-designer
│   ├── accounting-hub-architect
│   ├── rapid-prototyper
│   └── apqc-researcher
│
├── SYSTEMS INTEGRATION
│   ├── si-finance-process-lead
│   ├── si-functional-lead
│   ├── si-data-architect
│   ├── si-integration-lead
│   ├── si-security-controls-lead
│   ├── si-change-management-lead
│   └── si-data-analytics-lead
│
├── CREATIVE DESIGN
│   └── creative-designer
│
└── CREATIVE PRODUCTION STUDIO (NEW)
    ├── github-scout          ← Code & agent discovery
    ├── image-studio          ← Visual asset creation
    ├── presentation-studio   ← Polished deck generation
    ├── animation-motion      ← Animated & interactive visuals
    └── video-producer        ← Video content production
```

---

## Files Included

```
agents/
  ├── rudra.md                           # Main agent (UPDATED — 17 sub-agents)
  ├── coa-designer.md                    # COA Design Guru
  ├── accounting-hub-architect.md        # Hub Architecture
  ├── rapid-prototyper.md                # 15-min Prototypes
  ├── si-finance-process-lead.md         # Process Design
  ├── si-functional-lead.md              # ERP Configuration
  ├── si-data-architect.md               # Data & Migration
  ├── si-integration-lead.md             # Integration
  ├── si-security-controls-lead.md       # Security & Compliance
  ├── si-change-management-lead.md       # OCM
  ├── si-data-analytics-lead.md          # BI & Analytics
  ├── apqc-researcher.md                 # APQC Benchmarks
  ├── creative-designer.md               # Visual Design & GUI
  ├── github-scout.md                    # GitHub Discovery (NEW)
  ├── image-studio.md                    # Visual Assets (NEW)
  ├── presentation-studio.md             # Deck Production (NEW)
  ├── animation-motion.md                # Animation & Motion (NEW)
  └── video-producer.md                  # Video Content (NEW)

skills/
  ├── program-management/
  ├── delivery-excellence/
  ├── modern-finance-gl/
  ├── si-finance-process-lead/
  ├── si-functional-lead/
  ├── si-data-architect/
  ├── si-integration-lead/
  ├── si-security-controls/
  ├── si-change-management/
  ├── si-data-analytics/
  ├── apqc-benchmarks/
  ├── creative-design/
  ├── github-discovery/                  # GitHub intelligence (NEW)
  ├── image-studio/                      # Visual asset creation (NEW)
  ├── presentation-studio/               # Deck production (NEW)
  ├── animation-motion/                  # Animation & motion (NEW)
  └── video-production/                  # Video production (NEW)

commands/
  ├── qualify-deal.md
  ├── win-strategy.md
  ├── setup-program.md
  ├── recovery-plan.md
  ├── review-deliverable.md
  ├── prototype-vision.md
  ├── apqc-analysis.md
  ├── design-visuals.md
  ├── github-search.md                   # GitHub search (NEW)
  ├── create-image.md                    # Image creation (NEW)
  ├── create-deck.md                     # Deck creation (NEW)
  ├── create-animation.md                # Animation creation (NEW)
  └── create-video.md                    # Video creation (NEW)

RUDRA_README.md                          # This file (UPDATED)
```

---

## Getting Started

1. **Try a Command**: `/qualify-deal` on an opportunity
2. **Spawn a Sub-Agent**: "Spawn the [role] for [task]"
3. **Search GitHub**: `/github-search "AWS Bedrock agent patterns"`
4. **Create Visuals**: `/create-image "architecture diagram for BCAR platform"`
5. **Generate Decks**: `/create-deck "12-slide pitch for bank CFO"`
6. **Animate**: `/create-animation "data flow from SAP to dashboard"`
7. **Produce Video**: `/create-video "2-min platform explainer"`
8. **Iterate**: Use output and ask follow-up questions

---

**Rudra is ready — your ultimate consulting partner with 17 specialized sub-agents covering sales, delivery, SI, benchmarks, and a full Creative Production Studio!**

What's your biggest challenge right now?
