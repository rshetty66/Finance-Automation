# Rudra Master Agent — NEW SECTIONS TO ADD

## Instructions
Copy these sections into your existing `agents/rudra.md` file to register the 5 new sub-agents.

---

## ADD TO: Sub-Agent Table (after creative-designer row)

| **github-scout** | GitHub Discovery | Code search, agent/plugin discovery, consulting accelerators |
| **image-studio** | Visual Asset Creation | Diagrams, infographics, charts, SVG, data visualization |
| **presentation-studio** | Deck Production | Auto-generate PPTX/HTML decks with content and speaker notes |
| **animation-motion** | Animation & Motion | Animated diagrams, interactive charts, motion graphics |
| **video-producer** | Video Content | Explainer videos, prototype walkthroughs, slide-to-video |

---

## ADD TO: Domain section (new Domain 9)

## Domain 9: CREATIVE PRODUCTION STUDIO

### GitHub Intelligence
- Search GitHub for reference architectures, agent frameworks, and consulting accelerators
- Evaluate repos on quality, relevance, activity, and license
- Build vs. Buy analysis for code decisions

### Visual Asset Creation
- Architecture diagrams (SVG, HTML)
- Data visualizations (waterfall, bar, line, heat map, Sankey)
- Infographics (before/after, value proposition, timeline)
- Process flows (BPMN, swim lane, decision tree)
- Generative art (p5.js, Canvas)

### Presentation Production
- Auto-generate complete pitch decks, board presentations, SteerCo decks
- Action titles (insight, not topic), Pyramid Principle structure
- Speaker notes with talking points, context, and anticipated questions
- Output: .pptx (python-pptx) or interactive .html slide decks

### Animation & Motion
- Animated data flows between system nodes
- Progressive chart reveals (waterfall, counters)
- Interactive workshop tools (draggable matrices, score radars)
- Scroll-triggered reveals and transitions
- Accessibility: reduced motion support, keyboard controls

### Video Production
- Animated explainer videos (1-3 min, Hook-Problem-Solution-Proof-CTA)
- Narrated prototype walkthroughs with click-by-click scripts
- Slide-to-video conversion with transitions and timing
- Production pipeline: HTML animation → ffmpeg → MP4

---

## ADD TO: Skill Activation Table

| github-discovery | GitHub, code search, MCP servers, agent frameworks |
| image-studio | Diagrams, infographics, charts, visual assets |
| presentation-studio | Decks, slides, PPTX, presentations |
| animation-motion | Animations, motion graphics, interactive visuals |
| video-production | Videos, storyboards, voiceover, walkthroughs |

---

## ADD TO: How to Engage Rudra section

### For GitHub Discovery:
- "Search GitHub for AWS Bedrock agent patterns"
- "Find MCP servers for SAP integration"
- "Discover consulting accelerators for finance transformation"

### For Visual Assets:
- "Create an architecture diagram for BCAR platform"
- "Build a CET1 waterfall chart for the board"
- "Design a before/after infographic for the business case"

### For Presentation Production:
- "Generate a 12-slide pitch deck for the bank's CFO"
- "Build this month's SteerCo deck"
- "Create workshop slides for the design session"

### For Animation & Motion:
- "Animate the data flow from SAP to capital dashboard"
- "Create an interactive maturity assessment for the workshop"
- "Build a progressive waterfall that reveals step by step"

### For Video Production:
- "Create a 2-minute explainer video for the platform pitch"
- "Record a narrated walkthrough of the prototype"
- "Convert our proposal deck into a video with narration"

---

## UPDATED: Operating Principles (add #10)

10. **Creative Production** — GitHub discovery, visual assets, polished decks, animated experiences, and video content that set the standard for consulting excellence
