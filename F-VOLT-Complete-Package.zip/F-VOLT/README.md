# F-VOLT

**Full-spectrum Virtual Operations & Leadership Technology**

The enterprise consulting AI platform with 55 specialized agents, 26 skills, and 18 commands spanning the complete Big 4 / Systems Integrator service catalogue.

---

## What is F-VOLT?

F-VOLT is a unified package of AI consulting agents that replicate the expertise of an entire Big 4 consulting practice. Each agent embodies deep domain knowledge, proven methodologies, and first-principles thinking across enterprise transformation, ERP/EPM implementation, M&A, change management, and beyond.

**55 Agents. 10 Service Lines. 1 Platform.**

---

## Package Structure

```
F-VOLT/
├── agents/
│   ├── 01-consulting-core/        (15 agents)  Principal + SI Leads
│   ├── 02-erp-oracle/             ( 5 agents)  Oracle ERP Cloud Modules
│   ├── 03-erp-sap/                ( 5 agents)  SAP S/4HANA Modules
│   ├── 04-erp-workday-d365-netsuite/ ( 3 agents)  Other ERP Platforms
│   ├── 05-erp-cross-platform/     ( 4 agents)  Test, Cutover, Migration, Architect
│   ├── 06-epm-oracle/             ( 6 agents)  Oracle EPM Cloud Suite
│   ├── 07-epm-onestream-anaplan/  ( 2 agents)  Alternative EPM Platforms
│   ├── 08-epm-specialty/          ( 2 agents)  Workforce & Capital Planning
│   ├── 09-change-management-ai/   ( 6 agents)  Agentic AI-Driven OCM
│   └── 10-ma-finance/             ( 7 agents)  M&A Day 1 / Day 2 Finance
├── skills/                        (26 skills)  Domain Knowledge Packs
├── commands/                      (18 commands) Executable Workflows
└── README.md
```

---

## Agent Catalogue

### 01 — Consulting Core (15 Agents)

| Agent | Role | First Principle |
|-------|------|-----------------|
| rudra | Principal Consulting Partner & Orchestrator | The consulting partner principle — blend sales acumen, delivery excellence, and client empathy |
| si-finance-process-lead | R2R, O2C, P2P, Planning Process Design | Standardize first, automate second |
| si-functional-lead | ERP Configuration (Oracle, SAP, Workday) | Configuration over customization |
| si-data-architect | Data Migration, MDM, Governance | Data quality is non-negotiable |
| si-integration-lead | APIs, Middleware, B2B/EDI | Loose coupling, tight contracts |
| si-security-controls-lead | SOD, SOX, Access Management | Security by design |
| si-change-management-lead | OCM, Training, Adoption | Adoption is the real go-live |
| si-data-analytics-lead | BI, Reporting, Dashboards | Insight must reach the decision-maker |
| coa-designer | Chart of Accounts Design | Structure enables insight |
| accounting-hub-architect | Multi-ERP Accounting Consolidation | Single source of truth |
| rapid-prototyper | 15-Minute Vision Demos | Show, don't tell |
| apqc-researcher | APQC Benchmarks & PCF | Benchmark before you build |
| creative-designer | Visual Design & Executive UX | Design is decision-making |
| transformation-diagnostician | Maturity Assessment (7 dimensions) | Diagnose before prescribing |
| solution-architect | Technology Stack Recommendation | Technology is an enabler, not a strategy |

### 02 — ERP: Oracle Cloud (5 Agents)

| Agent | Modules | First Principle |
|-------|---------|-----------------|
| oracle-gl-specialist | GL, SLA, Multi-GAAP, Ledgers, Close | The GL is the single source of truth |
| oracle-ap-ar-specialist | Payables, Receivables, Cash Management | AP and AR are the cash conversion engine |
| oracle-procurement-specialist | Requisitions, POs, Sourcing, Suppliers | Procurement controls spend before it happens |
| oracle-projects-specialist | PPM, Costing, Billing, Capitalization | Projects are where strategy meets execution |
| oracle-fa-specialist | Fixed Assets, Depreciation, CIP, Leases | Asset data quality drives depreciation accuracy |

### 03 — ERP: SAP S/4HANA (5 Agents)

| Agent | Modules | First Principle |
|-------|---------|-----------------|
| sap-fico-specialist | FI/CO, Universal Journal, CO-PA, Material Ledger | The Universal Journal is S/4's revolution |
| sap-mm-sd-specialist | MM, SD, Procurement, Sales, Pricing | MM and SD are the operational backbone |
| sap-basis-architect | Basis, HANA, TMS, Security, RISE, Fiori | Basis is the foundation |
| sap-pp-pm-specialist | Production Planning, Plant Maintenance, MRP | Manufacturing efficiency is planned |
| sap-ewm-tm-specialist | Extended Warehouse, Transportation Mgmt | Warehouse efficiency compounds |

### 04 — ERP: Other Platforms (3 Agents)

| Agent | Platform | First Principle |
|-------|----------|-----------------|
| workday-financials-specialist | Workday Financial Management | Workday's power is in worktags |
| dynamics365-specialist | Microsoft D365 Finance & Operations | D365 thrives in the Microsoft ecosystem |
| netsuite-specialist | NetSuite OneWorld | NetSuite owns the mid-market |

### 05 — ERP: Cross-Platform (4 Agents)

| Agent | Domain | First Principle |
|-------|--------|-----------------|
| erp-test-lead | SIT, UAT, Regression, Automation | Testing is not a phase, it's a mindset |
| erp-cutover-go-live-lead | Cutover, Go/No-Go, Hypercare | Go-live is a one-way door |
| erp-data-migration-lead | Data Profiling, Cleansing, Loading | Data migration is 30% of effort, 80% of risk |
| erp-solution-architect | Cross-Module Design Authority | The solution architect sees the whole board |

### 06 — EPM: Oracle Cloud (6 Agents)

| Agent | Product | First Principle |
|-------|---------|-----------------|
| oracle-pbcs-epbcs-lead | Planning & Budgeting Cloud | Planning is a business process, not a technology |
| oracle-fccs-lead | Financial Consolidation & Close | Consolidation is the final mile of financial truth |
| oracle-arcs-lead | Account Reconciliation Cloud | Reconciliation is the control that catches everything |
| oracle-edmcs-lead | Enterprise Data Management Cloud | Metadata governance is the unsung hero |
| oracle-narrative-reporting-lead | Narrative Reporting | Numbers without narrative are noise |
| oracle-pcm-lead | Profitability & Cost Management | Allocate costs with causal drivers, not arbitrary spreads |

### 07 — EPM: OneStream & Anaplan (2 Agents)

| Agent | Platform | First Principle |
|-------|----------|-----------------|
| onestream-specialist | OneStream XF Unified Platform | OneStream's power is unification |
| anaplan-specialist | Anaplan Connected Planning | Anaplan democratizes planning |

### 08 — EPM: Specialty (2 Agents)

| Agent | Domain | First Principle |
|-------|--------|-----------------|
| epm-workforce-planning-lead | Headcount, Compensation, Attrition | People are the largest cost and the most important asset |
| epm-capital-planning-lead | CapEx, NPV/IRR, Asset Lifecycle | Capital allocation is the highest-leverage decision |

### 09 — Agentic AI Change Management (6 Agents)

| Agent | Domain | First Principle |
|-------|--------|-----------------|
| agentic-change-orchestrator | AI-Driven OCM Architecture | Change is the operating system of transformation |
| digital-adoption-platform-architect | WalkMe, Whatfix, Pendo, Enable Now | The best training is no training |
| ai-resistance-analytics-lead | ML Resistance Detection & Intervention | Resistance is data, not defiance |
| ai-learning-experience-architect | AI-Personalized Learning, LXP, GenAI Content | Learning is continuous, personalized, embedded |
| change-impact-assessment-lead | Impact Mapping, Readiness, Stakeholder Analysis | You can't manage what you haven't mapped |
| change-measurement-value-lead | Adoption Analytics, Change ROI | If you can't prove value, you can't justify it |

### 10 — M&A Finance Transformation (7 Agents)

| Agent | Phase | First Principle |
|-------|-------|-----------------|
| ma-day1-readiness-lead | Day 1 (Close) | Day 1 is a regulatory obligation, not a milestone |
| ma-day2-finance-integration-lead | Day 2-365 | Day 2 is where value is created or destroyed |
| ma-financial-due-diligence-lead | Pre-Close | Every dollar of unvalidated EBITDA is overpayment risk |
| ma-synergy-value-architect | Pre-Close → Year 2 | Synergies justify the premium |
| ma-carve-out-finance-lead | Special | Carve-outs are harder than integrations |
| ma-purchase-price-allocation-lead | Close | PPA determines the acquirer's balance sheet for years |
| ma-tsa-standalone-finance-lead | Post-Close | A TSA is a bridge, not a destination |

---

## First Principles

Every F-VOLT agent is grounded in a first principle — a fundamental truth that guides its behavior, shapes its recommendations, and determines where it pushes back. These are not slogans; they are decision-making frameworks.

---

## Technology Coverage

| Category | Platforms |
|----------|----------|
| ERP | Oracle ERP Cloud, SAP S/4HANA, Workday, Microsoft D365, NetSuite |
| EPM | Oracle PBCS/FCCS/ARCS/EDMCS, OneStream, Anaplan |
| Integration | MuleSoft, Dell Boomi, OIC, SAP Integration Suite |
| Analytics | Power BI, Tableau, Looker, Oracle Analytics Cloud |
| Cloud | AWS, Azure, GCP |
| Data | Databricks, Snowflake, Redshift |
| DAP | WalkMe, Whatfix, Pendo, SAP Enable Now, Oracle Guided Learning |
| GRC | SAP GRC, Oracle GRC, ServiceNow, Archer |

---

## Author

Rakesh Shetty — Finance Transformation & Big 4 / SI Consulting

---

*F-VOLT: 55 agents. 26 skills. 18 commands. One platform. Every engagement.*
