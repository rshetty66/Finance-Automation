---
description: Design a systems integration solution and testing strategy
allowed-tools: Read, Write
argument-hint: "[source systems, target systems, data flows, or integration context]"
---

Design a comprehensive Systems Integration (SI) solution and testing strategy based on: $ARGUMENTS

If files have been provided (system architecture diagrams, process designs, integration requirements, current state documentation), read them first.

Operate as the Principal Systems Integration Architect with deep experience in ERP/EPM integration, API strategy, data migration, and enterprise integration patterns for financial services.

---

## SYSTEMS INTEGRATION SOLUTION DESIGN

**INTEGRATION INVENTORY**

Map all required integrations. For each integration, define:

| Integration ID | Source System | Target System | Data Domain | Volume (daily) | Frequency | Priority | Pattern |
|---------------|--------------|--------------|-------------|---------------|-----------|---------|---------|
| INT-001 | | | | | | | |
| INT-002 | | | | | | | |

---

**INTEGRATION ARCHITECTURE DECISIONS**

**Architecture Pattern Selection**:

For each integration, recommend the appropriate pattern with rationale:

| Pattern | Description | Use Cases | Tools |
|---------|-------------|-----------|-------|
| **Real-time API (REST/GraphQL)** | Synchronous, sub-second | Master data sync, real-time event processing | MuleSoft, Azure APIM, Kong |
| **Event-driven (pub/sub)** | Async, near-real-time | Journal posting events, approval completions, workflow triggers | Kafka, Azure Event Hub, AWS EventBridge |
| **Batch ETL/ELT** | Scheduled bulk transfers | GL balance uploads, master data refresh, large data migration | Oracle ODI, Azure Data Factory, Informatica, dbt |
| **Pre-built connectors** | Vendor-native integration | ERP-to-EPM data load (standard GL/HR feeds) | Oracle FDMEE/Data Management, SAP BTP, Workday Studio |
| **File-based (SFTP/API)** | Legacy or third-party systems | Banking feeds, regulatory submissions, legacy ERP | SFTP, S3, Azure Blob |

**Middleware / Integration Platform Decision**:
Recommend integration platform based on: existing enterprise standards, volume, complexity, in-house skills, budget.

| Platform | Strengths | Weaknesses | Best Fit |
|---------|----------|-----------|----------|
| MuleSoft Anypoint | Enterprise-grade, API-first, large connector library | High cost | Large enterprise, multi-cloud, existing investment |
| Azure Integration Services | Strong Microsoft/Office 365 integration, competitive cost | Best in Microsoft ecosystem | Microsoft-centric organizations |
| Oracle Integration Cloud | Native Oracle ERP/EPM connectors, low-code | Oracle-centric | Oracle ERP/EPM shops |
| Dell Boomi | Broad connectors, low-code | Less strong for high-volume | Mid-market |
| AWS Glue + EventBridge | Cost-effective for AWS workloads | Less enterprise governance tooling | AWS-native organizations |

---

**DATA MIGRATION DESIGN**

**Migration Strategy Selection**:

| Strategy | Description | When to Use |
|---------|-------------|-------------|
| **Big Bang** | All data migrated in one cutover weekend | Smaller data volumes; tight timeline |
| **Phased by entity** | Migrate legal entities sequentially | Large multi-entity; staggered go-lives |
| **Phased by data type** | Migrate master data first, then transactions | Complex master data; cleansing needed |
| **Parallel run** | Old and new systems run simultaneously | High-risk; close/consolidation scenarios |

**Data Migration Workplan**:

| Phase | Activity | Duration | Owner |
|-------|----------|----------|-------|
| Data Profiling | Assess quality, volume, completeness of source data | Weeks 1–4 | Data Lead |
| Data Cleansing Rules | Define transformation rules for each data entity | Weeks 4–8 | Business + Data Lead |
| Migration Design | Source-to-target mapping for all data entities | Weeks 6–10 | SI Architect |
| Extract Development | Build extraction scripts from source systems | Weeks 10–16 | SI Developer |
| Transform Development | Build transformation and loading scripts | Weeks 14–20 | SI Developer |
| Mock Migration 1 | First full test load — identify gaps | Week 20 | SI + Business |
| Data Quality Review 1 | Business sign-off on data quality | Week 22 | Business Owner |
| Mock Migration 2 | Second full test load with corrections | Week 28 | SI + Business |
| Mock Migration 3 | Final dress rehearsal — go/no-go | Week 34 | All |
| Production Cutover | Live migration during cutover window | Go-live week | All |

**Migration Data Quality Validation Rules**:
- Record count: source total = target total ± 0
- Financial balance reconciliation: sum of source balances = sum of target balances (by period, entity, account)
- Master data completeness: 100% of active records migrated
- Orphan record detection: no transaction records without valid master data reference

---

**INTEGRATION TESTING STRATEGY**

**Testing Levels**:

| Level | Scope | Objective | Entry Criteria | Exit Criteria |
|-------|-------|-----------|---------------|--------------|
| Unit (Integration) | Single interface | Each interface passes basic data | Interface built | 100% of test cases pass |
| SIT | End-to-end scenarios crossing multiple systems | Business processes work across system boundaries | All unit tests passed | 95%+ critical scenarios pass |
| Performance | Load testing at 2× peak volume | System does not degrade under production load | SIT complete | No degradation at 2× peak |
| UAT | Business-led acceptance testing | Business confirms system meets requirements | SIT complete, training done | Business sign-off |
| Regression | Re-test after fixes | Fixes don't break previously passing scenarios | Post-defect fix | No regressions |
| Cutover simulation | Full cutover sequence dry-run | Cutover team can execute within planned window | All tests passed | Window achieved in dry-run |

**Defect Management**:
- P1 Critical: Blocks go-live — must resolve before cutover
- P2 High: Workaround available — must resolve within 5 days of go-live
- P3 Medium: Minor impact — scheduled for post-go-live sprint
- P4 Low: Cosmetic — backlog

---

**CUTOVER PLAN**

**Cutover Sequence**:

| Day | Activity | Owner | Duration | Dependency |
|-----|----------|-------|----------|------------|
| D-14 | Final data freeze communications | Programme Manager | 1 hour | — |
| D-7 | System freeze: no master data changes | IT Lead | — | Business agreement |
| D-3 | Mock migration 3 validation | Data Lead | 2 days | — |
| D-1 | Legacy system data extract (final) | SI Developer | 4 hours | System freeze |
| D-0 AM | Data load to target system | SI Developer | 6–8 hours | Extract complete |
| D-0 PM | Data validation: auto-reconciliation | SI + Business | 4 hours | Load complete |
| D-0 EOD | Go/No-Go decision | Steering Committee | 1 hour | Validation complete |
| D+1 | Go-live — system open to users | IT | — | Go/No-Go = Go |
| D+1 to D+30 | Hypercare: war room, floor walkers | SI + Change | 30 days | Go-live |

**Rollback Plan**:
- Define the rollback trigger criteria (what failure conditions require reverting to legacy)
- Rollback execution: re-enable legacy system; communicate delay; replan cutover
- Rollback window: must be executable within [X] hours of go-live

---

After generating, offer to: (1) produce a detailed integration specification document per interface, (2) create a test case library for integration testing, or (3) design the hypercare support model.
