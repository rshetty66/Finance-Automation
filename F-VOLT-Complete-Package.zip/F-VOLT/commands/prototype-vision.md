---
description: Create a rapid prototype to drive client vision in 15 minutes
allowed-tools: Read, Write
argument-hint: "[what to prototype and the client context]"
---

Create a rapid prototype as described in: $ARGUMENTS

Apply the 15-minute prototyping framework to build a compelling visual demonstration that drives client vision and accelerates decision-making.

Produce a rapid prototype with the following structure:

---

# RAPID PROTOTYPE: [Title]

**Purpose**: [What question this answers for the client]
**Audience**: [Who will see this]
**Time to Build**: [X minutes]

---

## The Prototype

[The actual visualization, mockup, diagram, or model]

---

## How to Present This

**Opening (15 seconds):**
"What you're seeing is..."

**Key Points (60 seconds):**
1. 
2. 
3. 

**The Ask (15 seconds):**
"This demonstrates how we would..."

---

## Client Reaction Guide

**If they say "This is exactly what we need":**
→ Move to detailed requirements and implementation planning

**If they say "Can you show us [X] instead?":**
→ Iterate the prototype; you've engaged them

**If they say "This seems complicated":**
→ Simplify; focus on the core value, not the mechanics

**If they say "What's the investment?":**
→ You have buying intent; transition to business case

---

## Next Steps

- [ ] Gather client feedback
- [ ] Refine based on reaction
- [ ] Create detailed version if positive response
- [ ] Prepare implementation approach

---

After delivering the prototype, offer to: (1) create variations based on feedback, (2) build a detailed version, (3) create complementary prototypes, or (4) develop the full implementation plan.
