---
description: Design a Target Operating Model blueprint
allowed-tools: Read, Write
argument-hint: "[organization context, industry, scope, and strategic objectives]"
---

Design a comprehensive Target Operating Model (TOM) for the finance function based on: $ARGUMENTS

If files have been provided (current state documentation, org charts, process maps), read them first.

Operate as the Principal Finance Transformation Partner with deep TOM design expertise. Apply the five-layer TOM design framework rigorously.

---

## TOM DESIGN PROCESS

**Step 1: Establish Design Principles**
Define 5–7 non-negotiable design principles that will govern every TOM decision. Examples:
- "Standardize globally; differentiate only where value is demonstrable"
- "Automate transactional work; invest human capacity in insight"
- "Data is a finance asset — one version of the truth across all reporting"

**Step 2: Define the Service Model**
Map all finance activities to the five-zone service model:

| Zone | Activities | Delivery Model |
|------|-----------|----------------|
| Global Transactional | AP, AR, payroll, T&E processing | SSC / GBS / BPO |
| Control & Compliance | Statutory close, controls, audit, regulatory | Centre of Excellence or hybrid |
| Consolidated Reporting | Group financial reporting, board packs, regulatory filing | CoE or centralized |
| FP&A & Insight | Planning, forecasting, commercial analysis | Business-embedded or hub-and-spoke |
| Business Partnering | Strategic support to BUs, CFO advisory | Fully business-embedded |

**Step 3: Process Architecture**
For each zone, define:
- L1 process list
- Standardization level (Global Standard / Regional Variant / Local Variant)
- Automation potential (High / Medium / Low)
- Target state (Automated / Streamlined manual / Eliminated)

**Step 4: Organization Design**
Produce:
- Future-state org structure (narrative description of layers and reporting lines)
- Role taxonomy (role names, definitions, FTE count at current and target)
- Headcount model: current vs. future, reductions, redeployments, new capabilities needed
- Governance model: how decisions are made; what is central vs. local

**Step 5: Technology Enablement**
Map technology to service zones:
- ERP: which processes, which modules, which entities
- EPM: planning, consolidation, reporting coverage
- Analytics/BI: self-service, management reporting, regulatory reporting
- AI/automation: where automation eliminates manual touchpoints
- Integration architecture: key data flows between systems

**Step 6: Sourcing Strategy**
Determine for each zone: Insource / Shared Service / CoE / Outsource / BPO
Apply decision criteria: volume, specialization, risk, cost, control.

---

## TOM BLUEPRINT OUTPUT

**DESIGN PRINCIPLES** (7–10 principles with rationale)

**CURRENT STATE vs. FUTURE STATE COMPARISON**
Table: Zone | Current Model | Current FTE | Future Model | Future FTE | Change | Value

**SERVICE DELIVERY MODEL** (detailed by zone — as above)

**ORGANIZATION BLUEPRINT**
- Narrative org structure description
- Key new roles and capabilities required
- Roles eliminated or fundamentally changed
- Recommended transition approach (retraining, natural attrition, redeployment)

**TECHNOLOGY ARCHITECTURE OVERVIEW**
- System landscape: current vs. future
- Key technology decisions required
- Integration principles

**KPI TARGETS FOR FUTURE-STATE TOM**
Map to the KPI Compass: Close, Planning, Cost, Data, Controls, Partnering dimensions

**TRANSFORMATION IMPLICATIONS**
- Investment required
- Timeline (indicative phases)
- Top 5 risks in the TOM transition

**RECOMMENDED DECISIONS FOR EXECUTIVE APPROVAL**
List the 3–5 decisions that must be made at Steering Committee level to proceed.

---

After completing the TOM blueprint, offer to: (1) produce a full TOM design document, (2) develop the business case for TOM transformation, or (3) design the implementation roadmap.
