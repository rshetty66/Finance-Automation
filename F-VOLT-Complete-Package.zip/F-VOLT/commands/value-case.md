---
description: Build a transformation business case with financial model
allowed-tools: Read, Write
argument-hint: "[programme scope, current state data, cost assumptions, or context]"
---

Build a comprehensive, board-ready business case for the transformation initiative described in: $ARGUMENTS

If files have been provided (current state data, cost models, benchmarks, programme scope), read them first.

Operate as the Principal Finance Transformation Advisor with deep business case and financial modelling expertise. This business case must be rigorous enough to pass CFO and Board scrutiny and compelling enough to secure investment approval.

---

## BUSINESS CASE STRUCTURE

**EXECUTIVE SUMMARY** (1 page)
- Investment ask: total cost over 3 years
- Expected return: NPV, IRR, payback period
- Strategic rationale: 2 sentences
- Confidence rating: High / Medium / Low (with brief rationale)
- Recommended decision: Approve / Approve with conditions / Defer / Do not proceed

---

**PART 1: PROBLEM DEFINITION**

**Current State Assessment**
- Key pain points (quantified wherever possible)
- Performance vs. industry benchmarks (use KPI Compass dimensions)
- Cost of current state: finance cost as % revenue, FTE cost, technology cost

**Cost of Inaction** (This is the most powerful section — make it uncomfortable)
- Year 1–3 cost of doing nothing (compounding cost, increasing risk, talent loss)
- Regulatory or compliance risk if not addressed
- Competitive disadvantage quantified

---

**PART 2: PROPOSED SOLUTION**

**Solution Description** (2–3 paragraphs — non-technical, outcome-focused)

**Scope Summary**
- In scope: processes, entities, geographies, systems
- Out of scope (explicit)
- Phasing: what delivers in Phase 1 vs. Phase 2

**Solution Options Considered**

| Option | Description | Investment | Expected Return | Risk | Recommendation |
|--------|-------------|-----------|----------------|------|----------------|
| A: Do nothing | Baseline | $0 | Negative (cost of inaction) | High | ❌ Not recommended |
| B: Tactical fixes | Point solutions | $X | Limited | Medium | ⚠️ Partial |
| C: Strategic transformation | Full programme | $Y | $Z NPV | Medium-Low | ✅ Recommended |

---

**PART 3: FINANCIAL MODEL**

**Investment Profile** (by year):

| Cost Category | Year 0 | Year 1 | Year 2 | Year 3 | Total |
|--------------|--------|--------|--------|--------|-------|
| Implementation (SI fees) | | | | | |
| Software licences | | | | | |
| Internal resource costs | | | | | |
| Change management & training | | | | | |
| Infrastructure / cloud | | | | | |
| Contingency (15%) | | | | | |
| **Total Investment** | | | | | |

**Benefits Profile** (by year — quantified):

| Benefit Category | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 | Notes |
|-----------------|--------|--------|--------|--------|--------|-------|
| FTE cost reduction | | | | | | Assumptions |
| Close cycle savings | | | | | | |
| IT TCO reduction | | | | | | |
| Audit/compliance cost avoided | | | | | | |
| Revenue enablement | | | | | | |
| Working capital improvement | | | | | | |
| **Total Benefits** | | | | | | |

**Financial Summary**:
- Net cash flow by year
- Cumulative cash flow (break-even year highlighted)
- NPV (at [X]% discount rate / WACC)
- IRR
- Payback period (months)

**Sensitivity Analysis**:

| Scenario | Assumption Change | NPV | Payback | IRR |
|----------|------------------|-----|---------|-----|
| Base case | As modelled | $X | Y months | Z% |
| Upside (+20% benefits, -10% cost) | | | | |
| Downside (-20% benefits, +20% cost) | | | | |
| Delay (programme starts 6 months late) | | | | |

---

**PART 4: NON-FINANCIAL BENEFITS**

Present qualitatively (but with proxy metrics where possible):
- Strategic positioning (digital finance capability, M&A readiness)
- Risk reduction (audit findings, regulatory penalty avoidance)
- Talent (retention of key finance talent; attracting next-generation FP&A capability)
- Regulatory alignment (DORA, IFRS 17, Basel IV readiness — as applicable)

---

**PART 5: RISK REGISTER**

| Risk | Probability | Impact | Net Risk Score | Mitigation |
|------|-------------|--------|---------------|-----------|
| | H/M/L | H/M/L | | |

Top 5 risks, each with a specific mitigation (not generic statements like "robust project management").

---

**PART 6: GOVERNANCE AND ACCOUNTABILITY**

- Recommended governance structure for programme delivery
- Investment approval process (who signs off, at what threshold)
- Benefits ownership: who is accountable for realizing each benefit category
- Review cadence: quarterly benefits review mechanism

---

**PART 7: RECOMMENDED DECISION AND NEXT STEPS**

- Clear recommendation
- Decision required by: [date]
- If approved: first 30-day actions
- Conditions for approval (if applicable)

---

After generating the business case, offer to: (1) build the financial model in Excel format, (2) create a board presentation version, or (3) produce a one-page executive summary.
