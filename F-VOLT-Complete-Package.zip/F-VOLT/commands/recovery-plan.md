---
description: Develop a recovery plan for a troubled program
allowed-tools: Read, Write
argument-hint: "[program situation, issues, and current status]"
---

Develop a comprehensive recovery plan for the troubled program described in: $ARGUMENTS

Apply the STOP-ASSESS-PLAN-ACT recovery framework to stabilize the situation and create a credible path back to success.

Produce a Program Recovery Plan with the following structure:

---

# Program Recovery Plan

**Program**: [Name]
**Current Status**: [Red/Yellow — describe situation]
**Recovery Plan Date**: [Today's date]
**Prepared By**: [Your name]

---

## Executive Summary

**Current Situation**: [2-3 sentences on what's wrong]

**Root Causes**: [Top 3]
1. 
2. 
3. 

**Recovery Approach**: [High-level strategy]

**Investment Required**: [Additional budget/time if any]

**Confidence Level**: [High/Medium/Low — with rationale]

---

## Situation Assessment

### Current State vs. Baseline

| Dimension | Baseline | Current | Variance | Severity |
|-----------|----------|---------|----------|----------|
| Schedule | | | | |
| Budget | | | | |
| Scope | | | | |
| Quality | | | | |
| Team Morale | | | | |
| Client Satisfaction | | | | |

### Warning Signs History
[Timeline of when issues first appeared and how they evolved]

### Stakeholder Impact
| Stakeholder | Current Sentiment | Key Concern | Relationship Status |
|-------------|-------------------|-------------|---------------------|
| Executive Sponsor | | | |
| Steering Committee | | | |
| End Users | | | |
| Project Team | | | |

---

## Root Cause Analysis

### Assessment Method
[Interviews, data analysis, document review, etc.]

### Findings by Category

**Scope**
- What was planned:
- What changed:
- Root cause:

**Schedule**
- Original timeline:
- Current forecast:
- Root cause:

**Resources**
- Planned team:
- Actual team:
- Root cause:

**Governance**
- Decisions pending:
- Escalations missed:
- Root cause:

**External Factors**
- Vendor issues:
- Dependencies:
- Root cause:

---

## Recovery Options Evaluated

| Option | Description | Pros | Cons | Investment | Confidence |
|--------|-------------|------|------|------------|------------|
| **A: Continue with Corrections** | | | | | |
| **B: Restructure and Replan** | | | | | |
| **C: Pause and Reset** | | | | | |
| **D: Scope Reduction** | | | | | |

### Recommended Option
**Option**: [A/B/C/D]

**Rationale**: [Why this option vs. others]

---

## Recovery Plan

### Immediate Actions (This Week)
| Action | Owner | Due Date | Success Criteria |
|--------|-------|----------|------------------|
| | | | |
| | | | |

### Short-Term (Next 30 Days)
| Action | Owner | Due Date | Success Criteria |
|--------|-------|----------|------------------|
| | | | |
| | | | |

### Medium-Term (Days 31-90)
| Action | Owner | Due Date | Success Criteria |
|--------|-------|----------|------------------|
| | | | |
| | | | |

### Recovery Milestones

| Milestone | Target Date | Success Criteria | Review Gate |
|-----------|-------------|------------------|-------------|
| Stabilization | | Issues contained, no further slippage | |
| Foundation Reset | | New baseline approved | |
| Momentum Building | | First wins delivered | |
| Back on Track | | Variance within tolerance | |

---

## Revised Baseline

### Updated Scope
**In Scope:**
- 

**Explicitly Out of Scope:**
- 

### Updated Timeline
- Original end date: 
- Revised end date: 
- Variance: 

### Updated Budget
- Original budget: 
- Spent to date: 
- Additional required: 
- Revised total: 

### Resource Adjustments
| Role | Original | Revised | Rationale |
|------|----------|---------|-----------|
| | | | |

---

## Enhanced Governance

### Immediate Governance Changes
1. [More frequent steering committee]
2. [Daily standups]
3. [Executive sponsor re-engagement]
4. [Enhanced RAID management]

### Escalation Protocol
| Trigger | Action | Timeline |
|---------|--------|----------|
| Any variance >5% | Immediate notification | Within 4 hours |
| Quality gate failure | Stop-work review | Within 24 hours |
| Resource issue | Replacement sourcing | Within 48 hours |

### Communication Plan
| Audience | Message | Channel | Frequency |
|----------|---------|---------|-----------|
| Steering Committee | | | Weekly |
| Client Sponsor | | | Weekly |
| Project Team | | | Daily |

---

## Risk Management

### Recovery-Specific Risks
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Loss of client confidence | | | |
| Team burnout/turnover | | | |
| Additional scope creep | | | |
| Vendor delivery issues | | | |

### Contingency Triggers
[Conditions that would trigger escalation to Option C or D]

---

## Success Criteria

### Recovery Success Metrics
| Metric | Current | Target | Measurement |
|--------|---------|--------|-------------|
| Schedule variance | | <5% | |
| Budget variance | | <5% | |
| Client satisfaction | | >4/5 | |
| Team morale | | Improved | |
| Defect rate | | <X% | |

### Exit Criteria (Recovery Complete)
- [ ] Variance within tolerance for 4 consecutive weeks
- [ ] Steering Committee confidence restored
- [ ] Team morale stabilized
- [ ] Quality standards consistently met
- [ ] Back to standard governance cadence

---

## Stakeholder Management

### Client Conversations

**Conversation 1: Executive Sponsor**
- Timing: 
- Key Messages: 
- Ask: 

**Conversation 2: Steering Committee**
- Timing: 
- Key Messages: 
- Ask: 

### Internal Communications
- Partner/Leadership notification: 
- Team communication: 
- HR/People (if resource changes): 

---

## Investment and Returns

### Additional Investment Required
| Category | Amount | Rationale |
|----------|--------|-----------|
| Additional resources | | |
| Extended timeline | | |
| External support | | |
| **Total** | | |

### Return on Recovery
[Why investing in recovery is better than alternatives]

---

## Next Steps

**Immediate (Today):**
1. 
2. 
3. 

**This Week:**
1. 
2. 
3. 

**Approval Required:**
- [ ] Sponsor approval for recovery plan
- [ ] Budget approval for additional investment
- [ ] Resource reallocation approval

---

After completing the recovery plan, offer to: (1) draft the stakeholder conversation scripts, (2) create a detailed mobilization plan for recovery, or (3) develop enhanced governance templates.
