---
description: Quality review a deliverable before client presentation
allowed-tools: Read, Write
argument-hint: "[path to deliverable or describe content]"
---

Conduct a comprehensive quality review of the deliverable: $ARGUMENTS

If a file path is provided, read the file first. Apply the Delivery Excellence quality framework to assess substance, structure, clarity, presentation, and accuracy.

Produce a Deliverable Quality Review with the following structure:

---

# Deliverable Quality Review

**Deliverable**: [Title/Name]
**Type**: [Assessment / Design / Strategy / Presentation / Other]
**Audience**: [Client level and context]
**Review Date**: [Today's date]
**Overall Rating**: [EXCELLENT / GOOD / NEEDS WORK / NOT READY]

---

## Executive Summary

**Verdict**: [Brief statement of overall quality]

**Top 3 Strengths:**
1. 
2. 
3. 

**Top 3 Issues:**
1. 
2. 
3. 

**Recommendation**: [APPROVE / APPROVE WITH CHANGES / REVISE BEFORE SUBMITTING]

---

## Dimension Scoring

| Dimension | Score (1-5) | Assessment | Priority Fixes |
|-----------|-------------|------------|----------------|
| **Substance** | | Insightful? Evidence-based? Actionable? | |
| **Structure** | | Clear flow? Easy navigation? | |
| **Clarity** | | Precise language? No ambiguity? | |
| **Presentation** | | Professional? Consistent? | |
| **Accuracy** | | Error-free? Consistent data? | |
| **Client-Ready** | | Tailored? Uses their language? | |

**Overall Score**: [XX/30]

---

## Detailed Findings

### Substance & Insights
**Strengths:**
- 

**Issues:**
- 

**Recommendations:**
- 

### Structure & Narrative
**Strengths:**
- 

**Issues:**
- 

**Recommendations:**
- 

### Clarity & Language
**Strengths:**
- 

**Issues:**
- 

**Recommendations:**
- 

### Presentation & Visuals
**Strengths:**
- 

**Issues:**
- 

**Recommendations:**
- 

### Accuracy & Consistency
**Issues Found:**
- [ ] 
- [ ] 
- [ ] 

---

## Client-Specific Gaps

| Gap | Impact | Fix Required |
|-----|--------|--------------|
| | | |

---

## Priority Revisions

### Must Fix (Before Delivery)
- [ ] 
- [ ] 
- [ ] 

### Should Fix (If Time Permits)
- [ ] 
- [ ] 

### Nice to Have (Future Enhancement)
- [ ] 

---

## Executive Summary Assessment

| Criterion | Pass/Fail | Notes |
|-----------|-----------|-------|
| Captures essence in 60 seconds | | |
| Leads with recommendation | | |
| Client-specific throughout | | |
| No jargon or acronyms | | |
| Clear next step | | |

---

## Comparison to Standards

| Element | Standard | This Deliverable | Gap |
|---------|----------|------------------|-----|
| Executive Summary | 1 page max | | |
| Supporting detail | Evidence-based | | |
| Recommendations | Specific, actionable | | |
| Risks | Top 3 with mitigation | | |
| Next steps | Owners and dates | | |

---

## Action Plan

**Estimated Rework Time**: [X hours]

**Critical Path Items:**
1. [Item that must be done first]
2. 
3. 

**Owner**: [Who makes the fixes]
**Target Completion**: [Date/time]
**Final Review**: [Who signs off]

---

After completing the review, offer to: (1) provide specific rewrite suggestions for weak sections, (2) create an executive summary if missing, or (3) help prioritize fixes based on client impact.
