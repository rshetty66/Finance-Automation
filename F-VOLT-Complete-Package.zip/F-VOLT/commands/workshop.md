---
description: Design a workshop agenda, facilitation guide, and materials
allowed-tools: Read, Write
argument-hint: "[workshop type, audience, duration, objectives, or context]"
---

Design a comprehensive, facilitation-ready workshop based on: $ARGUMENTS

If files have been provided (client context, programme documentation, previous outputs), read them first.

Operate as the Principal Finance Transformation advisor and expert facilitator with experience running executive workshops for CFOs, CIOs, Boards, and large team sessions.

Apply the Sales Storytelling and Creative Design skills: design a workshop that is intellectually stimulating, visually engaging, and produces clear decisions.

---

## WORKSHOP DESIGN

**WORKSHOP BRIEF**

Determine and confirm:
- Workshop type (select most appropriate, or combine):
  - **Discovery / Diagnostic**: Understanding current state, pain points, aspirations
  - **Vision & Design Thinking**: Co-creating the future-state vision
  - **Prioritization / Decision**: Evaluating options and making decisions
  - **Solution Design**: Designing a specific solution or architecture
  - **Change Readiness**: Assessing and building readiness for change
  - **Value & Business Case**: Quantifying opportunity and building investment case
  - **Lessons Learned / Retrospective**: Programme review and improvement
  - **Executive Alignment**: Building senior leadership alignment and mandate
  - **Innovation / AI Strategy**: Ideating and prioritizing AI/digital opportunities

- Audience: Who is in the room? (titles, functions, knowledge level, political dynamics)
- Duration: Half-day / Full day / 2-day workshop
- Location: In-person / Virtual / Hybrid
- Desired outcomes: What must be true at the end for this workshop to be successful?
- Pre-work required: What do participants need to prepare or review in advance?

---

## WORKSHOP AGENDA

Design a detailed, minute-by-minute agenda. Include:

| Time | Session | Type | Facilitation Notes | Outputs |
|------|---------|------|------------------|---------|
| 08:30–09:00 | Registration & coffee | Social | Networking; relationship-building | — |
| 09:00–09:15 | Welcome and context | Presentation | Executive sponsor sets tone; WHY we're here | Shared context |
| 09:15–09:30 | Workshop goals and ground rules | Facilitated | Agree outcomes and working norms | Aligned expectations |

Design the main workshop sessions with energy flow in mind:
- **Morning** (high energy): Strategic framing, problem definition, diagnosis
- **Mid-morning** (analytical): Data review, benchmark presentation, gap analysis
- **Late morning** (creative): Future-state ideation, design exercises
- **Lunch**: Relationship and trust-building
- **Early afternoon** (collaborative): Prioritization exercises, option evaluation
- **Mid-afternoon** (decisive): Decision-making, action planning
- **Close**: Commitments, next steps, energizing close

---

## FACILITATION GUIDE

For each session, provide:

**SESSION: [Name]**
- **Objective**: What this session must achieve
- **Duration**: [X] minutes
- **Format**: [Presentation / Discussion / Exercise / Voting / Breakout / Gallery walk]
- **Materials needed**: [Slides / Whiteboard / Sticky notes / Worksheets / Polling tool]
- **Facilitation script** (key questions to ask):
  - Opening question (engage all): "..."
  - Depth question (provoke thinking): "..."
  - Challenge question (test assumptions): "..."
  - Synthesis question (build to conclusion): "..."
- **Common traps and how to handle them**:
  - If the group goes off topic: ...
  - If one person dominates: ...
  - If the energy drops: ...
  - If there's unresolvable conflict: ...
- **Output**: What should exist on paper/board/screen at session end

---

## WORKSHOP EXERCISES

Design 3–5 specific, engaging exercises. For each:

**EXERCISE: [Name]**
- **Purpose**: What insight or decision this exercise produces
- **Duration**: [X] minutes
- **Format**: Individual → Pair → Group (builds from reflection to consensus)
- **Instructions** (participant-facing):
  1. Step 1 (time)
  2. Step 2 (time)
  3. Step 3 (time)
- **Facilitator debrief questions**:
  - ...

**Recommended exercise types by workshop goal**:

| Goal | Exercise |
|------|---------|
| Surface pain points | Empathy mapping, "Day in the life" journey maps |
| Prioritize opportunities | Impact/effort matrix, MoSCoW voting (dot voting) |
| Co-create future state | "How Might We?" brainstorm, future-state newspaper front page |
| Build consensus | "Fist of five" consensus check, anonymous polling (Mentimeter) |
| Make decisions | Decision matrix scoring, force field analysis |
| Identify risks | Pre-mortem: "It's 18 months from now and this failed — what happened?" |
| Assess readiness | ADKAR pulse check, stoplight assessment |

---

## POLLING AND REAL-TIME ENGAGEMENT

Design 3–5 polling questions for live audience response (Mentimeter/Slido):

1. **Opening diagnostic** (establish baseline, make the problem visible):
   Example: "How would you rate our current close process? (1=broken, 5=world-class)"

2. **Priority setting**:
   Example: "Which finance capability is most critical to improve in the next 18 months? (Select top 2)"

3. **Risk identification**:
   Example: "What is the biggest risk to our transformation programme?"

4. **Consensus check**:
   Example: "On a scale of 1–10, how confident are you in the transformation approach presented today?"

5. **Commitment close**:
   Example: "What is the one thing you personally commit to do differently as a result of today?"

---

## PRE-WORK PACKAGE

Design a pre-work brief for participants (to be sent 5 business days in advance):
- Workshop objectives and agenda headline
- 3 questions to reflect on before arriving
- 1–2 page reading: relevant context, benchmark data, or case study
- 15-minute pre-work exercise (e.g., "Map your 3 biggest finance pain points and estimated cost")

---

## WORKSHOP OUTPUTS TEMPLATE

Design a single-page output template to complete during the workshop:
- Key decisions made (list)
- Key assumptions agreed (list)
- Priorities ranked (table)
- Action items: Owner | Action | Due Date | Success Metric
- Open issues / parking lot

---

## POST-WORKSHOP FOLLOW-UP

Within 24 hours:
- Workshop summary document (decisions, priorities, actions)
- Voting results with commentary
- Next steps confirmation email from executive sponsor

Within 5 business days:
- Full workshop output document
- Updated programme artefacts reflecting workshop decisions
- Invitation for next workshop or action review

---

After generating the workshop design, offer to: (1) create the slide deck for the workshop, (2) build the polling questions in a copy-paste format for Mentimeter/Slido, or (3) produce the pre-work package as a standalone document.
