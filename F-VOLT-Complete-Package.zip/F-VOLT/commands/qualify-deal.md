---
description: Qualify a sales opportunity using MEDDIC framework
allowed-tools: Read, Write
argument-hint: "[deal description or RFP summary]"
---

Qualify the sales opportunity described in: $ARGUMENTS

Apply the MEDDIC/MEDDPICC qualification framework to assess deal viability and identify gaps that need addressing before investing significant proposal effort.

Produce a Deal Qualification Assessment with the following structure:

---

# Deal Qualification Assessment

**Opportunity**: [Brief description]
**Date**: [Today's date]
**Overall Verdict**: [PROCEED / PROCEED WITH CAUTION / QUALIFY FURTHER / PASS]
**Confidence**: [High / Medium / Low]

---

## MEDDIC Scorecard

| Element | Status | Evidence | Gaps/Risks | Action Required |
|---------|--------|----------|------------|-----------------|
| **Metrics** | Strong/Partial/Weak | | | |
| **Economic Buyer** | Met/Identified/Unknown | | | |
| **Decision Criteria** | Clear/Partial/Vague | | | |
| **Decision Process** | Defined/Partial/Unknown | | | |
| **Identify Pain** | Quantified/Described/Implied | | | |
| **Champion** | Strong/Weak/None | | | |
| **Competition** | Known/Partial/Unknown | | | |

**Score**: [X/7 elements qualified]

---

## Deal Attractiveness

| Factor | Assessment | Score |
|--------|------------|-------|
| Deal size | | 1-5 |
| Strategic value | | 1-5 |
| Win probability | | 1-5 |
| Delivery risk | | 1-5 |
| Profitability | | 1-5 |
| Relationship value | | 1-5 |

**Overall Attractiveness**: [XX/30]

---

## Key Strengths
1. 
2. 
3. 

## Critical Gaps & Risks
1. 
2. 
3. 

## Recommended Actions

**Before Proposal:**
- [ ] Action 1
- [ ] Action 2

**During Proposal:**
- [ ] Action 1
- [ ] Action 2

## Go/No-Go Recommendation

**Recommendation**: [GO / NO-GO / CONDITIONAL]

**Rationale**: [2-3 sentences]

**Conditions**: [If conditional, what must be true to proceed]

---

After completing the assessment, offer to: (1) create a win strategy, (2) develop a pursuit plan, or (3) draft proposal content.
