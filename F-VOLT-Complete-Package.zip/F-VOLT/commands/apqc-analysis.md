---
description: Conduct APQC benchmark analysis for current state or target setting
allowed-tools: Read, Write
argument-hint: "[process area, current metrics, and industry context]"
---

Conduct an APQC benchmark analysis for the context provided in: $ARGUMENTS

Leverage APQC's Process Classification Framework (PCF) and benchmarking data to assess performance, identify gaps, and set targets. The user has APQC login access to research content.

Produce an APQC Benchmark Analysis with the following structure:

---

# APQC Benchmark Analysis

**Scope**: [Process area in scope]
**Industry**: [Client industry]
**Revenue**: [Client revenue]
**Analysis Date**: [Today's date]

---

## Executive Summary

**Current State Performance**: [Summary of key metrics]

**Benchmark Comparison**: 
- Above median in: [areas]
- Below median in: [areas]
- Key gaps: [quantified]

**Opportunity**: [Estimated annual value]

---

## Current State Metrics

| Metric | Value | Calculation Method |
|--------|-------|-------------------|
| | | |

---

## APQC Benchmark Comparison

### Overall Finance Function
| Metric | Client | Top 25% | Median | Bottom 25% | Client %ile |
|--------|--------|---------|--------|------------|-------------|
| Cost as % of Revenue | | | | | |
| FTEs per $1B Revenue | | | | | |

### Record-to-Report
| Metric | Client | Top 25% | Median | Bottom 25% | Client %ile |
|--------|--------|---------|--------|------------|-------------|
| Days to Close | | 4 | 6.5 | 10 | |

### [Other Process Areas]
[Table for P2P, O2C, etc.]

---

## Gap Analysis

| Metric | Current | Median | Gap | Annual Value |
|--------|---------|--------|-----|--------------|
| | | | | |

---

## Target Recommendations

| Metric | Current | Phase 1 | Phase 2 | Target Basis |
|--------|---------|---------|---------|--------------|
| | | | | |

---

## Industry Context

**Industry Segment**: [Specific segment]
**Comparison to Peers**: [Above/below/at median]
**Best Practice Insights**: [From APQC research]

---

## PCF Process Mapping

| Client Process | PCF Code | PCF Process Name |
|----------------|----------|------------------|
| | | |

---

## Recommendations

1. 
2. 
3. 

---

After completing the analysis, offer to: (1) incorporate into business case, (2) design target operating model using PCF, (3) create executive presentation with benchmarks, or (4) develop detailed transformation roadmap with milestone targets.
