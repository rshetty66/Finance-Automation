---
description: Develop a win strategy for a qualified opportunity
allowed-tools: Read, Write
argument-hint: "[client name, deal context, and key competitors]"
---

Develop a comprehensive win strategy for the opportunity described in: $ARGUMENTS

Apply proven win strategy frameworks to create a clear, actionable plan for winning this deal.

Produce a Win Strategy document with the following structure:

---

# Win Strategy: [Client Name]

**Opportunity**: [Brief description]
**Estimated Value**: 
**Decision Timeline**: 
**Competitors**: 
**Strategy Date**: [Today's date]

---

## Win Theme

[One sentence that captures why we should win and why now]

Example: "We will win by demonstrating proven Financial Services EPM expertise with a faster, lower-risk implementation path that delivers measurable ROI within 12 months."

---

## Client Context

### Business Situation
- [Key facts about client's business]
- [Strategic priorities]
- [Recent events or pressures]

### Decision Makers
| Role | Name (if known) | Priority | Influence | Our Relationship |
|------|-----------------|----------|-----------|------------------|
| Economic Buyer | | | | |
| Technical Evaluator | | | | |
| User Champion | | | | |
| Procurement | | | | |

### Key Success Criteria
1. [Must-have from client's perspective]
2. 
3. 

---

## Competitive Landscape

| Competitor | Strengths | Weaknesses | Their Likely Strategy | Counter-Strategy |
|------------|-----------|------------|----------------------|------------------|
| Competitor A | | | | |
| Competitor B | | | | |

### Our Key Differentiators
1. **[Differentiator 1]**: [Why it matters to this client]
2. **[Differentiator 2]**: [Why it matters to this client]
3. **[Differentiator 3]**: [Why it matters to this client]

---

## Win Strategy

### Our Winning Approach
[3-5 paragraphs describing our strategy: how we position, what we emphasize, how we neutralize competition, how we build relationships]

### Key Messages by Audience

**For Economic Buyer:**
- 
- 

**For Technical Evaluators:**
- 
- 

**For End Users:**
- 
- 

---

## Risk Mitigation

| Client Concern | How We'll Address It | Proof Points |
|----------------|---------------------|--------------|
| [Concern 1] | | |
| [Concern 2] | | |
| [Concern 3] | | |

---

## Tactical Plan

### Pre-Proposal Phase
| Activity | Owner | Due Date | Purpose |
|----------|-------|----------|---------|
| | | | |

### Proposal Phase
| Activity | Owner | Due Date | Purpose |
|----------|-------|----------|---------|
| | | | |

### Presentation/Oral Phase
| Activity | Owner | Due Date | Purpose |
|----------|-------|----------|---------|
| | | | |

### Negotiation Phase
| Activity | Owner | Due Date | Purpose |
|----------|-------|----------|---------|
| | | | |

---

## Resource Requirements

| Resource | Time Required | Timing |
|----------|--------------|--------|
| Partner time | | |
| Solution architect | | |
| Proposal writer | | |
| Pricing support | | |

---

## Success Metrics

- [ ] [Criteria for knowing we're on track]
- [ ] 
- [ ] 

---

After completing the win strategy, offer to: (1) create a proposal outline, (2) develop key messaging, or (3) prepare for specific presentation scenarios.
