---
description: Create stunning visual designs, dashboards, or interactive GUIs
allowed-tools: Read, Write
argument-hint: "[what to design and context/audience]"
---

Create stunning visual designs as described in: $ARGUMENTS

Apply creative design best practices to create visuals that are beautiful, functional, and appropriate for the audience (executive, technical, or general).

Produce a design deliverable with the following structure:

---

# DESIGN: [Title]

**Type**: [Dashboard / Presentation / Interactive GUI / Other]
**Audience**: [Executive / Technical / General]
**Purpose**: [What this design should achieve]
**Date**: [Today's date]

---

## Visual Strategy

### Design Concept
[High-level creative concept and approach]

### Mood & Tone
- **Feeling**: [Professional / Energetic / Calm / Bold]
- **Style**: [Modern / Classic / Minimal / Rich]
- **Inspiration**: [Reference points]

### Key Visual Elements
- **Hero Element**: [The focal point]
- **Color Approach**: [Palette direction]
- **Typography Style**: [Font personality]
- **Imagery**: [Photo, illustration, abstract]

---

## Design System

### Color Palette
| Role | Color | Hex | Usage |
|------|-------|-----|-------|
| Primary | | | Main elements |
| Secondary | | | Supporting elements |
| Accent | | | CTAs, highlights |
| Background | | | Canvas |
| Surface | | | Cards, containers |
| Text Primary | | | Main text |
| Text Secondary | | | Supporting text |
| Success | | | Positive indicators |
| Warning | | | Alerts |
| Danger | | | Errors |

### Typography
| Element | Font | Size | Weight | Line Height |
|---------|------|------|--------|-------------|
| Hero | | 48-64px | 700 | 1.1 |
| H1 | | 36-48px | 700 | 1.2 |
| H2 | | 28-36px | 600 | 1.3 |
| H3 | | 22-28px | 600 | 1.4 |
| Body Large | | 18-20px | 400 | 1.6 |
| Body | | 16px | 400 | 1.6 |
| Data/Numbers | | 24-48px | 700 | 1 |

### Spacing System
- xs: 4px
- sm: 8px
- md: 16px
- lg: 24px
- xl: 32px
- 2xl: 48px

---

## Visual Design

### Layout Structure
```
[ASCII or text description of layout]
```

### Key Screens/Components

**1. [Component Name]**
```
[Visual representation or detailed description]
```
**Design Notes**: [Rationale, interactions]

**2. [Component Name]**
```
[Visual representation or detailed description]
```
**Design Notes**: [Rationale, interactions]

---

## Interaction Design

### Navigation Patterns
- [How users move through the experience]

### Micro-interactions
| Element | Trigger | Effect | Purpose |
|---------|---------|--------|---------|
| | | | |

### State Definitions
- **Default**: 
- **Hover**: 
- **Active**: 
- **Disabled**: 
- **Loading**: 
- **Success**: 
- **Error**: 

---

## Assets & Specifications

### Iconography
- **Style**: [Line, filled, duotone]
- **Library**: [Feather, Heroicons, custom]
- **Size Scale**: [16px, 24px, 48px]

### Imagery Guidelines
- **Photography Style**: 
- **Illustration Style**: 
- **Abstract Elements**: 

### Data Visualization
- **Chart Types**: 
- **Color Coding**: 
- **Interaction**: 

---

## Responsive Considerations

| Breakpoint | Layout Changes |
|------------|----------------|
| Desktop (1200px+) | |
| Tablet (768-1199px) | |
| Mobile (<768px) | |

---

## Accessibility Notes
- Contrast ratios
- Keyboard navigation
- Screen reader support
- Focus indicators

---

## Implementation Notes

### Technical Recommendations
- **Framework**: [React, Vue, HTML/CSS]
- **Styling**: [Tailwind, styled-components]
- **Animation**: [CSS, Framer Motion, Lottie]
- **Charts**: [D3, Chart.js, Recharts]

### Design Handoff
- [Link to Figma/design files]
- [Asset exports needed]
- [Animation specifications]

---

After delivering the design, offer to: (1) create a clickable prototype, (2) develop detailed specifications, (3) design additional screens/states, or (4) create an animation guide.
