---
description: Run a finance transformation maturity assessment
allowed-tools: Read, Write
argument-hint: "[organization context, industry, or upload assessment data]"
---

Conduct a comprehensive Finance Transformation Maturity Assessment based on: $ARGUMENTS

If a file has been provided (interview notes, process documentation, survey results), read it first.

You are operating as a Principal Finance Transformation advisor. Apply the maturity framework below across all dimensions. If the user has not provided full data, generate a diagnostic interview guide AND assess based on what is known — making explicit which dimensions have been assessed vs. assumed.

---

## ASSESSMENT FRAMEWORK

Score each dimension on a 1–5 scale:
- **1 — Ad Hoc**: Inconsistent, manual, high risk
- **2 — Defined**: Documented but not consistently applied
- **3 — Managed**: Consistently applied, measured
- **4 — Optimized**: Continuously improving, benchmarked
- **5 — Leading**: Best-in-class, technology-enabled, predictive

---

## DIMENSIONS TO ASSESS

**1. Close and Consolidation**
- Close cycle time and reliability
- Manual journal entry volume and risk
- Intercompany reconciliation maturity
- Balance sheet substantiation quality
- Use of automation and AI

**2. Planning and Forecasting**
- Forecasting accuracy and methodology
- Planning cycle time and agility
- Driver-based vs. historical planning
- Scenario planning capability
- Integration of operational and financial planning

**3. Finance Technology**
- ERP fitness for purpose and version currency
- EPM capability (planning, consolidation, reporting)
- Data warehouse/lakehouse maturity
- Analytics and BI self-service capability
- AI/ML adoption in finance

**4. Operating Model and Organization**
- Finance TOM design (centralized/decentralized/GBS)
- Role clarity and span of control
- Finance business partnering depth
- Talent capabilities vs. future need
- Finance cost efficiency (vs. benchmarks)

**5. Data and Reporting**
- Single source of truth maturity
- Data quality management
- Report rationalization (number of reports, sources)
- Insight vs. information ratio in reporting
- Regulatory reporting capability

**6. Controls and Compliance**
- Internal control strength (SOX/equivalent)
- Audit findings trend
- Regulatory submission on-time rate
- Three lines of defense clarity
- AI/model governance maturity

**7. Change Readiness and Culture**
- Leadership commitment to transformation
- Change management capability
- Digital adoption culture
- Finance team resilience and adaptability

---

## OUTPUT FORMAT

**EXECUTIVE SUMMARY**
- Overall maturity score (1–5) with narrative
- Top 3 strengths
- Top 3 critical gaps requiring immediate action

**DIMENSION SCORECARD**
Present as a table: Dimension | Current Score | Target Score (18 months) | Gap | Priority

**MATURITY RADAR CHART DESCRIPTION**
Describe the shape of the radar chart (which dimensions are high/low) in narrative form.

**KEY FINDINGS** (5–7 findings, each structured as: Finding → Evidence → Implication → Recommended Action)

**BENCHMARK COMPARISON**
Compare scores to industry benchmarks where data is available. Flag where the organization is below peer median.

**TRANSFORMATION OPPORTUNITY SIZING**
Estimate the addressable value from closing identified gaps (FTE cost, close cycle, forecast accuracy, compliance cost).

**RECOMMENDED TRANSFORMATION PRIORITIES**
Rank top 5 transformation initiatives by: Value × Urgency ÷ Complexity

**IMMEDIATE NEXT STEPS** (next 30 days)

---

After completing the assessment, offer to: (1) produce a detailed diagnostic report, (2) generate a transformation roadmap based on findings, or (3) create a board presentation summarizing results.
