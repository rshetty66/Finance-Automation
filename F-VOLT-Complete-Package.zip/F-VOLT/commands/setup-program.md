---
description: Set up program governance and initiate a new engagement
allowed-tools: Read, Write
argument-hint: "[program description, scope, timeline, and team size]"
---

Design the program governance and setup for the engagement described in: $ARGUMENTS

Apply program management best practices to establish a robust governance structure that sets the program up for success.

Produce a Program Setup Guide with the following structure:

---

# Program Setup Guide

**Program**: [Name]
**Client**: 
**Duration**: 
**Team Size**: 
**Budget Range**: 
**Setup Date**: [Today's date]

---

## Recommended Governance Structure

### Governance Bodies

**Steering Committee**
- **Frequency**: [Bi-weekly / Monthly]
- **Membership**: 
  - Client: [CFO / CIO / Executive Sponsor]
  - Firm: [Partner / Delivery Lead]
- **Purpose**: Strategic oversight, major decisions, issue escalation
- **Cadence**: [Day of week], [Time], [Location/Virtual]

**Program Management Office (PMO)**
- **PMO Lead**: [Role/responsibility]
- **Support**: [Analysts/Coordinators]
- **Responsibilities**:
  - Status reporting and tracking
  - RAID management
  - Financial tracking
  - Dependency management

**Workstream Structure**
| Workstream | Lead | Key Deliverables |
|------------|------|------------------|
| | | |
| | | |

**Review Boards** (as needed)
- Architecture Review Board
- Change Management Board
- Data Governance Board

---

## Key Documents to Create

### Week 1-2: Foundation
- [ ] **Program Charter** — Mandate, scope, governance, budget
- [ ] **Team Onboarding Pack** — Contacts, tools, ways of working
- [ ] **Stakeholder Map** — Power/interest matrix, engagement plan
- [ ] **Communication Plan** — Cadence, channels, audiences

### Week 3-4: Planning
- [ ] **Integrated Master Schedule** — Phases, milestones, dependencies
- [ ] **RAID Log Template** — Risks, assumptions, issues, dependencies
- [ ] **Quality Standards** — Review gates, acceptance criteria
- [ ] **Financial Tracking Model** — Budget, actuals, forecast

### Week 5-8: Baseline
- [ ] **Current State Assessment Report**
- [ ] **Baseline Metrics Report**
- [ ] **Gap Analysis**
- [ ] **Updated Business Case** (with actuals)

---

## First 90 Days Plan

### Days 1-14: Mobilization
**Week 1:**
- Confirm team assignments and onboard
- Set up working space and collaboration tools
- Conduct kickoff meeting (internal and client)
- Begin stakeholder mapping

**Week 2:**
- Complete team onboarding
- Establish document repositories
- Draft Program Charter
- Identify quick win opportunities

### Days 15-30: Governance & Planning
**Week 3:**
- Finalize and approve Program Charter
- Hold first Steering Committee
- Establish RAID log and reporting cadence
- Create integrated master schedule

**Week 4:**
- Define quality standards and review gates
- Set up financial tracking
- Confirm workstream leads and responsibilities
- Begin discovery activities

### Days 31-60: Discovery & Baseline
**Weeks 5-8:**
- Execute current state assessment
- Conduct stakeholder interviews
- Document processes and pain points
- Validate scope and assumptions
- Establish baseline metrics

### Days 61-90: Design Foundation
**Weeks 9-12:**
- Develop TOM design principles
- Confirm solution architecture direction
- Refine business case with actual data
- Build change management foundation
- Prepare for Design Phase tollgate

---

## Key Roles & Responsibilities

### Client-Side
| Role | Responsibilities | Ideal Profile |
|------|------------------|---------------|
| Executive Sponsor | Champion, unblock, resource allocation | C-level executive with budget authority |
| Product Owner | Scope decisions, requirements sign-off | Business leader with process expertise |
| Project Manager | Coordination, status, issue management | Experienced PM with authority |
| SMEs | Subject matter expertise, testing | Deep process/system knowledge |

### Firm-Side
| Role | Responsibilities | Time Commitment |
|------|------------------|-----------------|
| Partner/Exec Sponsor | Relationship, escalation, commercials | 20% |
| Delivery Lead | Day-to-day leadership, quality | 100% |
| Workstream Leads | Stream delivery, team management | 100% |
| PMO Lead | Governance, tracking, reporting | 100% |

---

## Risk Management Framework

### Escalation Thresholds
| Threshold | Action | Who Notifies |
|-----------|--------|--------------|
| Budget variance >5% | Flag in weekly status | PMO Lead |
| Budget variance >10% | Escalate to Steering Committee | Delivery Lead |
| Schedule slippage >1 week | Recovery plan in status | Workstream Lead |
| Schedule slippage >2 weeks | Steering Committee decision | Delivery Lead |
| Quality gate failure | Immediate review | Workstream Lead |
| Resource shortfall | Reallocation plan | Delivery Lead |

### Early Warning Indicators
- Steering Committee attendance declining
- Key client sponsor missing meetings
- Change requests increasing
- Defect rates rising
- Team overtime becoming routine

---

## Success Metrics

### Program Health Indicators
| Metric | Target | Measurement |
|--------|--------|-------------|
| Schedule variance | <5% | Planned vs actual milestones |
| Budget variance | <5% | Planned vs actual spend |
| RAID closure rate | >80% | Issues closed within SLA |
| Steering satisfaction | >4/5 | Post-meeting survey |
| Team utilization | 85-95% | Billable vs available |

### Quality Indicators
| Metric | Target | Measurement |
|--------|--------|-------------|
| Deliverable acceptance | First time | Rejection rate |
| Review findings | <5 major | Per design review |
| Rework rate | <10% | Effort on fixes vs build |

---

## Immediate Next Steps

1. [Specific action with owner and date]
2. 
3. 
4. 
5. 

---

After completing the program setup guide, offer to: (1) draft the Program Charter, (2) create a detailed mobilization checklist, or (3) design the Steering Committee presentation template.
