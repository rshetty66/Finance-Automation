---
description: Build an ERP/EPM selection framework and recommendation
allowed-tools: Read, Write
argument-hint: "[organization context, current systems, requirements, or RFP details]"
---

Conduct a rigorous ERP and/or EPM selection process and deliver a recommendation based on: $ARGUMENTS

If files have been provided (RFP documents, vendor responses, requirements documents, current state assessments), read them first.

Operate as the Principal Finance Technology Advisor with deep ERP/EPM selection expertise across Oracle, SAP, Workday, OneStream, Anaplan, and the broader vendor landscape.

---

## SELECTION PROCESS OUTPUT

**STEP 1: Requirements Synthesis**

Organize requirements into five categories:
1. **Functional requirements** (finance processes: close, planning, reporting, consolidation, reconciliation, etc.)
2. **Integration requirements** (source systems, data flows, middleware, APIs)
3. **Reporting requirements** (statutory, management, regulatory, self-service)
4. **Non-functional requirements** (performance, scalability, security, compliance, availability SLAs)
5. **Organizational constraints** (budget, timeline, internal capability, change tolerance)

Assign each requirement: **Must Have (M)** / **Should Have (S)** / **Nice to Have (N)**

---

**STEP 2: Vendor Longlist → Shortlist**

From the requirements, build the appropriate vendor longlist. For each vendor on the shortlist, provide:
- Product overview (2–3 sentences)
- Fit for stated requirements (High/Medium/Low with brief rationale)
- Industry references (same sector)
- Deployment model (cloud SaaS / private cloud / hybrid)
- Indicative total cost of ownership (5-year, including license + implementation + support)
- Key strengths
- Known limitations or risks

---

**STEP 3: Weighted Scoring Matrix**

Build a scoring matrix. Recommend weights based on context (adjust weights to stated priorities):

| Criterion | Weight | Vendor A | Vendor B | Vendor C |
|-----------|--------|----------|----------|----------|
| Functional fit (finance) | 25% | | | |
| Total Cost of Ownership (5yr) | 20% | | | |
| Implementation risk | 15% | | | |
| Vendor viability & roadmap | 10% | | | |
| Integration capability | 10% | | | |
| Regulatory / compliance depth | 10% | | | |
| Industry references | 5% | | | |
| UX and adoption potential | 5% | | | |
| **Weighted Total** | 100% | | | |

Score each vendor 1–5 per criterion. Calculate weighted score.

---

**STEP 4: Deep-Dive Analysis — Top 2 Vendors**

For the top two scoring vendors, provide:
- Gap analysis: requirements not met out-of-the-box and remediation approach (config / customization / third-party add-on / workaround)
- Implementation risk profile: typical implementation duration, common failure modes, reference client outcomes
- Total cost of ownership breakdown (Year 1 costs vs. Year 2–5 run costs)
- Contract / licensing considerations (subscription vs. perpetual, user-based vs. module-based)
- Implementation partner ecosystem quality

---

**STEP 5: Recommendation**

State the recommendation clearly. Structure as:
- **Recommended vendor** (and why, in 3 bullet points)
- **Runner-up** (and the scenario in which it would be preferred instead)
- **Decision risks**: What could change this recommendation (e.g., vendor pricing, integration complexity revealed in PoC)
- **Recommended next steps**: RFP → Proof of Concept → Contract → Implementation kickoff with timing

---

**STEP 6: PoC / Proof of Concept Design** (if applicable)

Define the PoC scope:
- PoC scenarios to test (cover the top 5 highest-risk requirements)
- Success criteria (what must the system demonstrate to pass)
- Duration (2–4 weeks recommended)
- Evaluation team composition

---

**STEP 7: Implementation Readiness Assessment**

Before the recommendation is finalized, flag organizational readiness:
- Data readiness (chart of accounts, master data quality, cleansing effort)
- Resource readiness (internal team, SI partner need, budget availability)
- Change readiness (leadership commitment, business team availability, change tolerance)
- Timeline feasibility (go-live target vs. realistic delivery based on scope)

---

After completing the selection framework, offer to: (1) build a full RFP document, (2) create a board presentation with the recommendation, or (3) design the implementation roadmap.
