---
description: Build a phased implementation roadmap with milestones and resourcing
allowed-tools: Read, Write
argument-hint: "[programme scope, timeline, constraints, or TOM/solution design]"
---

Build a comprehensive, execution-ready implementation roadmap based on: $ARGUMENTS

If files have been provided (TOM design, business case, solution architecture, or project scope), read them first.

Operate as the Principal Finance Transformation delivery expert with deep experience designing and governing large-scale transformation programmes.

Produce a roadmap that is:
- Sprint-level detailed for the first 90 days
- Phase-level detailed for months 4–18
- Strategic horizon for years 2–3

---

## ROADMAP STRUCTURE

**ROADMAP PRINCIPLES** (5 design principles that governed sequencing decisions)
Examples:
- "Quick wins in the first 90 days to build momentum and prove value"
- "Data foundations before analytics — never build insight on unstable data"
- "Change management starts on Day 1, not 3 months before go-live"

---

**PHASE OVERVIEW**

| Phase | Name | Duration | Key Deliverables | Success Criteria |
|-------|------|----------|-----------------|-----------------|
| Phase 0 | Mobilize | Weeks 1–4 | Programme setup, governance, team | Governance live, team onboarded |
| Phase 1 | Assess & Design | Weeks 4–16 | Current state, TOM, solution design | Design approved at G1/G2 |
| Phase 2 | Build | Weeks 16–40 | Configured system, integrations, data | SIT complete, UAT entered |
| Phase 3 | Test & Prepare | Weeks 38–48 | UAT complete, training delivered | Go-live readiness confirmed |
| Phase 4 | Deploy | Weeks 48–56 | Go-live, hypercare | System stable, users self-sufficient |
| Phase 5 | Optimize | Month 14–24 | Benefits realized, optimization backlog | Business case milestones achieved |

Adjust phases to actual programme context.

---

**SPRINT-LEVEL ROADMAP — FIRST 90 DAYS**

Sprint 1 (Days 1–14): **Programme Mobilization**
- Governance: Steering Committee constituted, PMO established, RAID log live
- Team: Core project team onboarded (SI partner, business leads, IT)
- Tooling: Project management tools live (JIRA/ADO/Smartsheet), communication channels established
- Kickoff: Executive kickoff workshop delivered
- Artefacts: Project charter, RACI, communication plan

Sprint 2 (Days 15–28): **Current State Assessment — Process and Organization**
- Finance process maps (L2) for all in-scope processes
- Stakeholder interviews completed (CFO-2 level and below)
- Pain point register built and prioritized
- Org chart: current state headcount and role mapping
- Change impact assessment: initial draft

Sprint 3 (Days 29–42): **Current State Assessment — Technology and Data**
- ERP/EPM current state documented: version, customizations, integration map
- Data quality assessment: chart of accounts review, master data quality scoring
- Report inventory: all live reports catalogued (source, consumer, frequency)
- Integration landscape: all current system integrations documented

Sprint 4 (Days 43–56): **TOM Options and Design Principles**
- TOM design principles agreed with steering committee
- 2–3 TOM options developed and assessed
- Recommended TOM option presented to steering (G1 tollgate)
- Future-state org chart: draft structural options

Sprint 5 (Days 57–70): **Future State Solution Architecture**
- Technology architecture: confirmed ERP/EPM scope, integration approach
- Process architecture: L3 future-state process maps for priority processes
- Data architecture: chart of accounts target design, data governance model
- Security model: roles and access design principles agreed

Sprint 6 (Days 71–84): **Business Case and Design Sign-Off**
- Full business case: investment, benefits, NPV, IRR, payback
- Detailed project plan: Weeks 16–52 at work-package level
- Resource plan: SI team, business team, IT team — roles and FTE-weeks
- Risk register: programme-level RAID with mitigations
- G2 tollgate: design approved, programme funding confirmed

Sprint 7 (Days 85–90): **Build Readiness**
- Development environment provisioned
- Data migration strategy finalized
- Integration design complete
- UAT strategy and test scenarios drafted
- Change management and training plan agreed

---

**DETAILED PHASE PLAN: MONTHS 4–18**

Generate a detailed work-breakdown by workstream:

| Workstream | Month 4–6 | Month 7–9 | Month 10–12 | Month 13–15 | Month 16–18 |
|------------|-----------|-----------|-------------|-------------|-------------|
| ERP/EPM Build | Configuration sprint 1–3 | Configuration sprint 4–6 | SIT | UAT | Go-live + hypercare |
| Data Migration | Source extract | Data cleanse | Mock migration 1–2 | Mock migration 3 | Production migration |
| Integrations | Integration design + build sprint 1 | Integration build sprint 2 | Integration SIT | End-to-end test | Go-live |
| Change Management | Stakeholder engagement | Training design | Training delivery | Go-live readiness | Adoption tracking |
| Reporting | Report inventory + rationalization | Report build | UAT | Training | Production |
| Testing | Test strategy + design | SIT preparation | SIT execution | UAT execution | Performance testing |

---

**RESOURCE PLAN**

| Role | Phase 0 | Phase 1 | Phase 2 | Phase 3 | Phase 4 | Total FTE-Months |
|------|---------|---------|---------|---------|---------|----------------|
| Programme Manager | | | | | | |
| Finance SME (senior) | | | | | | |
| IT Architect | | | | | | |
| Data Lead | | | | | | |
| Change Manager | | | | | | |
| SI Delivery Lead | | | | | | |
| SI Configuration Team | | | | | | |

**Resource sourcing**: identify which roles should be: internal client resource / SI partner / specialist contractor.

---

**MILESTONE SUMMARY**

| Milestone | Target Date | Owner | Risk | Dependency |
|-----------|-------------|-------|------|-----------|
| Programme kickoff | | | | |
| G1: Design approved | | | | |
| G2: Build approved | | | | |
| SIT complete | | | | |
| UAT complete | | | | |
| G4: Go-live approved | | | | |
| Go-live | | | | |
| G5: Benefits review | | | | |

---

**TOP 10 PROGRAMME RISKS**

| Risk | Probability | Impact | Mitigation | Owner |
|------|-------------|--------|-----------|-------|

---

After generating the roadmap, offer to: (1) export to an Excel project plan, (2) create a visual Gantt chart description, or (3) produce the governance charter for the programme.
