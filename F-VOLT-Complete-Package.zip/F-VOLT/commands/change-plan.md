---
description: Create a change management and adoption strategy
allowed-tools: Read, Write
argument-hint: "[programme context, impacted groups, timeline, or org details]"
---

Create a comprehensive Change Management and Adoption Strategy based on: $ARGUMENTS

If files have been provided (programme documentation, org charts, interview notes, stakeholder list), read them first.

Operate as the Principal Change Management and Transformation Adoption expert. Apply Prosci ADKAR methodology alongside stakeholder engagement, communications, and training design best practices.

This plan must be practical, specific, and phased — not a generic OCM framework. Every section should connect to real activities, owners, timelines, and measurable outcomes.

---

## CHANGE MANAGEMENT STRATEGY

**CHANGE NARRATIVE** (the "why" — 3–4 compelling paragraphs)

Write the change story that will be used internally: why the organization is transforming, what the future looks like, why now, and what it means for the people in the room. This narrative must be emotionally resonant and factually credible.

Use the Hero's Journey structure:
- Current world (where we are, what the pressures are)
- The call (why change is necessary)
- The future (what success looks like for individuals and the organization)
- The journey (what we'll go through together)

---

**STAKEHOLDER ANALYSIS**

Identify all impacted groups. For each group, provide:

| Stakeholder Group | # Impacted | Current Disposition | Change Impact (H/M/L) | Engagement Strategy |
|------------------|-----------|--------------------|-----------------------|-------------------|
| Finance leadership (VP+) | | | | |
| Controllers / Accountants | | | | |
| FP&A analysts | | | | |
| Business unit finance partners | | | | |
| IT team | | | | |
| Internal audit | | | | |
| Shared services / GBS (if applicable) | | | | |
| External auditors (awareness) | | | | |

**Priority stakeholder action plans**: For the top 3 high-influence / high-resistance stakeholders, develop a specific 90-day engagement plan.

---

**CHANGE IMPACT ASSESSMENT**

For each impacted role, score:

| Role | Process Change | System Change | Role Impact | Headcount Impact | CSI Score | Support Level Required |
|------|--------------|--------------|-------------|-----------------|-----------|----------------------|
| | 1–5 | 1–5 | 1–5 | 1–5 | Sum | High/Med/Low |

CSI ≥15 = High support (dedicated change resource + executive touchpoint)
CSI 10–14 = Medium support (group sessions + line manager enablement)
CSI <10 = Low support (standard training + reference materials)

---

**COMMUNICATIONS STRATEGY**

**Communication Principles** (5 governing rules for all communications)

**Key Messages by Audience**:

| Audience | Core Message | Tone | Channel | Owner |
|----------|-------------|------|---------|-------|
| Finance leadership | | Confident, strategic | 1:1 briefings, SC updates | Programme Sponsor |
| Finance staff | | Empathetic, specific | Town halls, team meetings | CFO + Change Lead |
| Business unit partners | | Partnership, minimal disruption | Business unit forums | Finance BPs |
| IT team | | Technical, collaborative | Technical briefings | IT Sponsor |

**Communications Calendar** (12-month view):

| Month | Milestone | Message Theme | Channel | Owner |
|-------|-----------|--------------|---------|-------|
| Month 1 | Launch | Why we're doing this | Town hall | CFO |
| Month 2–3 | Design phase | How your role is being designed | Team sessions | Change Lead |
| Month 4–6 | Build phase | What the system will look like | Demo sessions | Project team |
| Month 7–8 | UAT | Your chance to shape the system | UAT invitations | Change Lead |
| Month 9 | Pre-go-live | What changes on Day 1 | All channels | All |
| Month 10 | Go-live | We're live — here's your support | Email + intranet | Programme sponsor |
| Month 11–12 | Post go-live | How it's going; improvements made | Pulse results + update | CFO |

---

**TRAINING STRATEGY**

**Training Design Principles** (5 rules)

**Training Audience Matrix**:

| Role | Training Level | Format | Duration | Timing | Delivery |
|------|--------------|--------|----------|--------|----------|
| Super Users (10–15% of users) | Deep system + process | ILT + sandbox | 3–5 days | 6–4 weeks pre-go-live | Train-the-trainer |
| Power Users (30% of users) | Role-specific system + process | ILT + e-learning | 2–3 days | 4–2 weeks pre-go-live | Facilitated |
| End Users (50% of users) | Task-specific | E-learning + job aids | 0.5–1 day | 3–1 weeks pre-go-live | Self-directed |
| Management | Reporting and oversight | Executive briefing | 2 hours | 2 weeks pre-go-live | Executive session |

**Training Infrastructure**:
- Sandbox environment: provisioned [X] weeks before training starts
- LMS: completion tracking required (100% before go-live approval)
- Digital Adoption Platform (WalkMe / Whatfix): recommended for ongoing in-system guidance

---

**CHANGE CHAMPION NETWORK**

- Size: 1 champion per 10 users (minimum 1 per team)
- Selection criteria: respected, open to change, willing to invest 2–4 hours/week
- Activation: 2-day champion workshop before training rollout
- Ongoing: bi-weekly champion forum; champion briefings before communications go out
- Recognition: named in communications; career benefit framing; involvement in hypercare planning

---

**ADOPTION MEASUREMENT PLAN**

Define measurement cadence: weekly in hypercare, monthly in sustain phase.

| KPI | Measurement Method | Baseline | Month 1 Target | Month 3 Target | Month 6 Target |
|-----|-------------------|----------|----------------|----------------|----------------|
| Training completion | LMS | 0% | 100% by go-live | 100% | n/a |
| System login rate | Usage logs | 0% | >80% | >90% | >95% |
| Workaround usage | Audit sampling | 100% (old way) | <30% | <10% | <5% |
| Process compliance | Process audit | — | >70% | >90% | >95% |
| User satisfaction | Pulse survey (NPS) | — | >6.0 | >7.0 | >7.5 |

---

**RESISTANCE MANAGEMENT PLAN**

Anticipate resistance themes and prepare responses:

| Resistance Theme | Root Cause | Response Strategy | Owner |
|-----------------|-----------|-------------------|-------|
| "This is just another ERP project that will fail" | Previous negative experience | Acknowledge + differentiate + reference client evidence | Programme Sponsor |
| "I'll lose my job" | Role elimination fear | Direct communication on redeployment plan | CFO + HR |
| "The new system is worse than what we have" | Productivity dip during learning curve | Normalize dip; show post-90-day outcomes | Change Lead |
| "We're too busy to do training" | Capacity constraints | Integrate training into business rhythm; executive mandate | Finance Leadership |

---

After generating, offer to: (1) build a detailed communications template library, (2) create a change champion toolkit, or (3) design the training curriculum in detail.
