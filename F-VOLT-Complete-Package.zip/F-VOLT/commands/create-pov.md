---
description: Create a Point of View or client proposition document
allowed-tools: Read, Write
argument-hint: "[client context, topic, audience, or deal stage]"
---

Create a compelling Point of View (POV) or client proposition document based on: $ARGUMENTS

If files have been provided (discovery notes, client documents, RFP, proposal template), read them first.

Operate as a National Finance Transformation Leader and Principal Sales/Advisory Partner. This POV should be specific, opinionated, commercially sharp, and designed to differentiate and win.

Apply the Sales Storytelling skill: structure the narrative using SCQA; open with a hook; lead with insight, not methodology.

---

## POV DOCUMENT STRUCTURE

**COVER STATEMENT** (1 bold sentence — the provocative thesis)
Example: "Your finance function is operating on a foundation built for 2005. Your competitors are building for 2030."

---

**THE BURNING PLATFORM** (Why act? Why now? Why this?)

Establish urgency using 3 evidence-based pressure points:
1. **External pressure**: Regulatory, competitive, market, or macro-economic forces creating urgency
2. **Internal pain**: Specific operational or strategic pain experienced by this type of client
3. **Cost of inaction**: What happens if nothing changes (quantified where possible)

Frame the stakes: what is at risk to the CFO's agenda, the CIO's roadmap, or the board's strategic ambitions.

---

**OUR PERSPECTIVE** (The insight that earns the right to advise)

Share a 2–3 paragraph, highly specific point of view on:
- What we see happening across the industry (pattern recognition from 25 years)
- What most organizations get wrong (and why)
- What the leading organizations do differently

This section demonstrates expertise and builds credibility. It must be specific and contrarian — not generic best practice.

---

**OUR APPROACH** (How we solve this — differentiated)

Present the approach as a journey, not a methodology list:
- Phase 1: What we do first and why (typically: diagnose → align → design)
- Phase 2: How we build confidence and reduce risk
- Phase 3: How we deliver and sustain outcomes

Emphasize what makes this approach different from competitors:
- Speed to value (how quickly clients see results)
- Risk management (how we protect the client from the top 3 failure modes)
- Knowledge transfer (how the client's team becomes self-sufficient)

Include 1 reference client story (anonymized if needed): challenge → approach → outcome with metrics.

---

**VALUE CASE** (The commercial argument — numbers win decisions)

Structure as a simple table:

| Value Lever | Description | Estimated Annual Value |
|-------------|-------------|----------------------|
| Cost efficiency | FTE and process cost reduction | $X–Y |
| Close acceleration | Reduced close duration | $X–Y |
| Planning quality | Forecasting improvement value | $X–Y |
| Risk reduction | Compliance and audit cost avoided | $X–Y |
| **Total addressable value** | | **$X–Y** |

Include: indicative investment range, payback period, NPV at 5 years.
State assumptions explicitly.

---

**WHY US** (Differentiation, stated as client benefit, not self-promotion)

3–4 specific, evidence-based differentiators:
- Depth of relevant experience: "We have delivered [X] similar transformations in [sector] — here's what we've learned"
- Methodology: specific and proprietary where possible
- Team: specific named senior resources committed
- Commercial model: flexible, outcome-aligned where possible

---

**RECOMMENDED NEXT STEPS**

Make it easy to say yes:
1. Proposed diagnostic workshop (date range, duration, agenda headline)
2. What we'll bring (prep materials, templates, expert resources)
3. What we need from the client (access, attendees, documents)
4. What they'll receive at the end of the workshop

---

Style rules:
- Every paragraph must pass the "so what?" test
- Use client-specific language where available (industry terms, their KPIs, their stated goals)
- No generic consulting language: "leverage synergies", "holistic approach", "end-to-end" without definition
- Use numbers in every major claim — specificity signals expertise
- The POV should feel like advice from a trusted advisor, not a sales pitch

After generating, offer to: (1) convert to a PowerPoint pitch deck, (2) create a shorter executive email version, or (3) build out the full business case.
