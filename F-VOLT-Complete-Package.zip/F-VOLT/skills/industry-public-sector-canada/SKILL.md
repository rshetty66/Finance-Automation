---
name: industry-public-sector-canada
description: >
  This skill activates when the user discusses Canadian federal government,
  provincial government, municipal government, crown corporations, agencies,
  boards, commissions, public sector finance, public accounts, TBS, OAG,
  appropriations, voted vs statutory, estimates, public accounts, or finance
  transformation in Canadian public sector organizations.
version: 1.0.0
---

# Canadian Public Sector Expert

Deep expertise in finance transformation for Canadian federal, provincial, and municipal governments, as well as crown corporations and public agencies. Covers public sector budgeting, appropriations, reporting, and governance unique to the Canadian context.

---

## 1. Canadian Public Sector Landscape

### Federal Government
**Key Departments:**
- **TBS (Treasury Board of Canada Secretariat)**: Central agency for management
- **Department of Finance**: Fiscal policy, budget
- **PSPC (Public Services and Procurement Canada)**: Procurement, real property
- **CRA (Canada Revenue Agency)**: Tax administration
- **SSC (Shared Services Canada)**: IT services

**Crown Corporations (Schedule III):**
- Canada Post
- CBC/Radio-Canada
- VIA Rail
- Export Development Canada (EDC)
- Business Development Bank of Canada (BDC)
- Canada Mortgage and Housing Corporation (CMHC)

### Provincial/Territorial Governments
**Major Provinces:**
- Ontario: Ministry of Finance, Treasury Board Secretariat
- Quebec: Ministère des Finances, Secrétariat du Conseil du trésor
- British Columbia: Ministry of Finance, Treasury Board
- Alberta: Ministry of Finance, Treasury Board and Finance

### Municipal Government
**Structure:**
- Cities, towns, counties, regions
- School boards
- Public health units
- Conservation authorities

**Key Activities:**
- Property tax administration
- User fees and charges
- Development charges
- Intergovernmental transfers

---

## 2. Public Sector Budgeting

### Federal Budget Cycle

**Phases:**
1. **Budget Planning** (April-August)
   - Departmental planning
   - Strategic reviews
   - Expenditure management

2. **Budget Formulation** (September-December)
   - Ministerial consultations
   - Cabinet decisions
   - Budget speech preparation

3. **Budget Release** (February-March)
   - Budget Day
   - Budget Implementation Act

4. **Estimates** (Spring)
   - Main Estimates
   - Supplementary Estimates (A, B, C)

### Types of Authorities

**Voted (Annual):**
- Require Parliament approval annually
- Found in Estimates
- Examples: Operating budgets, capital spending

**Statutory (Ongoing):**
- Authorized by legislation
- Do not require annual vote
- Examples: Transfer payments, public debt charges, CPP

### Budget Structure

**Expenditure Categories:**
```
Total Expenditures
├── Voted
│   ├── Operating
│   ├── Capital
│   └── Grants/Contributions
└── Statutory
    ├── Transfer Payments
    ├── Public Debt Charges
    └── Other Statutory
```

### Provincial Budgeting

**Similar Structure with Variations:**
- Main estimates (annual)
- Supplementary estimates
- Interim supply (spring)
- Public accounts (annual)

**Key Differences:**
- Property tax (municipal, provincial education)
- Provincial transfers to municipalities
- Healthcare funding
- Education funding

---

## 3. Appropriations and Spending

### Appropriation Acts
**Purpose:** Legal authority to spend
**Types:**
- **1-year**: Operating, capital
- **2-year**: Capital (some jurisdictions)
- **5-year**: Specific initiatives
- **No-year**: Continuing funds

### Spending Process

**Allotment:**
- TBS authority to spend
- Quarterly or annual
- Can be revised

**Commitment:**
- Obligation to spend
- Creates liability
- Reduces available allotment

**Expenditure:**
- Actual payment
- Clears commitment
- Recorded in accounts

### Reconciliation
```
Appropriation
- Allotment
= Available to Allot

Allotment
- Commitments
- Expenditures
= Balance Available
```

### Year-End Process

**Lapse:**
- Unspent appropriations
- Typically return to consolidated revenue fund
- Some exceptions (frozen allotments)

**Carry Forward:**
- Limited ability to carry forward
- Usually requires TBS approval
- Common for capital

---

## 4. Public Sector Accounting

### Accounting Standards

**PSAS (Public Sector Accounting Standards):**
- Set by PSAB (Public Sector Accounting Board)
- Used by provinces, municipalities, crown corporations
- Accrual accounting basis

**CPA Canada Handbook:**
- Section PS 4200-4600: Public sector
- Section 4400: Crown corporations

**Federal Government:**
- Modified accrual (some cash basis elements)
- Comptroller General policies
- FAA (Financial Administration Act)

### Financial Statements

**Statement of Operations:**
- Revenues
- Expenses
- Surplus/deficit

**Statement of Financial Position:**
- Assets
- Liabilities
- Net debt/net assets

**Statement of Cash Flow:**
- Operating
- Capital
- Investing
- Financing

### Key Differences from Private Sector

| Aspect | Public Sector | Private Sector |
|--------|---------------|----------------|
| **Objective** | Service delivery | Profit |
| **Budget** | Legal authority | Planning tool |
| **Revenue** | Taxes, transfers | Sales, fees |
| **Performance** | Outputs, outcomes | Profit, ROI |
| **Reporting** | Public accounts | Financial statements |
| **Audit** | Auditor General | External auditors |

---

## 5. Governance and Controls

### Federal Governance

**FAA (Financial Administration Act):**
- Financial management framework
- Authorities and responsibilities
- Crown corporation governance

**Key Roles:**
- **Minister**: Political accountability
- **Deputy Head**: Departmental management
- **CFO**: Financial management
- **Chief Audit Executive**: Internal audit

**Committees:**
- **ADM (Resource Management)**: Senior management
- **CFO Committee**: Financial leadership
- **Audit Committee**: Independent oversight

### Internal Controls

**Framework:**
- COSO framework adapted
- TBS Policy on Internal Control
- Risk-based approach

**Key Controls:**
- Segregation of duties
- Delegation of authority
- Commitment control
- Payment verification
- Asset management

### External Audit

**Auditor General of Canada (OAG):**
- Independent audit of public accounts
- Performance audits
- Special examinations
- Crown corporation audits

**Provincial Auditors:**
- Similar mandate at provincial level
- Municipal audits
- Agency audits

---

## 6. Crown Corporations

### Governance Framework

**CCRA (Canada Commercial Corporation):** Not applicable
**Correct: Part X of FAA (or equivalent provincial legislation)**

**Key Elements:**
- Parent Crown vs. Wholly-owned
- Schedule III (Parliamentary appropriations)
- Schedule III.I (non-appropriated)
- Agent vs. non-agent Crown status

### Board Responsibilities

**Accountabilities:**
- Strategic planning
- Risk oversight
- CEO appointment
- Financial oversight
- Public policy alignment

### Performance Reporting

**CPR (Corporate Plan Summary):**
- Strategic objectives
- Performance indicators
- Financial projections
- Published annually

**QFR (Quarterly Financial Report):**
- Actual vs. plan
- Variance explanations
- Treasury Board submission

---

## 7. Public Sector KPIs

### Financial Performance

| KPI | Description | Target |
|-----|-------------|--------|
| **Budget Variance** | Actual vs. appropriated | < 5% |
| **Lapse Rate** | Unspent appropriations | < 3% |
| **Operating Ratio** | Operating costs / Total costs | Varies |
| **Cost per Program Output** | Unit cost efficiency | Improve YoY |

### Operational Efficiency

| KPI | Description | Target |
|-----|-------------|--------|
| **Procurement Cycle Time** | Days from requisition to order | Reduce |
| **Payables Days** | Days to pay vendors | < 30 |
| **Grant Processing Time** | Days to process applications | Reduce |
| **Close Cycle** | Days to close books | < 15 |

### Service Delivery

| KPI | Description | Target |
|-----|-------------|--------|
| **Program Uptake** | % eligible using program | Maximize |
| **Client Satisfaction** | Survey-based | > 80% |
| **Error Rate** | Payment/processing errors | < 1% |
| **Response Time** | Service level achievement | > 95% |

### Compliance

| KPI | Description | Target |
|-----|-------------|--------|
| **Audit Findings** | Number of material findings | Zero |
| **Internal Control Deficiencies** | Significant deficiencies | Zero |
| **Access to Information** | Response within statutory time | 100% |
| **Privacy Breaches** | Reportable incidents | Zero |

---

## 8. Public Sector Transformation

### Common Drivers

**Legislative Changes:**
- New programs
- Policy shifts
- Accountability requirements

**Efficiency Mandates:**
- Deficit reduction
- Spending reviews
- Strategic reviews

**Digital Transformation:**
- Online services
- Data analytics
- Automation

### Transformation Challenges

**Cultural:**
- Risk aversion
- Bureaucratic processes
- Tenure-based advancement

**Structural:**
- Siloed departments
- Complex approval chains
- Legislative constraints

**Technical:**
- Legacy systems
- Data fragmentation
- Security requirements

### Best Practices

**Change Management:**
- Engage unions early
- Communicate public service value
- Training and development
- Recognition programs

**Technology:**
- Cloud-first approach (where appropriate)
- Agile development
- User-centered design
- Cybersecurity integration

**Process:**
- Streamline approvals
- Delegation of authority
- Shared services
- Standardization

---

## 9. Federal-Provincial-Municipal Transfers

### Major Transfer Programs

**Canada Health Transfer (CHT):**
- $XX billion annually
- Block funding
- Condition: Canada Health Act

**Canada Social Transfer (CST):**
- $XX billion annually
- Social programs, post-secondary education
- Block funding

**Equalization:**
- To less prosperous provinces
- Fiscal capacity equalization
- Unconditional

**Infrastructure Programs:**
- Cost-shared projects
- Application-based
- Project agreements

### Transfer Payment Administration

**Types:**
- **Grants**: No repayment, no deliverables
- **Contributions**: Deliverables expected
- **Shared-cost**: Cost-sharing formula

**Due Diligence:**
- Risk assessment
- Recipient capacity
- Performance monitoring
- Audit rights

---

## 10. Public Sector Technology

### ERP in Public Sector

**Federal:**
- **SAP**: Many departments
- **Oracle**: Some agencies
- **Workday**: HCM emerging

**Provincial:**
- **SAP**: Ontario, Quebec, others
- **Oracle**: Various ministries

**Municipal:**
- **SAP**: Larger cities
- **JD Edwards**: Mid-size
- **Specialized**: Local government solutions

### Specialized Systems

**Grants Management:**
- Streamlined administration
- Compliance tracking
- Performance measurement

**HR/Pay:**
- Phoenix (federal) - lessons learned
- Provincial systems
- Pension administration

**Case Management:**
- Benefits administration
- Immigration
- Taxpayer services

---

## Quick Reference: Public Sector Checklist

**Engagement Start:**
- [ ] Level of government identified
- [ ] Department/agency scope defined
- [ ] Crown corporation vs. department clarified
- [ ] Appropriations structure understood
- [ ] Key stakeholders mapped (TBS, OAG, Minister)

**Financial Assessment:**
- [ ] Budget cycle timing understood
- [ ] Estimates/appropriations reviewed
- [ ] Lapse history analyzed
- [ ] Cost drivers identified
- [ ] Transfer payments mapped

**Transformation Planning:**
- [ ] Legislative constraints identified
- [ ] Union consultation plan
- [ ] TBS policy compliance
- [ ] Audit considerations
- [ ] Public communications strategy
