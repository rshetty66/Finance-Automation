---
name: si-change-management
description: >
  This skill activates when the user discusses change management, organizational
  change management, OCM, adoption, training, communication, stakeholder management,
  resistance management, change impact assessment, readiness assessment, ADKAR,
  Kotter, Prosci, change network, champions, super users, or business readiness
  for systems integration projects.
version: 1.0.0
---

# Change Management Lead — SI Delivery Excellence

Expert-level guidance for organizational change management in systems integration projects. Covers stakeholder engagement, training strategy, communication planning, adoption measurement, and business readiness across all major transformation initiatives.

---

## 1. Change Management Frameworks

### ADKAR Model

**The Five Elements:**
```
A - Awareness of the need for change
D - Desire to participate and support
K - Knowledge of how to change
A - Ability to implement required skills
R - Reinforcement to sustain the change
```

**Application in SI Projects:**

| Phase | ADKAR Element | Activities |
|-------|---------------|------------|
| **Assess** | Awareness | Stakeholder analysis, communication |
| **Design** | Desire | Vision workshops, WIIFM |
| **Build** | Knowledge | Training development, documentation |
| **Deploy** | Ability | Hands-on training, job aids |
| **Sustain** | Reinforcement | Adoption monitoring, support |

### Kotter's 8-Step Change Model

```
1. Create Urgency
        ↓
2. Form Coalition
        ↓
3. Create Vision
        ↓
4. Communicate Vision
        ↓
5. Remove Obstacles
        ↓
6. Create Quick Wins
        ↓
7. Build on Change
        ↓
8. Anchor Changes
```

**Application to SI Projects:**
| Step | SI Activity |
|------|-------------|
| 1 | Business case for change, cost of status quo |
| 2 | Steering committee, executive sponsors |
| 3 | Future state vision, benefits communication |
| 4 | Town halls, roadshows, newsletters |
| 5 | Process redesign, support removal |
| 6 | Pilot success, early adopters |
| 7 | Expand rollout, continuous improvement |
| 8 | Measure benefits, celebrate success |

### Prosci 3-Phase Process

**Phase 1: Prepare Approach**
- Define success
- Define impact
- Define approach

**Phase 2: Manage Change**
- Plan and act
- Track performance
- Adapt actions

**Phase 3: Sustain Outcomes**
- Review performance
- Activate sustainment
- Transfer ownership

---

## 2. Stakeholder Management

### Stakeholder Analysis

**Power/Interest Matrix:**
```
            INTEREST
         Low    |    High
       ┌─────────┼─────────┐
 High  | Keep    | Manage  |
       | Satisfied│ Closely │
POWER  ├─────────┼─────────┤
 Low   | Monitor | Keep    |
       |         | Informed│
       └─────────┴─────────┘
```

**Stakeholder Categories:**
| Category | Examples | Engagement Strategy |
|----------|----------|---------------------|
| **Sponsors** | CFO, CIO | Regular briefings, escalation path |
| **Champions** | Finance managers | Early involvement, influence |
| **End Users** | AP clerks, accountants | Training, support |
| **Affected** | IT support, auditors | Impact assessment, communication |
| **Blockers** | Resistant managers | Address concerns, convert |

### Stakeholder Register Template

```
Name | Role | Influence | Interest | Current Stance | Strategy | Actions
-----|------|-----------|----------|----------------|----------|--------
John | CFO  | High      | High     | Supportive     | Engage   | Weekly 1:1
Mary | AP Mgr| Medium   | High     | Resistant      | Convert  | Address workload
```

### Stakeholder Engagement Plan

**Executive Sponsors:**
| Activity | Frequency | Owner |
|----------|-----------|-------|
| Steering Committee | Monthly | Program Lead |
| Executive Briefing | Bi-weekly | Change Lead |
| Board Updates | Quarterly | Sponsor |

**Management:**
| Activity | Frequency | Owner |
|----------|-----------|-------|
| Manager Workshops | Monthly | Change Lead |
| Cascade Briefings | Weekly | Managers |
| Office Hours | Weekly | Project Team |

**End Users:**
| Activity | Frequency | Owner |
|----------|-----------|-------|
| Town Halls | Monthly | Change Lead |
| Department Sessions | As needed | Trainers |
| Email Updates | Weekly | Communications |
| Intranet Updates | Ongoing | Communications |

---

## 3. Change Impact Assessment

### Impact Assessment Framework

**Dimensions to Assess:**

| Dimension | Assessment Questions |
|-----------|---------------------|
| **Process** | What processes change? How significantly? |
| **Technology** | What new systems? What's retiring? |
| **Organization** | Roles changing? Reporting changes? |
| **Culture** | Behaviors changing? Mindset shift? |
| **Location** | Which sites affected? Language needs? |
| **Timing** | When do changes hit? Overlaps? |

### Impact Heat Map

```
           IMPACT SEVERITY
       Low      Medium     High
      ┌─────────┬─────────┬─────────┐
High  │  Green  │ Yellow  │   RED   │
      ├─────────┼─────────┼─────────┤
Medium│  Green  │ Yellow  │ Yellow  │
      ├─────────┼─────────┼─────────┤
Low   │  Green  │  Green  │ Yellow  │
      └─────────┴─────────┴─────────┘
      NUMBER OF PEOPLE AFFECTED
```

**Action by Zone:**
| Zone | Action |
|------|--------|
| Red | Intensive change management, dedicated support |
| Yellow | Standard change management, group activities |
| Green | Light touch, self-service resources |

### Role-Based Impact Assessment

**Finance Manager:**
| Change Area | Impact | Preparation Needed |
|-------------|--------|-------------------|
| Reporting | High | New reports, self-service training |
| Approvals | Medium | Workflow training, delegation |
| Team Management | Medium | Role changes, performance metrics |

**AP Processor:**
| Change Area | Impact | Preparation Needed |
|-------------|--------|-------------------|
| Invoice Entry | High | System training, new process |
| Payment Process | Medium | New approval chains |
| Vendor Management | Low | Awareness, reference materials |

---

## 4. Communication Strategy

### Communication Framework

**The 5 W's + H:**
| Element | Questions |
|---------|-----------|
| **Who** | Target audience, sender |
| **What** | Key messages |
| **When** | Timing, frequency |
| **Where** | Channels |
| **Why** | Purpose, call to action |
| **How** | Format, style |

### Communication Channels

| Channel | Best For | Frequency |
|---------|----------|-----------|
| **Town Halls** | Major announcements, vision | Monthly |
| **Email** | Updates, reminders | Weekly |
| **Intranet** | Repository, self-service | Ongoing |
| **Workshops** | Training, deep-dives | Per phase |
| **Videos** | Demos, testimonials | As needed |
| **Posters** | Reinforcement, awareness | Physical sites |
| **Q&A Sessions** | Concerns, feedback | Bi-weekly |
| **Manager Cascade** | Local context, team impact | Weekly |

### Message Development

**Message Framework:**
```
WHAT: What is changing?
SO WHAT: Why does it matter?
NOW WHAT: What do I need to do?
```

**Example:**
```
WHAT: We are implementing a new ERP system to replace our 
      legacy finance applications.

SO WHAT: This will eliminate manual workarounds, provide 
         real-time visibility, and reduce month-end close 
         from 8 days to 4 days.

NOW WHAT: You will attend training in March, participate 
          in UAT in April, and go live in May.
```

### Communication Calendar Template

| Week | Activity | Audience | Channel | Owner |
|------|----------|----------|---------|-------|
| 1 | Kickoff announcement | All | Town Hall + Email | Sponsor |
| 2 | Manager briefing | Managers | Workshop | Change Lead |
| 3 | Department sessions | End Users | Small groups | Trainers |
| 4 | Progress update | All | Email | Communications |

---

## 5. Training Strategy

### Training Needs Analysis

**Assessment Dimensions:**
| Dimension | Assessment |
|-----------|------------|
| **Current Skill Level** | Beginner, Intermediate, Advanced |
| **Change Magnitude** | New system, new process, minor change |
| **Role Criticality** | Daily user, occasional user, view-only |
| **Learning Preference** | Hands-on, visual, reading |
| **Location/Access** | Office, remote, mobile |

### Training Delivery Methods

| Method | Best For | Pros | Cons |
|--------|----------|------|------|
| **Instructor-Led (ILT)** | Complex processes | Interactive, Q&A | Cost, scheduling |
| **Virtual (VILT)** | Distributed teams | Cost-effective | Engagement |
| **eLearning** | Standard processes | Self-paced, scalable | No immediate help |
| **Hands-on Labs** | System practice | Practical experience | Time-intensive |
| **Job Aids** | Quick reference | Always available | Limited depth |
| **Videos** | Demos, concepts | Visual, replayable | Production time |
| **Simulations** | Practice | Safe environment | Development cost |

### Role-Based Training Plan

**System Administrators:**
| Topic | Method | Duration |
|-------|--------|----------|
| System configuration | ILT + Hands-on | 5 days |
| Security setup | ILT | 2 days |
| Troubleshooting | ILT + Lab | 3 days |

**Power Users/Super Users:**
| Topic | Method | Duration |
|-------|--------|----------|
| End-to-end process | ILT + Hands-on | 3 days |
| Advanced features | ILT | 2 days |
| Train-the-trainer | Workshop | 1 day |

**End Users:**
| Topic | Method | Duration |
|-------|--------|----------|
| Process overview | eLearning | 30 min |
| System basics | ILT | 4 hours |
| Hands-on practice | Lab | 4 hours |

### Training Materials Development

**Required Materials:**
| Material | Purpose | Format |
|----------|---------|--------|
| **User Guides** | Step-by-step instructions | PDF, Online |
| **Quick Reference Cards** | Common tasks | Laminated card |
| **Video Tutorials** | Visual demonstrations | MP4, YouTube |
| **eLearning Modules** | Self-paced learning | SCORM |
| **FAQ Document** | Common questions | Wiki, PDF |
| **Process Flows** | Visual process maps | Visio, PDF |

### Super User Network

**Super User Responsibilities:**
- First line of support
- Training assistance
- Feedback collection
- Change advocacy
- Testing participation

**Super User Selection Criteria:**
- Subject matter expertise
- Communication skills
- Positive attitude
- Credibility with peers
- Availability

**Super User Engagement:**
- Early involvement in design
- Advanced training
- Regular sync meetings
- Recognition program

---

## 6. Adoption Measurement

### Adoption Metrics Framework

**Leading Indicators (Predictive):**
| Metric | Target | Measurement |
|--------|--------|-------------|
| Training completion | >95% | LMS tracking |
| UAT participation | >90% | Test sign-off |
| Communication open rate | >70% | Email analytics |
| Help desk tickets | Baseline | Ticket volume |

**Lagging Indicators (Results):**
| Metric | Target | Measurement |
|--------|--------|-------------|
| System login rate | >95% | System logs |
| Transaction volume | Expected | System reports |
| Process compliance | >90% | Audit reports |
| User satisfaction | >4/5 | Survey |

### Adoption Dashboard

```
┌─────────────────────────────────────────┐
│         ADOPTION DASHBOARD             │
├─────────────────────────────────────────┤
│ Training Completion: ████████░░ 85%    │
│ System Access:       ██████████ 95%    │
│ Process Compliance:  ███████░░░ 78%    │
│ User Satisfaction:   █████████░ 4.2/5  │
├─────────────────────────────────────────┤
│ ⚠️ At Risk Users: 45 (need support)    │
│ 🎯 On Track: 850 users                 │
│ ⭐ Champions: 50 users                  │
└─────────────────────────────────────────┘
```

### Adoption Interventions

**For Low Adoption:**
| Intervention | When to Use |
|--------------|-------------|
| Reminder communications | Missing training |
| Manager escalation | Not using system |
| One-on-one coaching | Struggling users |
| Additional training | Knowledge gaps |
| Process simplification | Too complex |

---

## 7. Business Readiness

### Readiness Assessment

**Readiness Dimensions:**
| Dimension | Assessment Criteria | Status |
|-----------|---------------------|--------|
| **Technical** | System tested, data ready | R/Y/G |
| **Process** | Procedures documented, tested | R/Y/G |
| **People** | Trained, confident | R/Y/G |
| **Support** | Help desk ready, super users trained | R/Y/G |
| **Communications** | Users informed, expectations set | R/Y/G |

### Readiness Checklist

**Technical Readiness:**
- [ ] System configuration complete
- [ ] Data migration validated
- [ ] Integrations tested
- [ ] Security configured
- [ ] Performance validated

**Process Readiness:**
- [ ] Process documentation complete
- [ ] Procedures updated
- [ ] Quick reference guides available
- [ ] Exceptions process defined

**People Readiness:**
- [ ] Training completed by target date
- [ ] Super users identified and trained
- [ ] Managers briefed on team changes
- [ ] Resistance addressed

**Support Readiness:**
- [ ] Help desk trained
- [ ] Escalation paths defined
- [ ] Support tools ready
- [ ] FAQ published

**Communication Readiness:**
- [ ] Go-live date communicated
- [ ] User expectations set
- [ ] Support channels advertised
- [ ] Success metrics shared

### Go/No-Go Decision Criteria

| Criteria | Threshold | Data Source |
|----------|-----------|-------------|
| Training completion | >90% | LMS reports |
| Critical defects | 0 open | Defect log |
| Data migration | 100% reconciled | Recon reports |
| User confidence | >75% positive | Survey |
| Support readiness | All items complete | Checklist |

---

## 8. Resistance Management

### Sources of Resistance

| Source | Root Cause | Response |
|--------|------------|----------|
| **Fear of job loss** | Automation concerns | Communication, retraining |
| **Comfort with status quo** | Change fatigue | Incremental changes, involvement |
| **Lack of trust** | Past failed projects | Transparency, quick wins |
| **Workload concerns** | Training + day job | Time allocation, support |
| **Skill anxiety** | Technology intimidation | Training, mentoring |
| **Political** | Loss of power/influence | Involvement, recognition |

### Resistance Response Strategies

**Education & Communication:**
- When: Lack of information
- How: Clear communication, address rumors

**Participation & Involvement:**
- When: Need for buy-in
- How: Workshops, feedback sessions

**Facilitation & Support:**
- When: Skill gaps, anxiety
- How: Training, mentoring, job aids

**Negotiation & Agreement:**
- When: Power users with legitimate concerns
- How: Compromise, phased approach

**Co-optation:**
- When: Influential resisters
- How: Give them a role, convert to champion

**Explicit/Implicit Coercion:**
- When: Crisis, urgent need
- How: Executive mandate (last resort)

### Resistance Monitoring

**Early Warning Signs:**
- Declining meeting attendance
- Negative water-cooler talk
- Passive-aggressive behavior
- Delayed responses
- Escalating issues

**Intervention Escalation:**
```
Peer conversation → Manager involvement → 
Change lead meeting → Executive escalation → 
Formal performance discussion (if continued)
```

---

## Quick Reference: Change Management Checklist

**Pre-Project:**
- [ ] Change management strategy defined
- [ ] Change lead identified
- [ ] Stakeholder analysis complete
- [ ] Impact assessment complete

**During Project:**
- [ ] Communication plan executed
- [ ] Training delivered
- [ ] Super user network active
- [ ] Resistance addressed

**At Go-Live:**
- [ ] Business readiness confirmed
- [ ] Support structure in place
- [ ] Adoption monitoring active
- [ ] Reinforcement plan ready

**Post Go-Live:**
- [ ] Adoption metrics tracked
- [ ] Support provided
- [ ] Feedback collected
- [ ] Continuous improvement
