---
name: enterprise-value
description: >
  This skill activates when the user discusses enterprise value, value creation,
  value realization, benefits realization, business case, ROI, NPV, IRR, payback,
  TCO, cost-benefit analysis, economic value added, shareholder value, or
  measuring and tracking value from transformation initiatives.
version: 1.0.0
---

# Enterprise Value Expert

Deep expertise in quantifying, tracking, and realizing value from transformation initiatives. Covers business case development, value metrics, benefits realization, and value-based management.

---

## 1. Value Framework

### The Value Hierarchy

```
Strategic Value (Why)
    ↓
Business Value (What)
    ↓
Operational Value (How)
    ↓
Financial Value (How Much)
```

**Strategic Value:**
- Competitive positioning
- Market share
- Customer satisfaction
- Innovation capability
- Risk reduction

**Business Value:**
- Revenue growth
- Cost reduction
- Productivity improvement
- Quality enhancement
- Compliance

**Operational Value:**
- Process efficiency
- Automation
- Standardization
- Speed to market
- Decision quality

**Financial Value:**
- NPV, IRR, ROI
- Cash flow
- Payback period
- Cost savings
- Revenue uplift

### Value Categories

**Hard Benefits (Quantifiable):**
- Headcount reduction
- License cost avoidance
- Vendor consolidation
- Process efficiency
- Error reduction

**Soft Benefits (Directional):**
- Employee satisfaction
- Customer experience
- Decision quality
- Risk reduction
- Strategic flexibility

**Hard to Quantify:**
- Brand reputation
- Innovation enablement
- Employee retention
- Market expansion capability

---

## 2. Business Case Development

### Business Case Structure

```
EXECUTIVE SUMMARY
├── Investment required
├── Value proposition
├── Key risks
└── Recommendation

PROBLEM/OPPORTUNITY
├── Current state
├── Pain points
├── Root causes
└── Strategic imperative

SOLUTION ALTERNATIVES
├── Option 1: Do nothing
├── Option 2: Minimal solution
├── Option 3: Recommended solution
└── Comparison matrix

VALUE QUANTIFICATION
├── Benefits (hard and soft)
├── Costs (capex and opex)
├── Financial metrics (NPV, IRR, ROI)
└── Risk-adjusted value

IMPLEMENTATION APPROACH
├── Phases and timeline
├── Resource requirements
├── Risk mitigation
└── Success metrics

RECOMMENDATION
├── Preferred option
├── Next steps
├── Governance
└── Approval sought
```

### Financial Metrics

**Net Present Value (NPV):**
```
NPV = Σ (Cash Flow_t / (1 + r)^t) - Initial Investment

Where:
- Cash Flow_t = Net cash flow in period t
- r = Discount rate (WACC)
- t = Time period
```

**Internal Rate of Return (IRR):**
- Discount rate that makes NPV = 0
- Compare to hurdle rate
- Shows % return on investment

**Return on Investment (ROI):**
```
ROI = (Total Benefits - Total Costs) / Total Costs × 100%

Simple ROI = Average Annual Benefits / Total Investment
```

**Payback Period:**
- Time to recover initial investment
- Simple: Investment / Annual cash flow
- Discounted: Accounting for time value

**Total Cost of Ownership (TCO):**
```
TCO = 
  Initial Costs (software, hardware, implementation)
  + Ongoing Costs (maintenance, support, licenses)
  + Operating Costs (personnel, training, facilities)
  - Residual Value (salvage, resale)
```

### Discount Rate Selection

**Weighted Average Cost of Capital (WACC):**
```
WACC = (E/V × Re) + (D/V × Rd × (1 - T))

Where:
- E = Market value of equity
- D = Market value of debt
- V = E + D (Total value)
- Re = Cost of equity
- Rd = Cost of debt
- T = Tax rate
```

**Typical Hurdle Rates:**
| Organization Type | Typical Hurdle Rate |
|-------------------|---------------------|
| Large corporation | 10-15% |
| Mid-size company | 12-18% |
| High-risk project | 15-25% |
| Public sector | 6-8% (social discount) |

---

## 3. Value Identification

### Value Drivers Framework

**Revenue Growth:**
| Driver | Measurement | Examples |
|--------|-------------|----------|
| Volume | Units sold | More customers, higher frequency |
| Price | Price per unit | Premium pricing, upselling |
| Mix | Product mix | Higher-margin products |
| New Markets | Geographic/customer | Market expansion |
| Retention | Churn reduction | Customer loyalty |

**Cost Reduction:**
| Driver | Measurement | Examples |
|--------|-------------|----------|
| Labor | Headcount/FTE | Automation, efficiency |
| Materials | Unit cost | Procurement savings |
| Operations | Process cost | Lean, Six Sigma |
| Technology | IT spend | Cloud, consolidation |
| Overhead | Admin costs | Shared services |

**Capital Efficiency:**
| Driver | Measurement | Examples |
|--------|-------------|----------|
| Working capital | Cash conversion | Receivables, inventory |
| Asset utilization | ROA | Equipment efficiency |
| Capex avoidance | Deferred spend | Cloud vs. on-prem |

### Value Identification Workshop

**Process:**
1. **Current State Analysis**
   - Process mapping
   - Cost analysis
   - Pain point identification

2. **Future State Vision**
   - To-be process
   - Technology enablement
   - Operational model

3. **Gap Analysis**
   - Differences identified
   - Impact quantified
   - Value calculated

4. **Value Validation**
   - Stakeholder input
   - Benchmark comparison
   - Sensitivity analysis

### Value Calculation Examples

**Process Automation:**
```
Current:
- Process time: 4 hours/transaction
- Volume: 10,000/year
- Labor rate: $50/hour loaded
- Current cost: $2M/year

Future:
- Process time: 1 hour/transaction
- Volume: 10,000/year
- Labor rate: $50/hour loaded
- Future cost: $500K/year

Value: $1.5M/year
```

**System Consolidation:**
```
Current:
- 5 ERP systems: $2M/year licenses
- 50 FTE support: $5M/year
- Integration costs: $500K/year
- Total: $7.5M/year

Future:
- 1 ERP system: $800K/year licenses
- 30 FTE support: $3M/year
- Reduced integration: $200K/year
- Total: $4M/year

Value: $3.5M/year
Plus: One-time migration costs
```

---

## 4. Benefits Realization

### Benefits Realization Framework

**The 4 Pillars:**

| Pillar | Focus | Activities |
|--------|-------|------------|
| **Identify** | What value? | Value mapping, quantification |
| **Plan** | How to achieve? | Targets, initiatives, accountability |
| **Track** | Are we on track? | KPIs, reporting, dashboards |
| **Optimize** | How to improve? | Adjustments, acceleration |

### Benefits Realization Plan

**Structure:**
```
Benefit Category
├── Benefit 1
│   ├── Description
│   ├── Current baseline
│   ├── Target
│   ├── Measurement approach
│   ├── Owner
│   ├── Timeline
│   └── Dependencies
├── Benefit 2
│   └── ...
```

### Benefits Tracking

**Benefits Register:**
| ID | Benefit | Category | Baseline | Target | Actual | Owner | Status |
|----|---------|----------|----------|--------|--------|-------|--------|
| B001 | Close acceleration | Efficiency | 8 days | 4 days | 5 days | CFO | Yellow |
| B002 | Headcount reduction | Cost | 100 FTE | 85 FTE | 90 FTE | CHRO | Yellow |
| B003 | Error reduction | Quality | 5% | 1% | 2% | Controller | Green |

**Tracking Frequency:**
- **Leading indicators**: Weekly/Monthly
- **Lagging indicators**: Quarterly
- **Financial benefits**: Monthly/Quarterly

### Benefits Realization Challenges

| Challenge | Solution |
|-----------|----------|
| **Soft benefits hard to measure** | Proxy metrics, surveys |
| **Baseline unclear** | Retrospective analysis, estimates |
| **External factors** | Isolate transformation impact |
| **Benefit ownership gaps** | Assign clear accountability |
| **Sustainment** | Embed in operations, continuous monitoring |

---

## 5. Value-Based Management

### Value Scorecard

**Strategic Objectives → Value Drivers → KPIs**

```
Strategic Objective: Improve Financial Performance
    ↓
Value Drivers:
├── Revenue Growth
│   ├── KPI: Revenue growth %
│   ├── KPI: Market share
│   └── KPI: Customer lifetime value
├── Cost Efficiency
│   ├── KPI: Cost-to-income ratio
│   ├── KPI: Unit costs
│   └── KPI: Process efficiency
└── Capital Efficiency
    ├── KPI: ROE
    ├── KPI: Asset turnover
    └── KPI: Working capital ratio
```

### Value-Based Metrics

**Economic Value Added (EVA):**
```
EVA = NOPAT - (Capital × Cost of Capital)

Where:
- NOPAT = Net Operating Profit After Tax
- Capital = Invested capital
- Cost of Capital = WACC
```

**Cash Flow Return on Investment (CFROI):**
```
CFROI = (Gross Cash Flow - Economic Depreciation) / Gross Investment
```

**Total Shareholder Return (TSR):**
```
TSR = (Share Price End - Share Price Start + Dividends) / Share Price Start
```

### Value Driver Trees

**Example: Retail Bank Value Drivers**
```
Shareholder Value
├── Revenue
│   ├── Interest Income
│   │   ├── Loan Volume
│   │   └── Net Interest Margin
│   └── Fee Income
│       ├── Transaction volume
│       └── Fee per transaction
├── Costs
│   ├── Operating Expenses
│   │   ├── Personnel
│   │   ├── Technology
│   │   └── Occupancy
│   └── Credit Losses
│       ├── Loan volume
│       └── Loss rate
└── Capital
    ├── Risk-weighted assets
    └── Capital ratio
```

---

## 6. Value in Transformation Programs

### Program Value Framework

**Phase 1: Discovery**
- Value opportunity assessment
- Baseline establishment
- Target setting
- Business case development

**Phase 2: Design**
- Detailed value mapping
- Initiative prioritization
- Investment planning
- Benefit risk assessment

**Phase 3: Build**
- Quick wins identification
- Early value capture
- Progress tracking
- Course corrections

**Phase 4: Deploy**
- Full value realization
- Benefit tracking
- Performance optimization
- Sustainment planning

**Phase 5: Sustain**
- Embedded measurement
- Continuous improvement
- Value maximization
- Lessons learned

### Value Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| **Benefit overestimation** | Business case failure | Conservative estimates, ranges |
| **Implementation delays** | Delayed value | Phased approach, quick wins |
| **Adoption resistance** | Lower benefits | Change management, incentives |
| **Scope creep** | Cost overruns | Governance, change control |
| **External factors** | Market changes | Scenario planning, contingencies |

### Value at Risk (VaR) Analysis

**Sensitivity Analysis:**
- Best case (+20% benefits)
- Base case (planned benefits)
- Worst case (-20% benefits)

**Probability-Weighted Value:**
```
Expected Value = 
  (Best Case × 25%) + 
  (Base Case × 50%) + 
  (Worst Case × 25%)
```

---

## 7. Industry-Specific Value

### Financial Services
**Value Drivers:**
- ROE improvement (100bps = significant value)
- Cost-to-income ratio
- Capital efficiency
- Risk-adjusted returns

**Key Metrics:**
- NIM expansion
- Cost per transaction
- Credit cost reduction
- Regulatory cost avoidance

### Utilities
**Value Drivers:**
- Rate base growth
- O&M efficiency
- Capital productivity
- Regulatory outcomes

**Key Metrics:**
- Cost per customer
- SAIDI/SAIFI improvement
- Rate case success
- AFUDC benefits

### Public Sector
**Value Drivers:**
- Service delivery improvement
- Cost avoidance
- Compliance achievement
- Citizen satisfaction

**Key Metrics:**
- Cost per transaction
- Service level achievement
- Program uptake
- Audit findings reduction

---

## 8. Value Communication

### Executive Communication

**The Value Story:**
1. **The Challenge**: Current state pain
2. **The Solution**: Transformation approach
3. **The Value**: Quantified benefits
4. **The Investment**: Required resources
5. **The Return**: Financial metrics
6. **The Ask**: Decision needed

### Value Dashboards

**Executive Value Dashboard:**
```
┌─────────────────────────────────────────┐
│  TRANSFORMATION VALUE TRACKER          │
├─────────────────────────────────────────┤
│  Target Value:     $50M over 5 years   │
│  Realized to Date: $12M (24%)          │
│  Forecast:         On track            │
├─────────────────────────────────────────┤
│  Benefits by Category:                  │
│  💰 Cost:          $8M realized        │
│  ⚡ Efficiency:    $3M realized        │
│  📈 Revenue:       $1M realized        │
├─────────────────────────────────────────┤
│  Top Initiatives:                       │
│  ✅ ERP Implementation: $5M value      │
│  🔄 Process Optimization: $4M value    │
│  ⏳ Automation: In progress            │
└─────────────────────────────────────────┘
```

---

## Quick Reference: Value Checklist

**Business Case Development:**
- [ ] Problem/opportunity clearly defined
- [ ] Alternatives evaluated
- [ ] Benefits quantified (hard and soft)
- [ ] Costs comprehensive (capex, opex, TCO)
- [ ] Financial metrics calculated (NPV, IRR, ROI)
- [ ] Risks identified and mitigated
- [ ] Sensitivity analysis completed
- [ ] Approval sought at right level

**Benefits Realization:**
- [ ] Baseline established
- [ ] Targets set
- [ ] Owners assigned
- [ ] Measurement approach defined
- [ ] Tracking mechanism in place
- [ ] Review cadence established
- [ ] Accountability enforced

**Value Communication:**
- [ ] Executive summary clear
- [ ] Value story compelling
- [ ] Metrics easy to understand
- [ ] Progress visible
- [ ] Success celebrated
