---
name: change-management-adoption
description: >
  This skill should be used when the user asks about "change management",
  "adoption strategy", "stakeholder management", "resistance management",
  "transformation communication", "change impact assessment", "organizational
  change", "training strategy", "digital adoption platform", "change readiness",
  "OCM", "organizational change management", "Prosci ADKAR", "Kotter",
  "change management plan", "adoption measurement", "sustainment",
  "culture change", "change champion network", "change sponsor", "comms plan",
  "transformation communications", "people change", "behavior change",
  "change curve", "go-live readiness", "business readiness assessment",
  "training needs analysis", or "workforce transition".
version: 1.0.0
---

# Change Management and Adoption at Scale

Expert-level change management methodology for large-scale finance and enterprise transformation programmes. Apply to generate change management plans, stakeholder engagement strategies, communications calendars, training strategies, and adoption measurement frameworks.

## Why Change Management Determines Transformation Outcomes

Technology and process design deliver 30% of transformation value. The remaining 70% depends on **whether people actually change how they work**. Research consistently shows that change management is the number one differentiator between transformations that realize their business case and those that don't.

Finance transformations fail most commonly not because of ERP bugs or design flaws, but because:
- Finance staff revert to workarounds and shadow systems post-go-live
- Business partners reject new reporting and demand the old formats
- Leadership underestimates the depth of behavior change required
- Training is delivered too late, too theoretically, and not reinforced

## Change Management Framework

### The Prosci ADKAR Model — Applied to Finance Transformation

| Stage | Definition | Finance Transformation Application |
|-------|-----------|-----------------------------------|
| **Awareness** | Why is change necessary? | Burning platform: cost, data quality, competitive position, regulatory pressure |
| **Desire** | Personal motivation to support the change | WIIFM by role: "Your reporting job becomes more strategic; the system does the number-crunching" |
| **Knowledge** | How to change | Role-specific training, process walkthroughs, system demos |
| **Ability** | Practice makes permanent | Sandbox environments, supported parallel runs, floor walkers |
| **Reinforcement** | Sustaining the change | KPI monitoring, recognition programs, manager accountability |

**Diagnosis rule**: When adoption is failing, diagnose which ADKAR stage is blocked — don't apply generic solutions.

### Stakeholder Mapping and Engagement

#### Stakeholder Classification Matrix

Map every stakeholder group across two dimensions:
- **Y-axis**: Level of influence on programme success (High/Medium/Low)
- **X-axis**: Current disposition toward change (Champion/Neutral/Skeptic/Resistor)

**Engagement strategy by quadrant**:
- **High influence, Champion**: Activate as visible sponsors; give them a speaking role
- **High influence, Skeptic/Resistor**: Priority engagement; 1:1 with executive sponsor; address concerns directly
- **Low influence, Champion**: Recruit as change champions; peer influence is powerful
- **Low influence, Resistor**: Monitor; address through line management if needed

#### Key Stakeholder Groups in Finance Transformation

| Group | Primary Concern | Key Message | Engagement Channel |
|-------|----------------|------------|-------------------|
| CFO / Finance Leadership | Risk to close, compliance, and team | "This positions finance for the next decade" | Executive steering, co-sponsorship |
| FP&A Team | "My job is changing; am I redundant?" | "This upgrades your role from data management to strategic insight" | Workshops, demos, role design sessions |
| Controllers / Accountants | Process disruption, system complexity | "The new system does what you do manually in minutes" | Hands-on training, parallel run |
| Business Unit Finance Partners | Loss of local autonomy | "Global standards; local flexibility" | Business partner forums, co-design |
| IT Team | Support burden, integration complexity | "We're moving to a supported, maintained cloud platform" | Technical training, architecture reviews |
| Internal Audit / Compliance | Control gaps, audit risk | "Controls are stronger and automated; less manual evidence" | Controls design workshops |
| External Auditors | Familiarity with new system, evidence trail | "Audit trail is better documented and automated" | Briefings at key milestones |

## Change Impact Assessment

### How to Conduct a Change Impact Assessment

For each impacted process and role, score:

| Dimension | Score 1–5 | Notes |
|-----------|----------|-------|
| Process change complexity | 1=minor tweak, 5=completely new | |
| System change | 1=same system, new features; 5=entirely new platform | |
| Role impact | 1=minimal, 5=role eliminated or completely redefined | |
| Headcount impact | 1=no change, 5=significant reduction or redeployment | |
| Timing pressure | 1=long runway, 5=mandatory hard deadline | |

Sum score = **Change Severity Index (CSI)**. CSI >15 = High severity; 10–15 = Medium; <10 = Low.

High severity groups need: dedicated change resources, extended training, executive sponsorship visibility, and post-go-live support.

## Communications Strategy

### Communications Planning Principles

1. **Multi-channel**: Town halls + line manager cascades + intranet + team meetings + "Did You Know" emails
2. **Right time**: Communicate at decision milestones, not continuously (avoid "change fatigue")
3. **Role-specific**: Generic "we're upgrading our systems" messages land with zero impact — customize by audience
4. **Two-way**: Build feedback loops — pulse surveys, open Q&A sessions, anonymous question boxes

### Communications Calendar Structure

| Phase | Milestone | Message Theme | Channel | Owner |
|-------|-----------|--------------|---------|-------|
| Initiation | Programme launch | Why we're doing this; what it means for you | Town hall + email | CFO |
| Design | TOM approved | How your role changes; what we're designing | Team briefings | Workstream leads |
| Build | System demo | What the new system looks like; your input matters | Demo sessions | Project team |
| Test | UAT begins | Your chance to shape the final system | UAT participation invite | Change lead |
| Deploy | Go-live confirmed | What changes on Day 1; support available | All channels | Change lead + IT |
| Post Go-Live | +30/60/90 days | How it's going; here's where to get help | Pulse survey + update | Programme sponsor |

## Training Strategy

### Training Design Principles

- **Role-based, not system-based**: Train people on "how to do your job" not "how to click through screens."
- **Just-in-time**: Deliver training 2–4 weeks before go-live, not 3 months before.
- **Reinforced**: Follow-up simulations, floor walkers at go-live, reference guides, video snippets.
- **Leveled**: Distinguish between: Super Users (deep system knowledge), Power Users (role-specific), End Users (task-specific), Management (reporting and oversight only).

### Training Delivery Mix (Blended Approach)

| Format | Best For | Timing |
|--------|---------|--------|
| Instructor-led workshop | Complex processes, high interaction needed | 4–2 weeks pre-go-live |
| E-learning modules | Awareness, process concepts, policy | 8–4 weeks pre-go-live |
| System sandbox practice | Hands-on system navigation | 4–1 weeks pre-go-live |
| Job aids and reference cards | Day-of-go-live support | At go-live |
| Digital Adoption Platform (WalkMe, Whatfix) | Embedded in-system guidance | From go-live onwards |
| Hypercare floor walkers | High-touch support for first close | Weeks 1–4 post go-live |

## Adoption Measurement Framework

Define adoption KPIs before go-live; measure monthly for 12 months:

| KPI | Measurement Method | Target |
|-----|-------------------|--------|
| Training completion rate | LMS data | 100% before go-live |
| System login rate | System usage logs | >90% of expected users weekly |
| Self-sufficiency rate | % tickets resolved without escalation | >80% by Month 3 |
| Workaround usage rate | Audit of shadow spreadsheets, workaround trackers | <5% by Month 6 |
| Process compliance rate | Audit sampling of new process adherence | >95% by Month 3 |
| User satisfaction score | Pulse survey (1–10 NPS style) | >7.5 by Month 3 |
| Business case KPIs on track | Benefits tracking dashboard | As per plan |

## Change Champion Network

Build a network of 1 champion per 10 users, distributed across all business units:

- **Selection criteria**: Respected by peers, open to the change, willing to invest time
- **Activation**: Dedicated 2-day champion workshop before training rollout
- **Role**: Peer support at go-live, feedback conduit back to project team, local FAQ experts
- **Recognition**: Named in communications, included in leadership briefings, career benefit framing

## Additional Reference Materials

- **`references/stakeholder-frameworks.md`** — Stakeholder maps, engagement templates, resistance management playbook, communications calendar template
