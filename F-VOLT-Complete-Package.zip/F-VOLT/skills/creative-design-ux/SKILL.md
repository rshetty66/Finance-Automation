---
name: creative-design-ux
description: >
  This skill should be used when the user asks about "slide design", "presentation
  design", "visual design", "UX", "user experience", "UI design", "dashboard design",
  "data visualization", "infographic", "design principles", "typography",
  "color palette", "layout", "visual hierarchy", "white space", "design thinking",
  "executive presentation aesthetics", "board pack design", "PowerPoint design",
  "McKinsey-style slides", "Big 4 deck", "consulting deck", "slide makeover",
  "visual storytelling", "chart design", "data visualization best practices",
  "Gestalt principles", "design for executives", "modern design", "brand design",
  "professional aesthetics", "make this look better", "improve the visual",
  "redesign this slide", "cleaner layout", or "more impactful design".
version: 1.0.0
---

# Creative Design and UX Excellence

Expert-level design methodology for creating visually stunning, executive-grade presentations, dashboards, documents, and digital experiences. Apply to transform raw content into high-impact visual communication that commands attention, builds credibility, and drives decisions.

## The Design Principle: Clarity is the New Intelligence

In executive and consulting contexts, **the quality of your visual communication directly signals the quality of your thinking**. A poorly designed slide doesn't just look bad — it implies unclear thinking. A beautifully structured, precisely designed slide communicates mastery before a word is spoken.

Design is not decoration. Design is **structured communication at the speed of sight**.

## The Six Laws of Executive-Grade Design

### Law 1: Ruthless Simplicity
Every element on a page must earn its place. Remove anything that doesn't add meaning. White space is not empty space — it is breathing room that directs attention. The test: cover each element and ask "does the message survive without this?" If yes, delete it.

### Law 2: Visual Hierarchy Rules
The eye moves in a predictable pattern (Z or F pattern for Western audiences). Design **must** direct this journey:
- **Biggest element** = Most important message
- **Bold/color accent** = Second-level attention
- **Regular text** = Supporting detail
- Never compete at the same visual weight — hierarchy must be unambiguous

### Law 3: One Idea Per Slide
A slide with three ideas has zero ideas. Each slide should answer exactly one question or make exactly one assertion. The slide title is the answer; the content is the evidence.

### Law 4: Data Visualization Integrity
Charts must **reveal** patterns, not obscure them:
- Match chart type to data relationship (see chart selection guide below)
- Always label data points that matter; remove chart junk (unnecessary gridlines, legends, 3D effects)
- Color means something — use it consistently and sparingly
- Never truncate Y-axes to exaggerate trends

### Law 5: Color as Signal
- **Primary color**: The brand/theme anchor (1 color)
- **Accent color**: Used only for the most important insight on the slide (1 color)
- **Neutral grays**: For everything else (2–3 tones)
- **Red/Amber/Green**: Reserved exclusively for status indicators
- Maximum 4 colors on any single slide. Fewer is almost always better.

### Law 6: Typography Discipline
- Maximum 2 font families per document (heading + body)
- Recommended pairing: Inter/Calibri/Helvetica Neue (body) + Poppins/Montserrat/Gilroy (heading)
- Font size hierarchy: Title (28–36pt), Key message (20–24pt), Body (14–16pt), Labels (10–12pt)
- Never go below 10pt in a presentation intended for projection
- Left-align body text; center only for headings or isolated callouts

## Executive Slide Architecture

### The SCQA Slide Structure (McKinsey Standard)
Every slide follows: **S**ituation → **C**omplication → **Q**uestion → **A**nswer
- **Situation**: What everyone knows (brief)
- **Complication**: What has changed or is wrong
- **Question**: What decision/action is needed
- **Answer**: The recommendation (this is the slide title, stated as a conclusion)

**Slide title rule**: State the insight, not the topic.
- ❌ "Revenue Performance" → ❌ Generic, forces reader to interpret
- ✅ "Revenue grew 12% YoY but margin compressed 180bps — action required" → ✅ Drives action

### Slide Types and When to Use Each

| Slide Type | Purpose | Key Design Rule |
|------------|---------|-----------------|
| **Title/Divider** | Section breaks, agenda | Full bleed color/image; minimal text |
| **Executive Summary** | Key findings (3–5) | Numbered list; no more than 3 lines per point |
| **Data/Chart** | Quantitative insight | One chart; annotated with the key insight |
| **Process/Flow** | Sequential logic | Left-to-right or top-to-bottom; max 6 steps |
| **Comparison Matrix** | Options vs. criteria | Color-coded scoring; clear recommendation highlighted |
| **Org Chart/TOM** | Structure visualization | Boxes and lines; color-code by category |
| **Roadmap/Timeline** | Phases and milestones | Swim lanes or horizontal bar; key milestones marked |
| **Quote/Callout** | Emphasis | Large font; attributed; background accent |

### Chart Type Selection Guide

| Data Relationship | Chart Type | Avoid |
|-----------------|-----------|-------|
| Trend over time | Line chart | Pie chart |
| Part-to-whole | Stacked bar or Treemap | 3D pie, donut with many segments |
| Comparison (few items) | Grouped bar | Radar/spider chart |
| Ranking | Horizontal bar | Vertical bar for long labels |
| Correlation | Scatter plot | Line chart |
| Distribution | Histogram or Box plot | Bar chart |
| Geographic | Map/choropleth | Table |
| Single number vs. target | Bullet chart or KPI card | Gauge/speedometer |

## Dashboard Design Excellence

### The CFO Dashboard Design Hierarchy

Design every finance dashboard with four layers:
1. **Strategic layer** (top): 3–5 enterprise KPIs; color-coded vs. target; trend arrow
2. **Performance layer** (middle): Function-level metrics with period-on-period comparison
3. **Diagnostic layer** (below fold): Drill-down charts for root cause analysis
4. **Action layer** (contextual): Alerts, exceptions, items requiring attention

### Dashboard UX Principles

- **Mobile-first mindset**: Design as if it will be read on a phone in a taxi — the critical insight must survive that test
- **No scroll for the headline**: The most important 3 KPIs must be visible without scrolling
- **Consistent color coding**: Red always means bad; green always means good — never invert
- **Progressive disclosure**: Summary → Detail → Data — never dump everything on one screen
- **Interaction design**: Filters and drill-downs should be discoverable, not hidden
- **Loading time is UX**: A beautiful dashboard that loads in 15 seconds is a bad dashboard

## Modern Design Aesthetic: 2024–2025 Executive Standards

### What Works Now
- **Generous white space**: Sophisticated, confident, easy to read
- **Muted, sophisticated color palettes**: Slate blues, warm neutrals, charcoal — not primary colors
- **Large typography for key messages**: The headline is a visual element, not just text
- **Photography and illustration**: Used sparingly but powerfully — abstract/conceptual imagery over stock photography
- **Data-forward layouts**: The chart is the hero — design around the data, not around decorative frames
- **Subtle gradients and depth**: Replace flat boxes with subtle shadows and layering

### What to Retire
- Drop shadows on every box
- Clipart and generic stock photos
- Rainbow color palettes
- 3D charts of any kind
- WordArt and decorative fonts
- Busy backgrounds behind text
- Tables as the primary data display

## Design Thinking Applied to Finance Transformation

When designing any deliverable (presentation, report, dashboard, tool), apply the Design Thinking process:

1. **Empathize**: Who is the audience? What do they need to decide? What do they already know?
2. **Define**: What is the one thing this communication must achieve?
3. **Ideate**: What are three different ways to structure/visualize this?
4. **Prototype**: Sketch the layout before building it (even a hand-drawn wireframe saves hours)
5. **Test**: Show it to someone not on the team — what do they read first? Is that what you intended?

## Additional Reference Materials

- **`references/design-system.md`** — Color palettes, typography stacks, slide templates, icon libraries, chart templates, and design patterns for consulting deliverables
