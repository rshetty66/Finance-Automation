---
name: finance-transformation-core
description: >
  This skill should be used when the user asks about "finance transformation",
  "target operating model", "TOM design", "operating model redesign",
  "finance function redesign", "shared services", "global business services",
  "GBS", "finance centre of excellence", "finance CoE", "transformation
  programme governance", "transformation roadmap", "finance strategy",
  "CFO agenda", "corporate function redesign", or needs to design, assess,
  or govern a finance transformation programme. Also triggers for "finance
  maturity assessment", "transformation business case", "transformation
  PMO", "transformation governance", or "transformation delivery".
version: 1.0.0
---

# Finance Transformation Core Methodology

Expert-level methodology for designing, governing, and delivering end-to-end finance transformation programmes. Apply this knowledge to generate board-ready strategy documents, operating model blueprints, governance frameworks, and transformation roadmaps.

## The Finance Transformation Imperative

Finance functions are under sustained pressure to simultaneously reduce cost, improve speed and quality of insight, manage regulatory complexity, and enable digital business models. The CFO agenda has expanded from stewardship and control to value creation, strategic partnership, and enterprise-wide data trust.

A successful transformation addresses **four interdependent dimensions**:
1. **Process** — Standardize, simplify, and automate finance processes end-to-end
2. **Data** — Establish a single source of truth across planning, reporting, and control
3. **Technology** — Deploy fit-for-purpose ERP, EPM, and analytics platforms
4. **People & Organization** — Redesign roles, develop capabilities, and drive adoption

## Target Operating Model (TOM) Design

### TOM Framework: Five Design Layers

Design every TOM across these layers (always in this sequence — top-down):

| Layer | Questions to Answer |
|-------|-------------------|
| **1. Strategy & Ambition** | What role should finance play? Cost leader, business partner, or insight engine? What is the 3–5 year aspiration? |
| **2. Service Model** | Which activities sit where? (Transaction processing, control, reporting, business partnering, CoE, outsourced) |
| **3. Process Architecture** | Which processes are standardized globally vs locally differentiated? What is the E2E process flow? |
| **4. Organization Design** | What is the structure, span of control, layer count, role taxonomy, and headcount shape? |
| **5. Technology Enablement** | Which systems, tools, and automation capabilities enable the service model? |

### Finance Activity Classification

Classify all finance activities across three zones:

- **Run** (keep the lights on): Transactional processing, statutory compliance, period close — standardize, automate, or outsource.
- **Control** (protect the business): Financial controls, risk management, regulatory reporting — retain in finance with strong governance.
- **Partner** (grow the business): FP&A, business partnering, strategic analysis, M&A support — invest and elevate.

### Operating Model Archetypes

| Archetype | Description | Best For |
|-----------|-------------|----------|
| **Decentralized** | Finance embedded in business units; high local agility | Early-stage, high-diversity organizations |
| **Centralized CoE** | Specialist functions centralized; business partners retained locally | Mature organizations seeking expertise depth |
| **Shared Services** | Transactional activities consolidated into SSC/GBS | Cost reduction at scale; 1,000+ FTE finance |
| **Global Business Services (GBS)** | Multi-function shared services (Finance + HR + IT + Procurement) | Large multinationals post-ERP standardization |
| **Hybrid** | Mix of above; most common in practice | Most complex organizations |

### TOM Sizing and Benchmarks

Use these benchmarks to size the future-state TOM:

| Metric | Median (Top Quartile) | Notes |
|--------|----------------------|-------|
| Finance cost as % of revenue | 0.7–1.0% (0.4–0.6%) | Varies by industry |
| Finance FTEs per $1B revenue | 50–80 (25–40) | Lower in financial services |
| Close cycle (calendar days) | 5–7 (3–4) | Statutory close |
| Planning cycle time | 8–12 weeks (4–6 weeks) | Annual budget |
| Forecast accuracy (revenue) | ±5–8% (±2–3%) | 3-month rolling |

## Transformation Programme Governance

### Governance Structure (Five Bodies)

1. **Transformation Steering Committee** — Executive sponsors (CFO, CIO, CHRO). Meets monthly. Owns programme mandate, budget, and escalation.
2. **Programme Management Office (PMO)** — Cross-functional coordination, RAID management, status reporting, dependencies, financials.
3. **Workstream Leads Forum** — Weekly cross-stream coordination. Dependencies, blockers, design consistency.
4. **Business Readiness Board** — Change management, training progress, adoption KPIs, cutover readiness.
5. **Architecture & Controls Review Board** — Technology design, integration, security, controls sign-off.

### RAID Management

Maintain a live RAID log (Risks, Assumptions, Issues, Dependencies) with these minimum fields per item: ID, Category, Description, Probability (H/M/L), Impact (H/M/L), Owner, Mitigation/Action, Status, Due Date, Trend.

### Tollgate Review Model

| Tollgate | When | Decision |
|----------|------|---------|
| G0: Initiation | Programme kickoff | Approve charter, governance, budget |
| G1: Discovery Complete | End of assess phase | Approve current-state findings, approve TOM options |
| G2: Design Approved | End of design phase | Approve future-state TOM, solution architecture, business case |
| G3: Build Ready | End of build phase | Approve test results, approve cutover plan |
| G4: Go-Live | Pre-cutover | Approve go-live readiness, confirm hypercare |
| G5: Benefits Realization | 6–12 months post go-live | Confirm benefits achieved, close programme |

## Transformation Phases

### Standard Phase Model (Assess → Design → Build → Deploy → Sustain)

**Phase 1: Assess (4–8 weeks)**
- Current state mapping (process, data, technology, organization)
- Maturity assessment and benchmark comparison
- Stakeholder interviews and pain point analysis
- Value opportunity identification and sizing
- Transformation case for change

**Phase 2: Design (8–16 weeks)**
- Future-state TOM design across all five layers
- Process design (L1–L4 process maps)
- Solution architecture (ERP/EPM/data/analytics)
- Organization design (structure, roles, headcount)
- Business case finalization

**Phase 3: Build (16–52 weeks, varies)**
- ERP/EPM configuration and development
- Integration build and testing
- Data migration execution
- Change management and training delivery
- UAT and performance testing

**Phase 4: Deploy (4–8 weeks per wave)**
- Cutover planning and execution
- Go-live support and hypercare (4–8 weeks)
- Issue resolution and stabilization

**Phase 5: Sustain (ongoing)**
- Benefits tracking against business case
- Adoption measurement and sustainment
- Continuous improvement backlog
- Model governance and change control

## Finance Transformation KPI Framework

Connect every TOM design decision to measurable outcomes:

| Transformation Pillar | KPI | Target Direction |
|----------------------|-----|-----------------|
| Close Acceleration | Calendar days to close | ↓ |
| Planning Agility | Forecast accuracy (%) | ↑ |
| Finance Efficiency | Finance cost as % revenue | ↓ |
| Data Trust | Data quality score (%) | ↑ |
| Control Strength | Open audit findings | ↓ |
| Business Partnering | Insight-to-decision cycle time | ↓ |
| Technology Utilization | ERP/EPM adoption rate (%) | ↑ |

## Additional Reference Materials

- **`references/tom-frameworks.md`** — Detailed TOM design frameworks, role taxonomies, sourcing decision trees
- **`references/governance-model.md`** — Full governance templates, RAID log, tollgate review checklists, programme reporting
