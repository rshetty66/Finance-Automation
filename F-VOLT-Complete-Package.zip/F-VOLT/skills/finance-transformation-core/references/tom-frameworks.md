# TOM Design Frameworks — Extended Reference

## Finance Activity Taxonomy (Level 1)

Complete taxonomy of all finance function activities for TOM scoping:

### Record-to-Report (R2R)
- General ledger management and chart of accounts governance
- Period close management (month, quarter, year-end)
- Financial consolidation and group reporting
- Intercompany reconciliation and elimination
- Fixed asset accounting and depreciation
- Statutory and regulatory financial reporting
- External audit management
- XBRL/iXBRL filing and regulatory submissions

### Order-to-Cash (O2C)
- Customer credit management and credit limit setting
- Invoicing and billing
- Accounts receivable management
- Cash application and reconciliation
- Collections and dispute management
- Revenue recognition (ASC 606 / IFRS 15)

### Purchase-to-Pay (P2P)
- Procurement and purchase order management
- Supplier onboarding and master data
- Invoice processing and three-way matching
- Accounts payable management
- Payment execution and treasury settlement
- Travel and expense management

### Financial Planning & Analysis (FP&A)
- Strategic planning and long-range financial modelling
- Annual budgeting and target-setting
- Rolling forecasting and scenario planning
- Management reporting and performance analysis
- Business partnering and commercial support
- Capital allocation and investment analysis
- M&A financial support and integration

### Treasury and Risk Finance
- Cash management and liquidity forecasting
- Foreign exchange risk management and hedging
- Debt and capital structure management
- Insurance and risk financing
- Interest rate risk management

### Tax and Statutory
- Corporate tax compliance and provision
- Indirect tax (VAT/GST) compliance and reporting
- Transfer pricing documentation and compliance
- Tax planning and optimization
- Country-by-country reporting (CbCR)

### Controls and Governance
- Internal control design and documentation (SOX/ICFR)
- Control testing and self-assessment
- Accounting policy management
- Model risk management (for financial institutions)
- Third-party and vendor risk for finance systems

## Role Taxonomy — Finance TOM

### Corporate Centre Roles
- Group CFO / Finance Director
- Group Controller
- Group FP&A Director
- Group Treasury Director
- Group Tax Director
- Group Compliance and Controls Director

### Centre of Excellence Roles
- Finance CoE Lead
- EPM Solution Architect / Finance Systems Lead
- Finance Data Governance Manager
- Finance Process Architect
- Finance Automation Lead

### Shared Services / GBS Roles
- R2R Process Lead
- AP / AR Team Lead
- Payroll Manager
- Finance Operations Manager

### Business Finance Roles
- Business Unit CFO / Finance Director
- Commercial Finance Manager / Finance Business Partner
- FP&A Manager
- Financial Controller

## Sourcing Decision Framework

Apply these criteria to each finance activity zone:

| Criterion | Keep In-House | Shared Services / GBS | CoE | Outsource / BPO |
|-----------|-------------|----------------------|-----|-----------------|
| Strategic sensitivity | ★★★★★ | ★★ | ★★★ | ★ |
| Volume and repeatability | ★ | ★★★★★ | ★★ | ★★★★★ |
| Specialization required | ★★ | ★★★ | ★★★★★ | ★★ |
| Control / regulatory risk | ★★★★★ | ★★★ | ★★★★ | ★★ |
| Cost efficiency potential | ★ | ★★★★ | ★★★ | ★★★★★ |

## Span of Control Benchmarks

| Level | Finance Role | Recommended Span |
|-------|-------------|-----------------|
| CFO | Direct reports | 5–8 |
| VP Finance / Controller | Direct reports | 6–10 |
| Finance Manager | Individual contributors | 6–12 |
| Team Lead | Analysts/Accountants | 8–15 |

## Layer Reduction Principles

In most finance TOM redesigns, reducing management layers from 6–7 to 4–5 improves speed, accountability, and cost. Guidelines:
- Every layer must add decision-making value, not just information relay
- Front-line roles (analysts, accountants) should never be more than 3 layers from VP-level
- Avoid "coordinator" roles without genuine decision authority
