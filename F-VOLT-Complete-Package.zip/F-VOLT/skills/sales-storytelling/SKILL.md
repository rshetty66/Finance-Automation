---
name: sales-storytelling
description: >
  This skill should be used when the user asks about "storytelling", "narrative",
  "TED talk", "executive presentation", "sales pitch", "pitch deck", "deal shaping",
  "win strategy", "proposition", "POV", "point of view", "client pitch",
  "RFP response", "how to present", "structure a presentation", "opening hook",
  "public speaking", "presenting to the board", "board presentation", "C-suite
  presentation", "persuasion", "influence", "compelling narrative",
  "story structure", "hero's journey", "three-act structure", "STAR story",
  "SCQA", "pyramid principle", "Minto", "Barbara Minto", "elevator pitch",
  "pitch perfect", "how to be more persuasive", "how to open a presentation",
  "how to close a deal", "executive communication", "thought leadership",
  "conference talk", "keynote", "inspire an audience", "make it compelling",
  "make it memorable", "emotional connection", "audience engagement",
  "objection handling", or "how to tell a story with data".
version: 1.0.0
---

# Sales Excellence, Storytelling, and TED-Quality Communication

Expert-level frameworks for crafting and delivering high-impact narratives — from C-suite deal pitches and board presentations to TED-style keynotes and compelling thought leadership. Apply to build pitches that win, presentations that inspire, and stories that get remembered.

## The Core Insight: Logic Informs, Story Persuades

Facts are forgotten. Stories are remembered. Decisions are made with emotion and justified with logic. The most effective communicators — from TED speakers to McKinsey partners to CFOs — understand that **you must first make someone feel before you can make them think**.

The formula: **Story → Insight → Evidence → Call to Action**

## Story Architecture Frameworks

### Framework 1: The Minto Pyramid Principle (for advisory/analytical contexts)

Developed by Barbara Minto at McKinsey. Structure every piece of communication top-down:

```
CONCLUSION / RECOMMENDATION (lead with the answer)
    ↓
Supporting Argument 1 | Supporting Argument 2 | Supporting Argument 3
    ↓                         ↓                        ↓
Evidence              Evidence              Evidence
```

**Rule**: Never make the audience wait for your point. State your recommendation in sentence 1, then prove it. This is the opposite of how most people present (they build up to the conclusion) — but it's how executives prefer to receive information.

### Framework 2: SCQA (Situation-Complication-Question-Answer)

The McKinsey narrative structure, ideal for executive briefings and consulting proposals:

- **Situation**: Ground the audience in shared reality ("Our finance function currently closes in 8 days...")
- **Complication**: Introduce the tension or change ("...but competitors are closing in 4 days, and our regulators now expect real-time reporting...")
- **Question**: Articulate the decision needed ("...so how do we transform our close without disrupting the business?")
- **Answer**: Deliver your recommendation immediately ("We recommend a phased EPM modernization that cuts close time by 40% within 18 months.")

### Framework 3: The TED Story Arc (for keynotes, conferences, thought leadership)

TED's formula for talks that change minds:

1. **The Hook** (0–90 seconds): Open with a question, provocation, surprising statistic, or micro-story. Never start with "I'm delighted to be here today."
2. **The Tension** (context): What is broken, at risk, or misunderstood? Create intellectual tension that demands resolution.
3. **The Journey** (your insight): Walk them through how you discovered the idea, what changed your thinking, what you learned.
4. **The Evidence** (proof): Data, case study, demonstration — the rational backbone.
5. **The Vision** (possibility): Paint a picture of the world if the idea is adopted.
6. **The Call**: Specific, personal, achievable — what can one person do tomorrow?

**The TED Rule**: One idea, stated clearly enough that you can write it on a Post-It note. Everything else serves that one idea.

### Framework 4: The Hero's Journey (for transformation narratives)

Map the client's transformation story to the hero's journey:

| Stage | Narrative Application |
|-------|----------------------|
| **The Ordinary World** | "Today, your finance team spends 60% of close week firefighting..." |
| **The Call to Adventure** | "The competitive and regulatory landscape demands more..." |
| **Refusal of the Call** | "We know change feels risky..." |
| **Meeting the Mentor** | "That's why you've engaged [our firm]..." |
| **Crossing the Threshold** | "Together, we'll begin the transformation journey..." |
| **Tests and Trials** | "There will be hard moments — data migration, parallel runs, change resistance..." |
| **The Transformation** | "Your finance team, freed from manual work, becomes a true strategic partner..." |
| **The Return** | "And the business benefits: faster decisions, lower cost, better compliance..." |

The client is always the hero. You (the advisor/vendor) are always the mentor — never the hero.

## Opening Hooks: The First 30 Seconds Win or Lose the Room

### Proven Opening Types

| Hook Type | Example | When to Use |
|-----------|---------|------------|
| **Provocative statistic** | "70% of ERP implementations fail to achieve their business case. Yours won't." | Sales pitches, conference talks |
| **Micro-story** | "Two years ago, a CFO called me on a Sunday night — her company's year-end close had just collapsed..." | Thought leadership, keynotes |
| **Contrarian claim** | "The biggest risk to your AI programme isn't technology. It's your Excel addiction." | Conferences, workshops |
| **Direct question** | "How many of you have ever been asked to justify your finance transformation investment — and couldn't?" | Workshops, interactive sessions |
| **Future picture** | "Imagine your close is done by Day 2. Your forecast updates itself overnight. Your CFO starts Monday with live actuals." | Vision pitches |
| **Challenge assumption** | "We've been told that closing in 3 days is impossible for an organization of our complexity. That's wrong." | Board presentations |

**Never open with**: Your name, your firm's history, an agenda slide, or "Thank you for having me."

## Persuasion and Influence Architecture

### The Cialdini Principles — Applied to Finance Transformation Sales

| Principle | Application |
|-----------|------------|
| **Social Proof** | "Three of the top 5 Canadian banks have already made this move. Here's what they learned." |
| **Authority** | Reference frameworks (NIST, Gartner, KPMG benchmarks), your 25 years of direct experience |
| **Scarcity/Urgency** | "The regulatory window to comply with DORA closes in Q4. Starting now gives you a 90-day buffer." |
| **Reciprocity** | Bring unique insight to every meeting — even if they don't buy, they learned something |
| **Commitment and Consistency** | "You said in our last meeting that data quality was your #1 priority. This solves exactly that." |
| **Liking** | Mirror the client's language; reference their specific context, not generic examples |

### Objection Handling Framework: APEEL

When an objection is raised, respond using **APEEL**:
- **A**cknowledge: "That's a fair challenge."
- **P**ause: Don't rush to defend. The pause signals confidence.
- **E**xplore: "Can you tell me more about what's driving that concern?"
- **E**vidence: Address with specific, relevant proof.
- **L**ead: Redirect to the next step. "Given that, would it help to see the reference client who had the same concern?"

### Top Finance Transformation Objections and Responses

| Objection | Response Strategy |
|-----------|------------------|
| "We tried ERP before and it failed." | Acknowledge the pain → Diagnose why it failed → Differentiate how this is different (methodology, governance, your experience with that exact failure mode) |
| "We don't have the budget." | Quantify the cost of inaction → Show ROI with payback period → Explore phasing to fit budget cycles |
| "Our IT team will resist." | Reframe IT as co-owner → Show evidence of IT-led wins → Offer IT leadership advisory as part of scope |
| "We're too complex for a standard approach." | Use their complexity as proof they need more expertise, not less → Reference comparable-complexity client |
| "Why you vs. [competitor]?" | Prepare a crisp differentiation table → Focus on your unique points of proof → Win on fit, not on features |

## Data Storytelling: Making Numbers Human

### The Data Narrative Formula

Numbers alone don't persuade. Context + Comparison + Consequence = Compelling:

- **Without story**: "Our close time is 8 days."
- **With story**: "Our close time is 8 days — that's 4 days longer than our top competitors and costs us approximately $2.4M in finance overtime and delayed decisions each year. Every day we don't fix this is a day we're making capital allocation decisions without full-period visibility."

### Visualization for Story (not just information)

- **Callout the insight, not the chart**: Add a text box stating what the chart means — "Revenue growth slowing for 3 consecutive quarters" not just the chart title "Revenue Trend"
- **Animate for narrative effect**: In live presentations, reveal data progressively — don't show the full chart at once
- **Before/After architecture**: The most powerful data story shows the gap between current state and future state

## The World-Class Presenter: Ten Non-Negotiables

1. **Rehearse the opening 3 minutes until it's unconscious** — nerves are highest at the start
2. **Speak to one person at a time** — sustained 3-second eye contact per person creates connection
3. **Silence is power** — pause after key points; let the idea land
4. **Vary pace and volume** — monotone kills ideas; energy signals importance
5. **Don't read slides** — if your slides can deliver the message without you, you're unnecessary
6. **Acknowledge the elephant** — if there's a known concern in the room, address it first; ignoring it destroys credibility
7. **Stories over statistics** — lead with story, follow with data; never lead with data
8. **Know your 90-second version** — be ready to compress any presentation to 90 seconds without losing the core
9. **Close with action, not "any questions?"** — "Here's what I'm recommending we do next..." then questions
10. **Record yourself once** — you will discover the habits you don't know you have

## Additional Reference Materials

- **`references/story-templates.md`** — SCQA templates, MINTO worksheet, TED arc planner, objection handling playbook, elevator pitch builder, pitch deck templates for finance transformation contexts
