# Story and Pitch Templates

## Elevator Pitch Template (90 seconds)

```
For [specific client type] who [specific problem they have],
[Your offering] is a [category] that [key differentiator].
Unlike [named competitor or generic alternative],
[your solution] [specific proof point — time, cost, outcome].
We've done this for [reference client type] — they achieved [specific result].
The question is: can you afford not to?
```

## Executive Email Template (C-Suite Cold/Warm Outreach)

```
Subject: [Specific to their stated priority or public event — not generic]

[CFO Name],

[Opening hook — 1 sentence that demonstrates you've done your homework. Reference their recent earnings call, regulatory challenge, or public statement.]

[The problem, stated specifically]: Most [type of organization] at your scale are [experiencing X pain]. Based on what I've seen across [relevant reference clients], the underlying issue is [specific diagnosis — 1 sentence].

[Your POV — 1 sentence]: The organizations closing this gap fastest are doing [specific thing differently].

[Social proof — 1 sentence]: We recently helped [comparable organization type] [specific outcome — metric].

[Ask — low friction]: I'd welcome 20 minutes to share what we're seeing and hear whether it resonates with your priorities. [Specific day/time offer or calendar link.]

[Your name]
[Title — state seniority]
[Direct contact]
```

## SCQA Story Template for Executive Presentation

```
SITUATION (1–2 sentences — shared reality, not new information):
"Today, [organization] operates with [current state — describe what's true].
This has served us well in [context where it worked]."

COMPLICATION (1–2 sentences — what has changed):
"However, [external force / internal pressure / competitive shift] means that
[continuing the status quo creates specific risk or cost]."

QUESTION (1 sentence — the decision the audience must make):
"The question before us today is: [specific decision or recommendation request]."

ANSWER (lead immediately with the recommendation):
"Our recommendation is [specific action] because [top 3 reasons, each quantified where possible]."
```

## TED Opening Hook Templates

**The Question Hook**:
"How many of you have been in a steering committee meeting where the CFO asked 'how are we tracking to our business case?' and nobody could answer? [Pause.] That's the problem we're here to solve today."

**The Statistic Hook**:
"Here's a number: 70%. That's how many ERP implementations fail to deliver their intended business case. And yet, finance teams around the world are about to make the same mistakes that led to that number. Today, I want to show you how to be in the 30%."

**The Story Hook**:
"Three years ago, I got a call at 11pm on a Sunday. The CFO of a major bank was on the line. Her company had just gone live on a new ERP. Monday morning, 4,000 people would log in to find a system that didn't match their month-end close. She had six hours to decide: go back or push forward. What would you have done?"

**The Contrarian Hook**:
"Everything you've been told about finance transformation is wrong. Not slightly off — fundamentally wrong. The industry has been selling you transformation methodology when what you actually need is transformation *outcomes*. Let me show you the difference."
