# Finance KPI Library — Extended Reference

## Financial Services Sector KPI Adjustments

For banking, insurance, and asset management contexts, apply these sector-specific adjustments:

### Banking Finance KPIs
| KPI | Banking Benchmark | Notes |
|-----|-----------------|-------|
| Finance cost as % of total revenue | 0.2–0.4% | Lower than non-FSI due to revenue scale |
| Close cycle time | 3–5 days (regulatory) | Regulatory filing deadline drives absolute limit |
| IFRS 9 ECL forecasting accuracy | ±10% at portfolio level | Variance vs. actual credit losses |
| Regulatory filing on time | 100% | Non-negotiable; regulatory penalty exposure |
| RAROC reporting cycle | T+3 (trading) to T+30 (quarterly) | Risk-adjusted return on capital |
| Stress test cycle time | <2 weeks (ad hoc), <4 weeks (regulatory) | DFAST/CCAR/ICAAP scenarios |

### Insurance Finance KPIs
| KPI | Insurance Benchmark | Notes |
|-----|-------------------|-------|
| IFRS 17 close cycle | <10 days for full close | Contractual Service Margin (CSM) calculation complexity |
| Actuarial assumption refresh cycle | Quarterly (best practice) | vs. annual (legacy) |
| Combined ratio reporting cycle | T+7 | Underwriting result speed |
| Regulatory Solvency reporting | As per local jurisdiction | Solvency II / ORSA / LICAT |

### Asset Management Finance KPIs
| KPI | AM Benchmark | Notes |
|-----|-------------|-------|
| NAV calculation cycle | T+1 (daily), T+0 (target) | Net Asset Value per fund |
| Fee revenue reconciliation | T+3 | Management fee vs. AUM |
| Fund reporting close | T+5 | Fund financial statements |

## Transformation Investment KPI Benchmarks

Based on comparable Finance Transformation programmes:

| Programme Type | Typical Investment | Typical Benefits (5-year NPV) | Payback |
|----------------|-------------------|-------------------------------|---------|
| ERP Cloud (mid-size enterprise) | $15–40M | $20–60M | 2–3 years |
| EPM Cloud (Oracle/Anaplan/OneStream) | $5–20M | $15–45M | 1.5–2.5 years |
| Finance AI/automation programme | $3–10M | $8–25M | 1–2 years |
| Full Finance Transformation (TOM+ERP+EPM) | $40–150M | $80–250M | 2.5–4 years |
| Shared Services / GBS setup | $10–30M | $25–60M | 2–3 years |

## Benefits Quantification Formulas

### FTE Savings
```
Annual savings = FTE reduction × Fully-loaded cost per FTE
Fully-loaded cost = Base salary × 1.3 (benefits + overhead)
Typical finance FTE cost: $90K–$150K fully loaded (region-dependent)
```

### Close Acceleration
```
Annual savings = Days saved × Finance operations cost per close day
Finance ops cost per close day ≈ (close-week FTE × daily cost) + overtime + error correction
```

### Forecast Accuracy Improvement
```
Working capital benefit = (Average working capital) × (Forecast error reduction %) × (Cost of capital %)
Example: $500M WC × 3% error reduction × 8% cost of capital = $1.2M annual benefit
```

### External Audit Cost Reduction
```
Annual savings = (Hours saved by automated evidence) × (Blended audit hourly rate)
Typical external audit rate: $150–$350/hour depending on firm and location
```
