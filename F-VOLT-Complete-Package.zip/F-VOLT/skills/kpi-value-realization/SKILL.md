---
name: kpi-value-realization
description: >
  This skill should be used when the user asks about "KPIs", "key performance
  indicators", "metrics", "value case", "business case", "ROI", "IRR", "NPV",
  "payback period", "benefits realization", "value tracking", "value
  quantification", "finance transformation value", "ERP ROI", "EPM ROI",
  "AI ROI", "transformation benefits", "KPI framework", "KPI taxonomy",
  "KPI dashboard", "balanced scorecard", "OKRs for finance", "finance metrics",
  "FP&A metrics", "close metrics", "reporting metrics", "transformation
  investment case", "cost-benefit analysis", "financial model for transformation",
  "value realization office", "benefits tracking", "CFO dashboard metrics",
  "finance efficiency metrics", or "connecting financials to transformation".
version: 1.0.0
---

# KPI Frameworks and Value Realization

Expert-level methodology for designing KPI taxonomies, building transformation business cases, and tracking value realization across finance transformation programmes. Apply to generate KPI frameworks, financial models, value cases, and benefits tracking dashboards.

## The Finance Transformation Value Thesis

Every transformation investment must answer one question for the CFO: **"What does this do to our P&L, balance sheet, and risk profile over the next 3–5 years?"**

Value in finance transformation comes from four levers:
1. **Cost reduction**: Fewer FTEs on transactional activities; lower technology TCO; reduced audit/compliance cost
2. **Revenue enablement**: Faster, better quality insight enabling faster business decisions; improved capital allocation
3. **Risk reduction**: Stronger controls, fewer audit findings, lower regulatory penalty exposure
4. **Strategic optionality**: Scalable platform enabling M&A, new business models, geographic expansion

## KPI Taxonomy: The Finance Transformation KPI Compass

### Dimension 1: Close and Consolidation Performance

| KPI | Definition | Measurement | Benchmark |
|-----|-----------|-------------|-----------|
| Close cycle time | Calendar days from period end to signed-off financials | Days | 3–5 days (top quartile) |
| Manual journal entry volume | # of manual JEs per period | Count | <30% of total (top quartile) |
| Close defect rate | # of errors/restatements per close | Count | <2% per period |
| Intercompany reconciliation completion | % of ICO items matched by Day 3 | % | >95% |
| Account reconciliation completion | % of balance sheet accounts reconciled by Day 5 | % | >99% |
| Audit adjustment rate | # of auditor-required adjustments per year | Count | 0 (target) |

### Dimension 2: Planning and Forecasting Quality

| KPI | Definition | Measurement | Benchmark |
|-----|-----------|-------------|-----------|
| Revenue forecast accuracy | Absolute % variance: forecast vs actual at 3 months out | % | ±2–3% (top quartile) |
| Cost forecast accuracy | Absolute % variance: cost forecast vs actual | % | ±3–5% (top quartile) |
| Annual budget cycle time | Weeks from kick-off to approved budget | Weeks | 6–8 weeks (top quartile) |
| Forecast refresh cycle time | Days to produce an updated rolling forecast | Days | <3 days (top quartile) |
| Scenario planning cycle time | Days to produce a credible stress scenario | Days | <2 days (top quartile) |
| % of budgeting time in value-add analysis | Finance time on analysis vs. data consolidation | % | >60% (target) |

### Dimension 3: Finance Efficiency and Cost

| KPI | Definition | Measurement | Benchmark |
|-----|-----------|-------------|-----------|
| Finance cost as % of revenue | Total finance function cost ÷ total revenue | % | 0.4–0.6% (top quartile) |
| Finance FTEs per $1B revenue | Total finance headcount per $1B of revenue | FTE | 25–40 (top quartile) |
| Cost per invoice processed | Total AP cost ÷ invoices processed | $ | $2–5 (top quartile with automation) |
| Cost per payment | Total payment processing cost ÷ payments | $ | <$1 (automated) |
| AR days outstanding (DSO) | Average days sales outstanding | Days | Industry-specific |
| System TCO per transaction | Total system cost ÷ transaction volume | $ | Benchmark by sector |

### Dimension 4: Data Quality and Trust

| KPI | Definition | Measurement | Benchmark |
|-----|-----------|-------------|-----------|
| Finance data quality score | Composite: completeness + accuracy + timeliness | % | >98% |
| Reconciliation exception rate | # of unresolved reconciling items at period close | Count | <0.1% of population |
| Single source of truth adoption | % of management reports sourced from approved data | % | 100% (target) |
| Report restatement frequency | # of published reports requiring correction | Count | 0 |
| Data lineage coverage | % of KPIs with documented data lineage | % | >95% |
| Self-service BI adoption | % of report consumers able to self-serve | % | >70% |

### Dimension 5: Controls and Compliance

| KPI | Definition | Measurement | Benchmark |
|-----|-----------|-------------|-----------|
| Open SOX control deficiencies | # of open material weaknesses or significant deficiencies | Count | 0 |
| Audit findings (internal) | # of open internal audit findings by severity | Count | 0 critical, <5 high |
| Regulatory submissions on time | % of regulatory filings submitted by deadline | % | 100% |
| Control automation rate | % of key controls that are automated/system-enforced | % | >60% (target) |
| Fraud losses as % of revenue | Finance fraud/error losses ÷ revenue | % | <0.01% |
| Third-party risk incidents | # of material incidents from finance system vendors | Count | 0 |

### Dimension 6: Strategic Value and Business Partnering

| KPI | Definition | Measurement | Benchmark |
|-----|-----------|-------------|-----------|
| Insight-to-decision cycle time | Days from data availability to leadership decision | Days | <1 day (top quartile) |
| Finance business partner satisfaction | Internal NPS from business unit clients | Score | >7.5/10 |
| Strategic analysis hours % | % of finance time on forward-looking analysis | % | >40% (target) |
| Business case accuracy | Variance: actual project returns vs. approved business case | % | <±10% |
| Finance employee engagement | Finance team engagement score | Score | >70th percentile |

## Building the Transformation Business Case

### Business Case Structure (Board-Ready)

**Section 1: Executive Summary** (1 page max)
- Investment size, expected return, payback period, strategic rationale
- One-sentence recommendation with confidence level

**Section 2: Problem Statement**
- Current state evidence: benchmark data, cost analysis, pain points
- Cost of inaction: regulatory risk, talent risk, competitive disadvantage

**Section 3: Solution Options**
- Option A: Do nothing (baseline)
- Option B: Tactical improvement (point solutions)
- Option C: Strategic transformation (recommended)

**Section 4: Financial Model**
- Benefits by year (1–5): cost savings, FTE reductions, efficiency gains, risk avoidance
- Costs by year: implementation, licenses, change management, ongoing support
- NPV, IRR, payback period (sensitivity analysis at ±20% assumptions)

**Section 5: Non-Financial Benefits**
- Risk reduction (audit findings, regulatory penalties avoided)
- Strategic enablement (M&A readiness, scalability, data-driven decision-making)
- Talent: ability to attract/retain finance talent in a modern environment

**Section 6: Risks and Mitigations**
- Top 5 risks with probability, impact, and mitigation plan

**Section 7: Recommended Decision and Next Steps**

### Standard Benefit Categories and Quantification

| Benefit Category | How to Quantify |
|----------------|----------------|
| FTE cost avoidance | FTE reduction × fully-loaded cost ($100–150K/FTE typical) |
| Close acceleration | Days saved × cost per close day (controller time + finance ops) |
| Forecasting accuracy improvement | Better capital allocation decisions; quantify via working capital optimization |
| Audit cost reduction | External audit hours saved × blended hourly rate |
| IT TCO reduction | Legacy system retirement + license consolidation + support headcount |
| Compliance penalty avoidance | Regulatory fine exposure × probability reduction |
| Revenue enablement | Better pricing decisions, faster M&A integration, capital redeployment |

### NPV / IRR Model Parameters

- **Discount rate**: Use WACC or hurdle rate (typically 8–12% for financial services).
- **Benefit start timing**: Year 1 = 25% of full benefit (go-live typically mid-year); Year 2 = 75%; Year 3+ = 100%.
- **Implementation cost phasing**: Front-load costs in Years 1–2.
- **Sensitivity analysis**: Always show ±20% benefit realization and ±20% cost scenarios.
- **Payback period**: Aim for <3 years for high-confidence projects; <5 years for transformational.

## Benefits Realization Office (BRO) Model

### BRO Governance Structure

1. **Benefits Owner**: Executive responsible for realizing each benefit (typically CFO/COO per workstream)
2. **Benefits Tracker**: PMO-owned tool showing planned vs actual benefit realization by quarter
3. **Benefit Sign-Off Process**: Business owner signs off when benefit is demonstrably realized
4. **Benefit Clawback**: If benefits not realized within agreed timeframe, investment approval for Phase 2 is conditional

### Benefit Realization Timeline

| Phase | Benefit Type | Timing |
|-------|-------------|--------|
| Go-live | Quick wins: close acceleration, reconciliation automation | Month 1–3 |
| Stabilization | FTE savings begin: attrition management, redeployment | Month 3–6 |
| Optimization | Forecast accuracy improvement, self-service BI adoption | Month 6–12 |
| Full realization | Full cost savings, IT TCO reduction, audit benefits | Year 2+ |

## Additional Reference Materials

- **`references/kpi-library.md`** — Full KPI library by finance sub-function, industry-adjusted benchmarks, KPI dashboard templates, benefits tracking model
