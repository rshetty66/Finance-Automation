---
name: program-management
description: >
  This skill should be used when the user asks about "program management",
  "program governance", "PMO", "project management office", "steering committee",
  "program charter", "RAID log", "risk management", "issue escalation",
  "program reporting", "status report", "executive reporting", "tollgate",
  "phase gate", "benefits realization", "program recovery", "rescue",
  "mobilization", "team onboarding", "resource planning", "dependency management",
  "milestone tracking", "scope management", "change control", or needs to 
  design, manage, or recover a consulting program or transformation initiative.
version: 1.0.0
---

# Program Management Excellence

Expert-level methodology for setting up, governing, and delivering complex consulting programs and transformations. Apply this knowledge to establish robust governance, manage stakeholder expectations, track benefits, and recover troubled programs.

## Program Governance Framework

### Governance Structure by Scale

| Component | Tier 1 (>$50M) | Tier 2 ($10-50M) | Tier 3 (<$10M) |
|-----------|----------------|------------------|----------------|
| **Steering Committee** | Monthly, C-suite attendance | Bi-monthly, VP-level | As needed, Director-level |
| **PMO Function** | Dedicated PMO Lead + 2-3 analysts | Part-time PMO Lead | PM embedded in team |
| **Workstreams** | 4-6 workstreams with leads | 2-4 workstreams | 1-2 workstreams |
| **Review Boards** | Architecture, Change, Data separate | Combined review board | Informal reviews |
| **Reporting** | Weekly status, monthly steering | Bi-weekly status, monthly steering | Weekly integrated update |

### Key Governance Documents

**1. Program Charter**
```
1. Purpose & Objectives
   - Business case summary
   - Program goals and success criteria
   - Benefits to be realized

2. Scope & Deliverables
   - In-scope (explicit)
   - Out-of-scope (equally explicit)
   - Key deliverables and acceptance criteria

3. Governance Structure
   - Steering Committee membership and cadence
   - PMO structure and responsibilities
   - Decision-making authority and escalation paths

4. Program Plan
   - Phases and milestones
   - High-level timeline
   - Key dependencies

5. Resources & Budget
   - Team structure and key roles
   - Budget envelope and approval authority
   - Resource contingency

6. Risk Framework
   - Risk tolerance and appetite
   - RAID log structure
   - Escalation thresholds

7. Change Control
   - Scope change process
   - Budget reallocation authority
   - Change board membership
```

**2. RAID Log Template**

| ID | Category | Description | Probability | Impact | Owner | Mitigation/Action | Status | Due Date | Trend |
|----|----------|-------------|-------------|--------|-------|-------------------|--------|----------|-------|
| R001 | Risk | Data migration complexity higher than anticipated | High | High | Data Lead | Engage specialist firm; parallel track migration approach | Active | 15-Mar | ↑ |
| I001 | Issue | Key SME unavailable due to maternity leave | N/A | Medium | HRBP | Backfill with contractor; knowledge transfer plan | Mitigating | 01-Mar | → |
| A001 | Assumption | Cloud infrastructure provisioned by IT by 01-Apr | N/A | High | CIO | Weekly checkpoint with IT; escalation path defined | Monitoring | 01-Apr | → |
| D001 | Dependency | Finance process redesign completion for system config | N/A | High | Process Lead | Integrated planning; daily stand-ups during overlap | On Track | 30-Apr | → |

### Tollgate Review Model

| Gate | Timing | Entry Criteria | Decision | Typical Duration |
|------|--------|----------------|----------|------------------|
| **G0: Initiation** | Program kickoff | Charter approved, team mobilized, governance established | Proceed to Discovery | 1-2 weeks |
| **G1: Discovery Complete** | End of assess phase | Current state documented, gaps identified, options developed | Proceed to Design | 4-8 weeks |
| **G2: Design Approved** | End of design phase | Future state approved, business case confirmed, vendor selected | Proceed to Build | 8-16 weeks |
| **G3: Build Ready** | End of build phase | UAT passed, training complete, cutover plan approved | Proceed to Deploy | 16-52 weeks |
| **G4: Go-Live** | Pre-cutover | All readiness criteria met, hypercare planned | Approve Go-Live | 4-8 weeks per wave |
| **G5: Benefits Realization** | 6-12 months post go-live | Benefits measured, sustainment plan active | Close Programme | Ongoing |

## Program Recovery Protocol

### Early Warning Indicators

**Schedule Indicators:**
- Milestones slipping with no recovery plan
- Critical path tasks consistently delayed
- Integration testing compressed or skipped

**Budget Indicators:**
- Burn rate exceeding plan by >10%
- Change requests increasing in frequency
- Scope creep without change control

**Quality Indicators:**
- Defect rates increasing
- UAT failures or rejection
- Rework exceeding 15% of effort

**Stakeholder Indicators:**
- Steering Committee attendance declining
- Key sponsors disengaged
- User resistance or adoption concerns

**Team Indicators:**
- Key departures or low morale
- Overtime becoming normalized
- Conflict between workstreams

### Recovery Framework: STOP, ASSESS, PLAN, ACT

**STOP: Stabilize the Situation**
1. Pause non-critical activities
2. Preserve cash and key resources
3. Communicate transparently to stakeholders
4. Prevent further deterioration

**ASSESS: Diagnose Root Causes**
```
Assessment Areas:
□ Scope: Was it realistic? Has it changed?
□ Schedule: Were estimates accurate? Dependencies clear?
□ Resources: Right people? Enough capacity? Right skills?
□ Governance: Decisions being made? Escalations working?
□ Stakeholders: Sponsors engaged? Users bought in?
□ External: Vendor issues? Dependencies outside control?
□ Quality: Technical debt? Rework? Acceptance criteria clear?
```

**PLAN: Develop Recovery Options**
- Option A: Continue with corrections (incremental)
- Option B: Restructure and replan (significant change)
- Option C: Pause and reset (major intervention)
- Option D: Scope reduction or termination (last resort)

**ACT: Execute with Discipline**
1. Secure stakeholder buy-in to recovery plan
2. Re-baseline scope, schedule, budget
3. Implement enhanced governance and reporting
4. Weekly steering reviews until stable
5. Celebrate early wins to rebuild confidence

## Benefits Realization Management

### Benefits Mapping Framework

| Benefit | Baseline | Target | Measurement Method | Owner | Review Cadence |
|---------|----------|--------|-------------------|-------|----------------|
| Close cycle time | 8 days | 4 days | Close calendar tracking | Controller | Monthly |
| Finance cost % revenue | 1.2% | 0.8% | Finance cost / Revenue | CFO | Quarterly |
| Forecast accuracy | ±12% | ±5% | Actual vs forecast variance | FP&A Lead | Monthly |
| Data quality score | 72% | 95% | Automated data quality metrics | Data Lead | Monthly |

### Benefits Tracking Dashboard

```
BENEFITS REALIZATION DASHBOARD

Financial Benefits:
  Close acceleration:        $1.2M/year  [██████░░░░] 60% realized
  Headcount optimization:    $0.8M/year  [████████░░] 80% realized
  System cost reduction:     $0.4M/year  [████░░░░░░] 40% realized

Operational Benefits:
  Close cycle time:          8 → 4 days  [███████░░░] 70% achieved
  Forecast accuracy:         ±12% → ±5%  [█████░░░░░] 50% achieved
  Report generation time:    3 → 0.5 days [████████░░] 80% achieved

Risk Status: AMBER
  - Headcount benefits at risk due to delayed role transitions
  - Mitigation: Fast-track change management, executive intervention
```

## Executive Reporting Best Practices

### The 5-Slide Steering Committee Update

**Slide 1: Executive Summary**
- Overall status: Green/Yellow/Red with one-line explanation
- Key accomplishments this period
- Critical decisions needed today

**Slide 2: Timeline & Milestones**
- Visual timeline with key milestones
- Variance from baseline (days early/late)
- Forecast completion date

**Slide 3: Financials**
- Budget: Approved / Spent / Forecast / Variance
- Spend rate vs. plan
- Key cost drivers or concerns

**Slide 4: Top 3 Risks & Issues**
- Risk/issue statement
- Impact and probability
- Mitigation status and owner
- Escalation needed (Y/N)

**Slide 5: Next Period Priorities**
- Top 3 deliverables
- Key activities and milestones
- Decisions/dependencies needed from leadership

### Communication Protocols

**Escalation Triggers:**
- Budget variance >10%
- Schedule slippage >2 weeks on critical path
- Quality gate failure
- Key stakeholder disengagement
- Resource shortfall affecting delivery

**Escalation Path:**
1. Workstream Lead → Program Manager (immediate)
2. Program Manager → Steering Committee (next meeting)
3. Steering Committee → Executive Sponsor (urgent)
4. Executive Sponsor → C-Suite/Board (crisis)

---

## Additional Resources

- `references/program-templates.md` — Charter templates, status report formats, RAID log examples
- `references/recovery-playbooks.md` — Scenario-specific recovery plans
- `references/benefits-frameworks.md` — Benefits categorization and measurement approaches
