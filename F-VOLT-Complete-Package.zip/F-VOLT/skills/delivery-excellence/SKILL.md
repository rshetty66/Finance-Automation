---
name: delivery-excellence
description: >
  This skill should be used when the user asks about "deliverables",
  "deliverable quality", "board-ready", "executive presentation", "quality assurance",
  "review", "editing", "structuring a document", "executive summary", "POV",
  "point of view", "white paper", "thought leadership", "case study",
  "proposal", "proposal writing", "sales document", "pitch deck",
  "presentation design", "slide deck", "visual design", "document formatting",
  "content review", "quality control", or needs to create, review, or polish
  consulting deliverables for client or executive consumption.
version: 1.0.0
---

# Delivery Excellence: Creating Board-Ready Deliverables

Expert-level standards and techniques for producing consulting deliverables that meet the highest quality standards, resonate with C-suite audiences, and build lasting client trust.

## The Delivery Excellence Mindset

### Quality is Multi-Dimensional

| Dimension | Standard | Test Question |
|-----------|----------|---------------|
| **Substance** | Insightful, evidence-based, actionable | "Does this say something important that the client doesn't already know?" |
| **Structure** | Clear narrative flow, easy navigation | "Can an executive find what they need in 60 seconds?" |
| **Clarity** | Precise language, no ambiguity | "Is there only one way to interpret this?" |
| **Presentation** | Professional, consistent, visually appealing | "Would I be proud if the CEO saw this?" |
| **Accuracy** | Error-free, fact-checked, consistent | "Are there any typos, inconsistencies, or errors?" |
| **Client-Ready** | Tailored to client context, uses their language | "Could this have been written for any client, or is it specifically for them?" |

## Deliverable Types & Standards

### 1. Executive Summary / One-Pager

**Purpose**: Enable a CEO to understand the essence and decision in under 2 minutes.

**Structure:**
```
THE BOTTOM LINE (1 sentence — what you want them to do)

WHY IT MATTERS (2-3 bullets — business impact, urgency)

WHAT WE RECOMMEND (3-5 bullets — specific actions)

THE INVESTMENT (cost, timeline, resources)

RISKS & MITIGATION (top 2 risks, how we address them)

NEXT STEP (single, specific ask)
```

**Quality Check:**
- [ ] Can be read and understood in 90 seconds
- [ ] Every sentence adds value (no throat-clearing)
- [ ] Client-specific data and context throughout
- [ ] No jargon or undefined acronyms
- [ ] Clear, single next step

### 2. Strategic Advisory Memo (3-5 pages)

**Purpose**: Provide comprehensive recommendation with supporting rationale for executive decision.

**Structure:**
```
TO: [Executive Audience]
FROM: [Author]
DATE: [Date]
RE: [Clear, Specific Subject Line]
CLASSIFICATION: [Internal / Confidential / Client-Facing]

EXECUTIVE SUMMARY
- Recommendation (lead with it)
- Key supporting points (3-5 bullets)
- Investment required
- Timeline

SITUATION
- Current state (brief context)
- What has changed or what is at stake
- Why this matters now

ANALYSIS
- Key findings (structured, evidence-based)
- Options considered
- Comparative assessment

RECOMMENDATION
- Specific proposed action
- Rationale
- Expected outcomes

IMPLEMENTATION
- High-level approach
- Key milestones
- Resources required

RISKS & MITIGATIONS
- Top 3 risks
- Mitigation approach for each

NEXT STEPS
- Specific actions
- Owners
- Timeline
```

### 3. Board Presentation (8-12 slides)

**Slide-by-Slide Architecture:**

**Slide 1: Title**
- Title: Clear, action-oriented
- Subtitle: Context and date
- Classification level

**Slide 2: Situation Summary** (The "Why Now")
- Current state in 3 bullets
- The change or pressure point
- What's at stake

**Slide 3: Key Insight** (The "So What")
- The core finding or implication
- Visual: Chart or graphic making the point
- Supporting data point

**Slide 4: Options Considered** (The "What Else")
- 2-3 alternatives evaluated
- Why each was rejected
- Reinforces the wisdom of your recommendation

**Slide 5: Recommendation** (The "What")
- Clear, specific recommendation
- Visual: Summary diagram or framework
- Key benefits (3 bullets)

**Slide 6: Investment & Returns** (The "How Much")
- Investment required (capex and opex)
- Expected returns/benefits
- Payback period or ROI

**Slide 7: Implementation** (The "How")
- High-level timeline
- Key phases
- Critical success factors

**Slide 8: Risks & Mitigation** (The "What Could Go Wrong")
- Top 3 risks
- Mitigation for each
- Residual risk level

**Slide 9: Decision Required** (The "Ask")
- Specific decision needed
- Alternatives if declined
- Timeline for decision

**Slide 10: Next Steps** (The "Now What")
- Immediate actions (next 30 days)
- Owners
- Expected outcomes

### 4. Design Blueprint / Target Operating Model

**Purpose**: Comprehensive future-state design across people, process, and technology.

**Structure:**
```
EXECUTIVE SUMMARY
- Design principles (3-5)
- Key decisions made
- Investment and timeline summary

DESIGN CONTEXT
- Current state summary
- Drivers for change
- Design constraints and assumptions

TARGET OPERATING MODEL
- Service model (what happens where)
- Organization design (structure, roles, headcount)
- Process architecture (key processes, standardization)
- Technology enablement (systems, platforms)

IMPLEMENTATION APPROACH
- Phasing and sequencing rationale
- Key milestones and dependencies
- Change management approach

BUSINESS CASE & BENEFITS
- Investment breakdown
- Benefits by category
- Risk-adjusted ROI

GOVERNANCE & SUSTAINMENT
- Ongoing governance model
- Performance management
- Continuous improvement
```

### 5. Point of View (POV) / Thought Leadership

**Purpose**: Demonstrate expertise and shape client thinking on a key topic.

**Structure:**
```
TITLE: Provocative, Specific, Timely

EXECUTIVE SUMMARY (1 paragraph)
- Core argument
- Why it matters
- Key implication

THE CONTEXT (1 page)
- Industry trends or market dynamics
- The challenge or opportunity
- Why traditional approaches fall short

THE INSIGHT (1-2 pages)
- Your unique perspective or framework
- Evidence and examples
- Case studies or proof points

THE IMPLICATIONS (1 page)
- What this means for executives
- Actions to consider
- Questions to ask

ABOUT US (1 paragraph)
- Brief credentials
- Call to action (conversation, assessment, etc.)
```

## Writing for Executive Audiences

### Language Guidelines

**DO:**
- Use active voice
- Be specific ("reduce close time by 40%" not "improve efficiency significantly")
- Lead with the insight
- Use client's terminology
- Quantify wherever possible

**DON'T:**
- Hedge unnecessarily ("perhaps", "might", "could potentially")
- Use consultant jargon ("leverage", "synergy", "bandwidth")
- Over-qualify ("we believe that it may be possible that...")
- Use passive voice
- Write in abstractions

**Before:** "We believe that leveraging best practices could potentially enable efficiencies that might result in significant cost savings."

**After:** "Standardizing on proven processes will cut transaction processing costs by 30%, saving $2.4M annually."

### The Pyramid Principle

Every section should follow this structure:

```
MAIN POINT (the answer)
  ↓
KEY ARGUMENTS (why)
  ↓
SUPPORTING EVIDENCE (proof)
```

**Example:**
- **Main Point**: We recommend Oracle EPM Cloud for your consolidation platform.
- **Key Arguments**: (1) Strongest functional fit for multi-GAAP requirements, (2) Lowest TCO over 5 years, (3) Proven track record in your industry.
- **Supporting Evidence**: Feature comparison matrix, TCO analysis, reference client quotes.

## Visual Excellence

### Slide Design Principles

**1. One Idea Per Slide**
- If you have 5 points, use 5 slides
- Exception: Summary slides that tie together

**2. Visual Hierarchy**
- Title: 32-36pt, bold
- Subtitle: 24pt, regular
- Body: 18-20pt
- Annotations: 14-16pt

**3. Color Palette**
- Primary: Client's brand colors
- Accent: Single highlight color for emphasis
- Neutrals: Grays for supporting text
- Maximum 4 colors per slide

**4. Data Visualization**
- Use the right chart type:
  - Comparison: Bar chart
  - Trend: Line chart
  - Composition: Pie (only if <5 segments) or stacked bar
  - Relationship: Scatter plot
- Label directly on charts (avoid legends where possible)
- Highlight the insight, not just the data

### Document Formatting Standards

**Font Hierarchy:**
- Document Title: 18pt, Bold, All Caps
- Section Headers: 14pt, Bold
- Subsection Headers: 12pt, Bold
- Body Text: 11pt, Regular
- Captions/Footnotes: 9pt, Regular

**Spacing:**
- Line spacing: 1.15 for body text
- Paragraph spacing: 12pt after
- Section breaks: 24pt before

**Margins:**
- Standard: 1 inch all around
- Executive summary pages: 0.75 inch for one-pagers

## The Quality Assurance Process

### Pre-Delivery Checklist

**Content Review:**
- [ ] Executive summary captures the essence
- [ ] Every claim is supported by evidence
- [ ] Client-specific context throughout
- [ ] No factual errors or inconsistencies
- [ ] Numbers reconcile (totals, percentages, dates)

**Structure Review:**
- [ ] Clear narrative flow
- [ ] Headings are descriptive
- [ ] Page breaks are logical
- [ ] Table of contents matches actual content

**Language Review:**
- [ ] Active voice throughout
- [ ] No typos or grammatical errors
- [ ] Consistent terminology
- [ ] Acronyms defined on first use
- [ ] No jargon or clichés

**Visual Review:**
- [ ] Consistent formatting
- [ ] Professional appearance
- [ ] Charts are readable
- [ ] Color palette consistent
- [ ] Page numbers correct

### The Cold Read Test

Before delivering:
1. Put the document away for 2+ hours (or overnight)
2. Read it fresh as if you were the client
3. Mark anything confusing, surprising, or weak
4. Fix before sending

### The "So What?" Test

For every paragraph, ask: "So what?"
- If the answer isn't clear, rewrite or delete
- Every paragraph must advance the argument or provide essential context

---

## Additional Resources

- `references/deliverable-templates.md` — Templates for common deliverable types
- `references/visual-standards.md` — Color palettes, font pairings, chart guidelines
- `references/writing-guide.md` — Expanded writing techniques and examples
