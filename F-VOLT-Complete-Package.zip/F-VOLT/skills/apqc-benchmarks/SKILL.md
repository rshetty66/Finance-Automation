---
name: apqc-benchmarks
description: >
  This skill activates when the user discusses APQC, Process Classification
  Framework (PCF), benchmarks, benchmarking, process frameworks, finance
  benchmarks, performance metrics, KPIs, best practices, process maturity,
  or comparing performance against industry standards. The user has APQC
  login access to research content and benchmarks.
version: 1.0.0
---

# APQC Benchmark Expert — Process & Performance Excellence

Expert-level guidance on leveraging APQC's Process Classification Framework (PCF) and benchmarking data to assess performance, identify improvement opportunities, and validate transformation business cases.

---

## 1. APQC Overview

### What is APQC?

APQC (American Productivity & Quality Center) is a member-based nonprofit and the world's foremost authority in:
- **Process Frameworks**: The Process Classification Framework (PCF)
- **Benchmarking**: Cross-industry performance data
- **Best Practices**: Research on what top performers do differently
- **Process Improvement**: Methodologies and tools

### APQC Membership Value

| Resource | Description | Use Case |
|----------|-------------|----------|
| **PCF** | 13-level process taxonomy | Process mapping, standardization |
| **Benchmarks** | Performance metrics by industry | Target setting, gap analysis |
| **Research** | Best practice reports | Solution design, transformation |
| **Tools** | Assessments, maturity models | Current state evaluation |
| **Community** | Networking, peer learning | Solution validation |

---

## 2. Process Classification Framework (PCF)

### PCF Structure

```
Level 1: Category (12 Categories)
  Level 2: Process Group
    Level 3: Process
      Level 4: Activity
        Level 5: Task
```

### PCF Categories

| Code | Category | Description |
|------|----------|-------------|
| 1.0 | Develop Vision and Strategy | Strategic planning |
| 2.0 | Develop and Manage Products and Services | R&D, product management |
| 3.0 | Market and Sell Products and Services | Marketing, sales |
| 4.0 | Deliver Physical Products | Supply chain, logistics |
| 5.0 | Deliver Services | Service delivery |
| 6.0 | Manage Customer Service | Support, complaints |
| 7.0 | Develop and Manage Human Capital | HR, talent |
| 8.0 | Manage Information Technology | IT, systems |
| 9.0 | Manage Financial Resources | **Finance function** |
| 10.0 | Acquire, Construct, and Manage Assets | Facilities, assets |
| 11.0 | Manage Enterprise Risk, Compliance, and Controls | Risk, audit |
| 12.0 | Manage External Relationships | Procurement, vendors |
| 13.0 | Develop and Manage Business Capabilities | Process, knowledge |

### PCF Category 9.0: Manage Financial Resources (Finance Function)

**9.1 Perform Planning and Management Accounting**
- 9.1.1 Perform planning/budgeting
- 9.1.2 Perform cost accounting
- 9.1.3 Perform variance analysis
- 9.1.4 Manage consolidated financial results

**9.2 Perform Revenue Accounting**
- 9.2.1 Process customer credit
- 9.2.2 Invoice customers
- 9.2.3 Process accounts receivable
- 9.2.4 Manage revenue

**9.3 Perform General Accounting and Reporting**
- 9.3.1 Manage policies and procedures
- 9.3.2 Perform general accounting
- 9.3.3 Perform fixed asset accounting
- 9.3.4 Perform financial reporting
- 9.3.5 Perform consolidated accounting
- 9.3.6 Perform funds management

**9.4 Manage Fixed Asset Project Accounting**
- 9.4.1 Perform capital planning
- 9.4.2 Perform capital project accounting

**9.5 Process Payroll**
- 9.5.1 Process payroll taxes
- 9.5.2 Process payroll benefits
- 9.5.3 Process employee payroll

**9.6 Process Accounts Payable and Expense Reimbursements**
- 9.6.1 Process accounts payable
- 9.6.2 Process expense reimbursements
- 9.6.3 Manage payroll taxes

**9.7 Manage Treasury**
- 9.7.1 Manage treasury policies
- 9.7.2 Manage cash
- 9.7.3 Manage capital structure
- 9.7.4 Manage financial risk
- 9.7.5 Manage investments

**9.8 Manage Internal Controls**
- 9.8.1 Establish internal controls
- 9.8.2 Evaluate internal controls

**9.9 Manage Taxes**
- 9.9.1 Develop tax strategy
- 9.9.2 Process taxes

**9.10 Manage International Funds/Compliance**
- 9.10.1 Manage international funds
- 9.10.2 Monitor international compliance

**9.11 Perform Intercompany Accounting**
- 9.11.1 Perform intercompany processing
- 9.11.2 Reconcile intercompany accounts

---

## 3. Finance Function Benchmarks

### Key Finance Benchmarks

| Metric | APQC Metric Code | Description |
|--------|------------------|-------------|
| **Total Cost to Perform Finance Function** | 100642 | All-in finance cost |
| **Cost to Perform the Process "Perform General Accounting"** | 104336 | GL accounting cost |
| **Cost to Perform the Process "Process Accounts Payable"** | 104337 | AP cost |
| **Cost to Perform the Process "Process Accounts Receivable"** | 104338 | AR cost |
| **Cost to Perform the Process "Perform Financial Reporting"** | 104339 | Reporting cost |
| **Number of FTEs for Finance Function** | 100645 | Total FTEs |
| **Days to Close the Books** | 100641 | Close cycle time |
| **Percentage of Automatic Payments** | 100650 | AP automation |
| **Percentage of Invoices Paid on Time** | 100655 | AP timeliness |
| **DSO (Days Sales Outstanding)** | 100660 | AR efficiency |

### Finance Cost Benchmarks

**Total Cost to Perform Finance Function (% of Revenue)**
| Percentile | All Industries | Manufacturing | Financial Services |
|------------|----------------|---------------|-------------------|
| Top 25% | 0.6% | 0.5% | 0.8% |
| Median | 1.0% | 0.9% | 1.2% |
| Bottom 25% | 1.8% | 1.6% | 2.0% |

**Total Cost to Perform Finance Function ($ per $1,000 Revenue)**
| Percentile | Cost |
|------------|------|
| Top 25% | <$6 |
| Median | $10 |
| Bottom 25% | >$18 |

### Finance FTE Benchmarks

**Finance FTEs per $1 Billion Revenue**
| Percentile | FTEs |
|------------|------|
| Top 25% | <40 |
| Median | 70 |
| Bottom 25% | >120 |

**Finance FTEs per $50 Million Revenue**
| Percentile | FTEs |
|------------|------|
| Top 25% | <5 |
| Median | 8 |
| Bottom 25% | >12 |

### Record-to-Report (R2R) Benchmarks

**Days to Close the Books**
| Percentile | Days |
|------------|------|
| Top 25% | 4 days |
| Median | 6.5 days |
| Bottom 25% | 10 days |

**Cost to Perform General Accounting per $1,000 Revenue**
| Percentile | Cost |
|------------|------|
| Top 25% | <$1.50 |
| Median | $3.00 |
| Bottom 25% | >$6.00 |

**Cost to Perform Financial Reporting per $1,000 Revenue**
| Percentile | Cost |
|------------|------|
| Top 25% | <$0.50 |
| Median | $1.00 |
| Bottom 25% | >$2.50 |

### Procure-to-Pay (P2P) Benchmarks

**Cost to Process a Single Invoice (Manual vs. Automatic)**
| Method | Cost |
|--------|------|
| Manual (no PO) | $15-20 |
| Manual (with PO) | $10-15 |
| Semi-automated | $5-8 |
| Fully automated | $2-4 |
| Best-in-class | <$1 |

**Cost to Perform the Process "Process Accounts Payable" per Invoice**
| Percentile | Cost |
|------------|------|
| Top 25% | <$3 |
| Median | $7 |
| Bottom 25% | >$15 |

**Percentage of Invoices Processed Straight-Through (Touchless)**
| Percentile | % Touchless |
|------------|-------------|
| Top 25% | >85% |
| Median | 60% |
| Bottom 25% | <35% |

**Days Payable Outstanding (DPO)**
| Percentile | Days |
|------------|------|
| Top 25% | 45-60 |
| Median | 35-45 |
| Bottom 25% | <30 |

### Order-to-Cash (O2C) Benchmarks

**Cost to Process an Order (End-to-End)**
| Complexity | Cost |
|------------|------|
| Simple | $25-50 |
| Moderate | $50-100 |
| Complex | $100-200 |

**Days Sales Outstanding (DSO)**
| Percentile | Days |
|------------|------|
| Top 25% | <30 |
| Median | 40 |
| Bottom 25% | >55 |

**Percentage of Automatic Cash Application**
| Percentile | % Auto |
|------------|--------|
| Top 25% | >90% |
| Median | 70% |
| Bottom 25% | <45% |

**Cost to Perform the Process "Process Accounts Receivable" per Invoice**
| Percentile | Cost |
|------------|------|
| Top 25% | <$5 |
| Median | $10 |
| Bottom 25% | >$20 |

### Planning & Analysis Benchmarks

**Cost of Financial Planning and Analysis per $1,000 Revenue**
| Percentile | Cost |
|------------|------|
| Top 25% | <$0.50 |
| Median | $1.00 |
| Bottom 25% | >$2.50 |

**Cycle Time to Produce Annual Budget**
| Percentile | Weeks |
|------------|-------|
| Top 25% | <8 |
| Median | 12 |
| Bottom 25% | >20 |

**Cycle Time to Produce Monthly Forecast**
| Percentile | Days |
|------------|------|
| Top 25% | <5 |
| Median | 10 |
| Bottom 25% | >15 |

---

## 4. Using APQC in Engagements

### Current State Assessment

**Step 1: Map Current Processes to PCF**
```
Current: "We do month-end close in 12 days"
PCF Mapping: 9.3.4 Perform Financial Reporting
Benchmark: Median is 6.5 days, Top quartile is 4 days
Gap: 8 days above median, 3x top quartile
```

**Step 2: Collect Current Metrics**
- Use APQC metric definitions for consistency
- Gather data for comparable scope
- Document calculation methodology

**Step 3: Compare to Benchmarks**
- Select appropriate industry/segment
- Identify percentile positioning
- Quantify gaps

### Business Case Development

**Using Benchmarks to Build Business Cases:**

| Element | APQC Application |
|---------|------------------|
| **Current State Cost** | Calculate based on FTE × loaded cost |
| **Benchmark Target** | Top quartile or median performance |
| **Gap Value** | Difference × volume |
| **Benefit Opportunity** | Gap × payback period |
| **ROI Validation** | Compare to similar transformations |

**Example Business Case:**
```
Current State:
- Finance cost: $12M (1.5% of revenue)
- APQC median for industry: 1.0%
- Gap: 0.5% of revenue

Opportunity:
- Revenue: $800M
- Potential savings: $4M annually
- Investment required: $8M
- Payback: 24 months
- 5-year NPV: $12M

Benchmark Validation:
- Top quartile operates at 0.6%
- Target of 0.8% is achievable
- Target savings: $5.6M
```

### Target Operating Model Design

**Setting Targets Using APQC:**

| Approach | When to Use |
|----------|-------------|
| **Top Quartile** | Aspirational, leading organization |
| **Median** | Realistic, competitive parity |
| **Industry Best** | Specific industry leader comparison |
| **Peer Comparison** | Direct competitors |

**PCF for Process Design:**
- Use PCF as starting point for process taxonomy
- Identify missing processes
- Standardize process naming
- Benchmark process-specific metrics

### Transformation Roadmap

**Using APQC Maturity Models:**

| Maturity Level | Characteristics | APQC Resources |
|----------------|-----------------|----------------|
| **Level 1: Initial** | Ad hoc, inconsistent | Benchmark current state |
| **Level 2: Developing** | Documented, basic controls | Best practice research |
| **Level 3: Defined** | Standardized, measured | Process frameworks |
| **Level 4: Managed** | Measured, controlled | Advanced benchmarks |
| **Level 5: Optimizing** | Continuous improvement | Innovation research |

---

## 5. Industry-Specific Benchmarks

### Financial Services

**Finance Cost as % of Revenue**
| Segment | Top 25% | Median | Bottom 25% |
|---------|---------|--------|------------|
| Banking | 0.7% | 1.2% | 2.0% |
| Insurance | 0.8% | 1.3% | 2.2% |
| Asset Management | 0.6% | 1.0% | 1.8% |

**Close Cycle (Days)**
| Segment | Top 25% | Median | Bottom 25% |
|---------|---------|--------|------------|
| Banking | 3 | 5 | 8 |
| Insurance | 4 | 6 | 10 |

### Manufacturing

**Finance Cost as % of Revenue**
| Segment | Top 25% | Median | Bottom 25% |
|---------|---------|--------|------------|
| Discrete Manufacturing | 0.5% | 0.9% | 1.6% |
| Process Manufacturing | 0.6% | 1.0% | 1.8% |

**Cost per Invoice**
| Segment | Top 25% | Median | Bottom 25% |
|---------|---------|--------|------------|
| Manufacturing | $2.50 | $6.00 | $14.00 |

### Healthcare

**Finance Cost as % of Revenue**
| Segment | Top 25% | Median | Bottom 25% |
|---------|---------|--------|------------|
| Healthcare Providers | 1.2% | 2.0% | 3.5% |
| Healthcare Payers | 0.8% | 1.5% | 2.5% |

### Retail

**Finance Cost as % of Revenue**
| Metric | Top 25% | Median | Bottom 25% |
|--------|---------|--------|------------|
| % of Revenue | 0.4% | 0.7% | 1.2% |
| DSO | 20 days | 30 days | 45 days |

### Technology

**Finance Cost as % of Revenue**
| Metric | Top 25% | Median | Bottom 25% |
|--------|---------|--------|------------|
| % of Revenue | 0.5% | 0.9% | 1.5% |
| Finance FTEs per $1B | 35 | 60 | 100 |

---

## 6. APQC Research Resources

### Key Research Areas

| Area | Description | Application |
|------|-------------|-------------|
| **Process Improvement** | Methodologies, case studies | Solution design |
| **Emerging Technologies** | AI, RPA, blockchain | Technology strategy |
| **Operating Models** | SSO, GBS, outsourcing | TOM design |
| **Data & Analytics** | Governance, monetization | Data strategy |
| **Change Management** | Adoption, sustainment | OCM planning |

### Using APQC Assessments

**Available Assessments:**
- Process Maturity Assessment
- Finance Function Assessment
- Shared Services Assessment
- Digital Transformation Assessment

**Assessment Applications:**
- Current state baseline
- Priority setting
- Progress tracking
- Peer comparison

---

## 7. APQC in Proposals & Deliverables

### Proposal Applications

**Credibility:**
- "According to APQC benchmarks..."
- "Top quartile performers achieve..."
- "Our target aligns with industry median..."

**Differentiation:**
- APQC-certified framework
- Benchmark-based targets
- Proven methodology

### Deliverable Applications

**Current State Reports:**
- Process mapping using PCF
- Benchmark comparisons
- Gap analysis with quantification

**Design Reports:**
- Target setting with benchmarks
- Best practice incorporation
- Peer comparison validation

**Business Cases:**
- Benchmark-based benefits
- ROI validation
- Risk-adjusted targets

---

## Quick Reference: APQC Research Access

### Research Portal Navigation

**Home Page Sections:**
- Benchmarks & Metrics
- Process Framework (PCF)
- Research Reports
- Communities
- Tools & Templates

**Benchmark Search:**
1. Select function (Finance)
2. Select metric category (Cost, Cycle Time, Productivity)
3. Filter by industry
4. View percentiles
5. Download data

**PCF Access:**
1. Navigate to PCF section
2. Select version (Cross-Industry, Industry-Specific)
3. Download Excel or PDF
4. Use for process mapping

### Key Reports for Finance Transformation

| Report | Topic | Use Case |
|--------|-------|----------|
| **Finance Function Benchmarks** | Comprehensive finance metrics | Current state, target setting |
| **Close Optimization** | Accelerating month-end | R2R transformation |
| **AP Automation** | Touchless processing | P2P transformation |
| **Shared Services** | GBS/SSC operating models | TOM design |
| **Digital Finance** | AI, RPA in finance | Technology roadmap |
| **Process Frameworks** | PCF detailed guidance | Process standardization |

---

## APQC Benchmark Checklist

**Before Analysis:**
- [ ] Confirm APQC membership access
- [ ] Identify relevant industry segment
- [ ] Define scope (function, processes)
- [ ] Gather current state data

**During Analysis:**
- [ ] Map processes to PCF
- [ ] Extract relevant benchmarks
- [ ] Calculate current state metrics
- [ ] Compare to appropriate percentiles
- [ ] Quantify gaps

**After Analysis:**
- [ ] Validate with client data
- [ ] Set realistic targets
- [ ] Incorporate into business case
- [ ] Document assumptions
- [ ] Cite APQC sources

**In Deliverables:**
- [ ] Reference APQC framework
- [ ] Include benchmark charts
- [ ] Show gap analysis
- [ ] Validate targets
- [ ] Maintain confidentiality
