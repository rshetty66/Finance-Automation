---
name: industry-utilities
description: >
  This skill activates when the user discusses electric utilities, gas
  utilities, water utilities, renewable energy, power generation, transmission,
  distribution, smart grid, rate cases, regulatory commissions, OEB, FERC,
  rate base, ROE, AFUDC, or finance transformation in utilities organizations.
version: 1.0.0
---

# Utilities Industry Expert

Deep expertise in finance transformation for electric, gas, and water utilities. Covers regulatory frameworks, rate-making, capital-intensive operations, and industry-specific KPIs unique to the utilities sector.

---

## 1. Utilities Sub-Sectors

### Electric Utilities
**Segments:**
- **Generation**: Power plants (fossil, nuclear, renewable)
- **Transmission**: High-voltage lines, substations
- **Distribution**: Local delivery, meters, customer connections
- **Retail**: Customer service, billing, energy services

**Finance Characteristics:**
- Capital intensive (high fixed assets)
- Regulatory-driven returns
- Long asset lives (30-50 years)
- Complex depreciation
- Storm cost recovery

**Key Metrics:**
- Rate base
- Return on equity (ROE)
- Cost of service
- Customer count
- Peak demand

### Gas Utilities
**Segments:**
- **Transmission**: Interstate pipelines
- **Distribution**: Local gas delivery
- **Storage**: Underground storage facilities
- **LDC (Local Distribution Company)**: Customer-facing operations

**Finance Characteristics:**
- Seasonal demand (heating)
- Commodity cost pass-through
- Pipeline infrastructure
- Safety investments
- Decarbonization initiatives

**Key Metrics:**
- Throughput (volumes)
- Customer growth
- Pipeline miles
- Safety incidents
- Emissions

### Water Utilities
**Segments:**
- **Water**: Treatment, distribution
- **Wastewater**: Collection, treatment
- **Stormwater**: Management systems

**Finance Characteristics:**
- Essential service
- Infrastructure replacement
- Regulatory lag
- Conservation incentives
- Water quality compliance

**Key Metrics:**
- Connections
- Water quality compliance
- Infrastructure condition
- Leakage rates
- Conservation savings

---

## 2. Regulatory Framework

### Rate-Making Process

**Traditional Cost-of-Service Regulation:**
```
Revenue Requirement = Operating Expenses + Depreciation + Taxes + (Rate Base × ROE)

Rate Base = Net plant in service + Working capital - Accumulated deferred income taxes

Rates = Revenue Requirement / Sales Volume
```

**Key Components:**
| Component | Description |
|-----------|-------------|
| **Rate Base** | Net investment in utility plant |
| **ROE (Return on Equity)** | Authorized return (typically 9-11%) |
| **Cost of Service** | Operating costs + depreciation + taxes |
| **Revenue Requirement** | Total costs + allowed return |

### Rate Case Process

**Phases:**
1. **Test Year Selection**: Representative historical year
2. **Cost of Service Study**: Calculate revenue requirement
3. **Rate Design**: Allocate costs to customer classes
4. **Filing**: Submit to regulatory commission
5. **Discovery**: Interrogatories, data requests
6. **Hearings**: Testimony, cross-examination
7. **Decision**: Commission order
8. **Implementation**: New rates effective

**Typical Timeline**: 9-18 months

### Key Regulatory Concepts

**AFUDC (Allowance for Funds Used During Construction)**
- Financing cost capitalized during construction
- Borrowing rate for debt portion
- Equity return rate for equity portion
- Reduces rate base when project placed in service

**CWIP (Construction Work in Progress)**
- Construction costs before asset is operational
- Some jurisdictions allow in rate base
- Others require project completion

**Regulatory Assets/Liabilities**
- Costs deferred for future recovery
- Accounting treatment under ASC 980 (US) or IFRS
- Examples: storm costs, pension adjustments, OPEB

**Riders/Surcharges**
- Cost recovery mechanisms outside base rates
- Examples: fuel adjustment, purchased gas, energy efficiency
- Provides timely cost recovery

---

## 3. Canadian Regulatory Environment

### Provincial Regulation

**Ontario - OEB (Ontario Energy Board)**
- Electric and gas utilities
- Rate-setting, licensing, compliance
- Ontario's energy policy implementation
- Key frameworks: Custom IR, PICs (Performance Incentive Mechanisms)

**Alberta - AUC (Alberta Utilities Commission)**
- Electric utilities
- Market-based generation
- Regulated transmission and distribution

**British Columbia - BCUC (British Columbia Utilities Commission)**
- BC Hydro, FortisBC
- Integrated resource planning
- Clean energy requirements

**Quebec - Régie de l'énergie**
- Hydro-Québec
- Natural gas distributors

### Canadian ROE Benchmarks (2020-2024)

| Utility Type | Typical ROE Range | Notes |
|--------------|-------------------|-------|
| **Electric Distribution** | 9.0% - 9.5% | OEB range |
| **Electric Transmission** | 8.5% - 9.5% | Lower risk profile |
| **Gas Distribution** | 9.0% - 9.75% | OEB recent decisions |
| **Water Utilities** | 8.0% - 9.0% | Varies by province |

### Rate Base Calculation (Canada)

**Formula:**
```
Rate Base = 
  Gross Plant in Service
  - Accumulated Depreciation
  + Construction Work in Progress (if applicable)
  + Materials and Supplies
  + Prepayments
  - Customer Deposits
  - Accumulated Deferred Income Taxes
```

---

## 4. US Regulatory Environment

### FERC (Federal Energy Regulatory Commission)
- Interstate transmission
- Wholesale electricity markets
- Natural gas pipelines
- Hydroelectric licensing

### State Public Utility Commissions (PUCs)
- Retail rate regulation
- Distribution rates
- Service quality standards
- Integrated resource planning

### Key US Concepts

**Formula Rate Plans**
- Annual rate adjustments based on formula
- Reduces rate case frequency
- True-up mechanisms

**Performance-Based Regulation (PBR)**
- Incentives for performance
- Outcome-based metrics
- Revenue decoupling
- Shared savings mechanisms

**Multi-Year Rate Plans (MYRP)**
- 3-5 year rate plans
- Forecasted test years
- Annual adjustments

---

## 5. Utilities Finance KPIs

### Financial Performance

| KPI | Typical Range | Calculation |
|-----|---------------|-------------|
| **ROE** | 9-11% | Net income / Average equity |
| **ROA** | 2.5-3.5% | Net income / Average assets |
| **Interest Coverage** | 3-5x | EBIT / Interest expense |
| **Debt/Equity** | 50-60% | Total debt / Total equity |
| **FFO/Debt** | 15-25% | Funds from operations / Total debt |

### Operational Metrics

| KPI | Description | Benchmark |
|-----|-------------|-----------|
| **SAIDI** | System Average Interruption Duration Index | < 2 hours (urban) |
| **SAIFI** | System Average Interruption Frequency Index | < 1.5 (urban) |
| **CAIDI** | Customer Average Interruption Duration Index | < 1.5 hours |
| **O&M per Customer** | Operations and maintenance cost | Varies by region |
| **Customers per Employee** | Efficiency metric | 150-250 |

### Rate Base Metrics

| KPI | Description | Typical |
|-----|-------------|---------|
| **Rate Base Growth** | Year-over-year growth | 3-7% |
| **Capital Ratio** | Capital spending / Rate base | 8-12% |
| **Depreciation Rate** | Annual depreciation % | 2.5-4% |
| **Average Asset Life** | Weighted average | 30-50 years |

### Customer Metrics

| KPI | Description | Target |
|-----|-------------|--------|
| **Customer Satisfaction** | Survey-based | > 80% |
| **Call Center ASA** | Average Speed of Answer | < 60 seconds |
| **First Call Resolution** | Issues resolved on first call | > 80% |
| **Billing Accuracy** | Error-free bills | > 99% |
| **Collection Efficiency** | Bad debt ratio | < 1% |

---

## 6. Capital Investment & Planning

### Integrated Resource Planning (IRP)
**Process:**
1. Demand forecasting (15-20 years)
2. Resource option analysis
3. Portfolio optimization
4. Stakeholder engagement
5. Regulatory filing
6. Implementation

**Key Considerations:**
- Load growth/decline
- Renewable energy targets
- Carbon regulations
- Technology costs (solar, wind, storage)
- Grid modernization

### Capital Project Types

**Generation:**
- Renewables (solar, wind, hydro)
- Natural gas peakers
- Nuclear upgrades/refurbishment
- Coal retirements

**Transmission:**
- New lines
- Substation upgrades
- Grid modernization
- Smart grid technologies

**Distribution:**
- System hardening
- Automation
- Smart meters
- EV infrastructure

**Environmental:**
- Emissions controls
- Renewable energy
- Energy storage
- Grid flexibility

### AFUDC Economics

**Benefits:**
- Reduces financing costs during construction
- Smooths rate impacts
- Improves cash flow

**Calculation:**
```
AFUDC Rate = (Debt % × Borrowing Rate) + (Equity % × ROE)

Example:
- Capital structure: 50% debt, 50% equity
- Borrowing rate: 5%
- Authorized ROE: 9.5%
- AFUDC Rate: (50% × 5%) + (50% × 9.5%) = 7.25%
```

---

## 7. Utilities Accounting Considerations

### Regulatory Accounting (ASC 980)

**Criteria for Regulatory Accounting:**
1. Rates are established by independent regulator
2. Rates are designed to recover specific costs
3. It is probable that rates will recover costs

**Regulatory Assets:**
- Costs probable of recovery in future rates
- Examples: storm costs, pension costs, environmental

**Regulatory Liabilities:**
- Refunds probable to customers
- Examples: excess earnings, tax benefits

### Depreciation

**Key Factors:**
- Asset lives (30-50 years for transmission)
- Salvage values
- Depreciation methods (straight-line typical)
- Net salvage studies

**Group Depreciation:**
- Vintage year accounting
- Average service life
- Remaining life depreciation

### Storm Cost Recovery

**Accounting Treatment:**
- Expense as incurred
- Defer if material
- Regulatory asset for recovery
- Rate rider or base rate inclusion

---

## 8. Emerging Trends

### Decarbonization
- Net-zero commitments
- Coal retirement
- Renewable energy expansion
- Electrification (transportation, heating)
- Carbon pricing

### Grid Modernization
- Smart grid investments
- Grid edge technologies
- Distributed energy resources (DERs)
- Energy storage
- Microgrids

### Regulatory Evolution
- Performance-based regulation
- Multi-year rate plans
- Outcome-based incentives
- Rate design reform
- Integrated system planning

### Technology Disruption
- Smart meters / AMI
- Advanced analytics
- AI/ML for grid management
- Blockchain for energy trading
- Customer engagement platforms

---

## Quick Reference: Utilities Transformation

**Common Initiatives:**
- ERP system upgrades (SAP, Oracle, Workday)
- AMI/Smart meter deployment
- Customer information systems
- Asset management systems
- Regulatory reporting automation
- Financial planning & analytics

**Key Stakeholders:**
- Regulatory Affairs
- Rates and Regulatory Finance
- Resource Planning
- Grid Operations
- Customer Operations
- Environmental Compliance

**Success Factors:**
- Regulatory alignment
- Rate case timing
- Customer impact management
- Employee engagement
- Technology integration
