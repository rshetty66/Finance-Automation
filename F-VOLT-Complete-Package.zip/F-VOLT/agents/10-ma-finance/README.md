# M&A Finance Transformation Agents — Complete Set

This directory contains 6 specialized agent definition files for M&A Finance Transformation, designed for Big 4 / SI consulting-grade delivery. These agents span the complete M&A finance lifecycle: from pre-close due diligence through post-close integration, carve-out finance management, and acquisition accounting.

## Agent Overview

### 1. **ma-day1-readiness-lead.md** [RED | P1]
**First Principle:** Day 1 is a regulatory and legal obligation — the acquired entity must operate independently from legal close forward.

**Role**: Ensures the acquired/merged entity can operate as a standalone legal and financial entity on Day 1. Manages the 8 pillars of Day 1 readiness (Legal Entity, Finance, HR/Payroll, IT/Systems, Treasury/Banking, Tax, Procurement, Customer/Supplier Communication).

**Key Expertise**:
- 8-pillar Day 1 readiness framework and checklists
- Finance Day 1 operational readiness (AP, AR, Payroll, GL, Treasury, Tax, Reporting)
- TSA design and service definitions (scope, cost, duration, exit criteria)
- ERP Day 1 options (Parallel Run on TSA, Standalone Clone, Lift-and-Shift, New Implementation)
- War Room governance and contingency playbooks
- Go/No-Go decision framework

**Deliverables**: Day 1 Readiness Playbook, TSA Schedule, Finance Day 1 Risk Register, War Room Playbook, Go/No-Go Assessment, Post-Day 1 Stabilization Plan

**Integration**: Upstream from Day 2 Finance Integration Lead; foundational for all post-close operations

**File Size**: 721 lines (55 KB)

---

### 2. **ma-day2-finance-integration-lead.md** [BLUE | P1]
**First Principle:** Day 2 is where value is created or destroyed — integration speed and quality determine whether the deal thesis materializes.

**Role**: Drives the post-close finance function integration from TSA exit through full harmonization. Manages 100-day integration plan across 4 waves (Stabilize, Harmonize, System Integrate, Optimize).

**Key Expertise**:
- 100-Day Finance Integration Plan (4 waves with detailed activities and milestones)
- Process harmonization (P2P, O2C, R2R / Record-to-Report)
- Chart of Accounts harmonization (3 approaches: Buyer Absorbs, Blend, Dual CoA)
- System integration strategy (lift-and-shift to buyer ERP, timeline, data migration)
- Synergy tracking and realization dashboard
- TSA exit planning (service-by-service exit criteria and timeline)
- Controls & compliance consolidation (SOX/SOC integration)
- Consolidation and intercompany elimination setup

**Deliverables**: 100-Day Finance Integration Plan, Wave 2 Process Harmonization Plan, System Migration Plan, COA Mapping Document, Synergy Tracking Dashboard, Organization Integration Plan, SOX/SOC Controls Integration Plan

**Integration**: Receives Day 1 foundation from Day 1 Readiness Lead; executes synergies identified by Synergy Value Architect; coordinates with Finance Due Diligence on baseline assumptions

**File Size**: 625 lines (47 KB)

---

### 3. **ma-financial-due-diligence-lead.md** [GREEN | P1]
**First Principle:** Due diligence is buyer protection — every dollar of unvalidated EBITDA is a dollar of overpayment risk.

**Role**: Conducts independent, critical financial examination of target to identify valuation risks, validate projections, and protect buyer from overpayment.

**Key Expertise**:
- Quality of Earnings (QoE) analysis (EBITDA normalization, non-recurring items, management add-back challenges)
- Working capital analysis (DSO, DIO, DPO, NWC peg development, seasonal adjustments)
- Debt & debt-like items (covenant testing, refinancing requirements, change-of-control provisions)
- Financial model validation (stress-testing buyer's projections, DCF analysis)
- IT/Systems due diligence (ERP age, customization, migration risk, cybersecurity)
- Carve-out financial validation (stranded costs, standalone economics)

**Deliverables**: Financial Due Diligence Report (80–120 pages), Normalized EBITDA Bridge, Working Capital Peg Development, Debt Schedule & Refinancing Analysis, Financial Model Validation, Risk Register

**Integration**: Provides baseline financial assumptions for all downstream agents; works in parallel with Commercial, Legal, and Tax DD; findings inform deal structure and price negotiation

**File Size**: 391 lines (30 KB)

---

### 4. **ma-synergy-value-architect.md** [ORANGE | P2]
**First Principle:** Synergies justify the premium — if you can't quantify them, you can't defend the price. If you can't track them, they'll evaporate.

**Role**: Identifies cost and revenue synergies, quantifies with confidence-weighted scenarios, estimates integration costs, calculates net synergy value, and establishes monthly tracking dashboard.

**Key Expertise**:
- Cost synergy identification & quantification (FTE reduction, real estate, IT, procurement, process automation)
- Revenue synergy identification (cross-selling, market expansion, bundling, pricing power)
- Integration cost estimation (severance, system implementation, training, professional services)
- Net synergy value calculation (Conservative / Base / Upside scenarios)
- Synergy realization tracking dashboard (monthly tracking, escalation triggers, accountability)
- Confidence-weighted scenario analysis

**Deliverables**: Synergy Identification & Quantification Memo, Integration Cost Estimate, Net Synergy Value Analysis, Synergy Realization Playbook, Monthly Tracking Dashboard

**Integration**: Works with Day 2 Integration Lead to execute identified synergies; provides accountability structure for post-close performance tracking; feeds into deal thesis validation and investor reporting

**File Size**: 374 lines (26 KB)

---

### 5. **ma-carve-out-finance-lead.md** [PURPLE | P2]
**First Principle:** Carve-outs are harder than integrations — you are building a standalone company while dismantling shared infrastructure.

**Role**: Manages financial separation of carved-out business unit from parent company. Designs standalone finance operating model, separates GL, allocates stranded costs, establishes standalone systems, and validates carve-out financial statements.

**Key Expertise**:
- Standalone finance operating model design (org structure, staffing, processes, systems, controls)
- GL separation & allocation methodology (account-by-account analysis, allocation basis, historical data remapping)
- Stranded cost analysis (costs that remain with parent post-carve-out; impact on purchase price)
- Working capital & asset separation (AR, AP, inventory, cash, fixed assets, true-up mechanism)
- Historical carve-out financial statement preparation (3–5 year reconstruction for regulatory filings)
- TSA design (post-close services seller continues to provide; exit timeline and costs)
- Separation Management Office (SMO) governance and workstream management

**Deliverables**: Carve-Out Finance Operating Model, GL Separation & Allocation Methodology, Stranded Cost Analysis, Working Capital & Asset Separation Plan, Carve-Out Financial Statements, TSA Schedule, Separation Management Plan

**Integration**: Works with Day 1 Readiness for carve-out standalone setup; coordinates with Finance DD on stranded cost validation; upstream from Day 2 Integration Lead

**File Size**: 534 lines (32 KB)

---

### 6. **ma-purchase-price-allocation-lead.md** [YELLOW | P2]
**First Principle:** PPA determines the acquirer's balance sheet for years to come — get the valuations wrong and you'll impair goodwill, restate earnings, and face auditor scrutiny.

**Role**: Applies acquisition method accounting under ASC 805 (Business Combinations) to allocate purchase consideration to identifiable assets, intangibles, and goodwill. Establishes goodwill impairment testing procedures.

**Key Expertise**:
- ASC 805 Business Combinations framework (acquisition method, consideration, identifiable assets/liabilities)
- Identifiable intangible asset valuation (customer relationships via MEEM, technology via relief from royalty, brands, backlog, favorable contracts, non-compete, IPR&D)
- Tangible asset fair value assessment (PP&E, inventory, AR fair value adjustments)
- Goodwill calculation (consideration + NCI + prior interests – FV of net identifiable assets)
- Contingent consideration & earnout accounting (probability-weighted valuation, post-acquisition adjustments)
- Deferred tax impacts (DTA/DTL on intangible valuations, tangible asset step-ups, assumed liabilities)
- Goodwill impairment testing protocol (annual testing, qualitative assessment, DCF fair value)
- Pro-forma financial statements & ASC 805 disclosures

**Deliverables**: Purchase Price Allocation Report, Intangible Asset Valuation Reports, Goodwill Impairment Testing Protocol, Pro-Forma Financial Statements, Deferred Tax Calculation Schedule, Disclosure Memo

**Integration**: Works with Financial DD Lead on baseline tangible asset valuation; works with Day 2 Integration Lead on synergy realization (synergy realization affects goodwill impairment testing); coordinates with external auditor

**File Size**: 495 lines (28 KB)

---

## Cross-Agent Integration Map

```
Pre-Close Phase:
├── Financial Due Diligence Lead (validates economics; informs deal thesis)
├── Purchase Price Allocation Lead (prepares pre-close PPA framework; identifies key intangibles)
└── Synergy Value Architect (quantifies deal value; builds business case)

Day 1 Phase:
└── Day 1 Readiness Lead (ensures 8-pillar operational capability; manages war room)

Post-Close Integration (Days 1–100):
├── Day 2 Finance Integration Lead (manages 4 waves; process harmonization; system migration)
├── Synergy Value Architect (tracks monthly realization; escalates variances)
├── Carve-Out Finance Lead (if applicable; manages GL separation; TSA governance)
└── Purchase Price Allocation Lead (finalizes PPA within 12 months; goodwill impairment protocols)
```

---

## Key Design Principles Across All Agents

1. **Big 4 / SI Consulting Grade**: All agents deliver enterprise-grade deliverables (detailed playbooks, checklists, risk registers, templates) suitable for board-level presentation and audit committee review.

2. **Finance Transformation Focus**: Not generic M&A advisory — all agents are finance-specific, operational in nature, and focused on standalone finance capability and integration speed.

3. **Regulated Entity Awareness**: All agents account for banking, financial services, and OSFI regulatory requirements (CAR, FRTB, capital requirements, BCBS 239, etc.).

4. **First-Principle Discipline**: Each agent has a clear first principle that governs decision-making (e.g., "Day 1 is a regulatory obligation"; "Integration speed creates value"; "Synergies justify the premium").

5. **Confidence-Weighted Scenarios**: All quantitative outputs include low/medium/high confidence scenarios (not single-point estimates) and explicitly call out assumptions at risk.

6. **Accountability & Tracking**: All agents establish governance structures, ownership matrices, and monthly/weekly tracking mechanisms to ensure execution discipline.

7. **Playbook-Driven**: Deliverables include not just analysis but step-by-step playbooks, contingency procedures, and war room plans for execution.

---

## Recommended Usage Model

**Engagement Sequencing**:
1. **Pre-Close (Months -12 to 0)**: Financial Due Diligence Lead, Purchase Price Allocation Lead, Synergy Value Architect (in parallel)
2. **Pre-Close (Months -6 to 0)**: Day 1 Readiness Lead (designs readiness framework; conducts walkthroughs; prepares TSA schedule)
3. **Day 1 (Close ± 2 days)**: Day 1 Readiness Lead (executes war room; manages 8 pillars; declares go-live)
4. **Days 1–100**: Day 2 Finance Integration Lead (4 waves of integration); Carve-Out Finance Lead (if applicable); Synergy Value Architect (monthly tracking)
5. **Months 12–24**: Purchase Price Allocation Lead (finalizes PPA within 12 months; implements goodwill impairment testing)

---

## File Manifest

| Agent | File | Lines | Size | Color | Priority |
|-------|------|-------|------|-------|----------|
| Day 1 Readiness Lead | ma-day1-readiness-lead.md | 721 | 55 KB | Red | P1 |
| Day 2 Finance Integration Lead | ma-day2-finance-integration-lead.md | 625 | 47 KB | Blue | P1 |
| Financial Due Diligence Lead | ma-financial-due-diligence-lead.md | 391 | 30 KB | Green | P1 |
| Synergy Value Architect | ma-synergy-value-architect.md | 374 | 26 KB | Orange | P2 |
| Carve-Out Finance Lead | ma-carve-out-finance-lead.md | 534 | 32 KB | Purple | P2 |
| Purchase Price Allocation Lead | ma-purchase-price-allocation-lead.md | 495 | 28 KB | Yellow | P2 |
| **TOTAL** | | **3,140** | **218 KB** | | |

---

## Design Quality Notes

- **Depth**: Each agent file is 350–750 lines of detailed expert guidance (not summary outlines)
- **Practical**: Includes real-world examples, checklists, templates, decision matrices, and sample financials
- **Regulatory-Aware**: References OSFI, BCBS, SEC, ASC, IFRS standards where applicable
- **Interconnected**: All agents explicitly call out dependencies and integration points with other agents
- **Actionable**: Each agent provides specific, step-by-step deliverables and implementation procedures
- **Risk-Managed**: Each agent includes risk assessment, contingency planning, and escalation procedures

---

## Author Notes

These agents are purpose-built for:
- **Finance Transformation teams** managing M&A integration for financial services institutions (especially OSFI-regulated entities)
- **Big 4 and SI firms** delivering M&A finance transformation services to corporate and PE clients
- **Internal M&A teams** at large corporations managing acquisition integration
- **PE sponsors** managing post-close finance function integration

All agents assume:
- Target is material acquisition ($100M–$1B+ revenue)
- Buyer has financial reporting obligations (SOX/SOC or equivalent)
- Integration timeline is 6–24 months (not rapid 90-day carve-and-paste)
- Finance transformation is a strategic objective (not just operational integration)

---

**Created**: April 5, 2026
**Version**: 1.0 (Complete Set)
**Quality Bar**: Big 4 / SI Consulting Grade
